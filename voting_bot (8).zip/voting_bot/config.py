"""
config.py
Central configuration loader. Reads all secrets from environment variables
(.env locally, Railway Variables in production). Never hard-code secrets here.
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _required(name: str) -> str:
    val = os.getenv(name, "").strip()
    if not val:
        raise RuntimeError(
            f"Missing required environment variable: {name}. "
            f"Set it in your .env (local) or Railway Variables (production)."
        )
    return val


def _optional(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


@dataclass(frozen=True)
class Config:
    bot_token: str
    owner_id: int
    storage_chat_id: int
    default_review_chat_id: int | None
    google_api_keys: list[str]
    payment_provider: str
    payment_api_key: str
    payment_api_secret: str
    manual_payment_instructions: str
    required_channel: str
    voting_channel: str
    moderation_alert_chat_id: int | None
    premium_max_channels: int
    proxy_url: str | None
    connect_timeout: float
    read_timeout: float
    ai_moderation_timeout: float


def _normalize_chat_ref(raw: str) -> str:
    """Accepts '@name', 'name', or a numeric chat id string and returns
    whatever the Bot API expects as a `chat_id` value: '@name' for a
    public username, or the raw numeric string for a numeric id."""
    raw = raw.strip()
    if not raw:
        return raw
    if raw.lstrip("-").isdigit():
        return raw
    return raw if raw.startswith("@") else f"@{raw}"


def load_config() -> Config:
    bot_token = _required("BOT_TOKEN")
    owner_id = int(_required("OWNER_ID"))
    storage_chat_id = int(_required("STORAGE_CHAT_ID"))

    review_raw = _optional("DEFAULT_REVIEW_CHAT_ID")
    default_review_chat_id = int(review_raw) if review_raw else None

    # Up to 40 keys supported (was 10) so moderation can keep running
    # through Google AI free-tier per-key rate limits even under heavy
    # load — see services/api_pool.py, which round-robins across whichever
    # of these are actually set. Any GOOGLE_API_KEY_1..40 left blank in
    # .env is simply skipped, so you don't need all 40 filled in.
    google_keys = []
    for i in range(1, 41):
        key = _optional(f"GOOGLE_API_KEY_{i}")
        if key:
            google_keys.append(key)

    # Single, pre-configured channel used for both the mandatory
    # subscription gate (spec: "MANDATORY CHANNEL SUBSCRIPTION") and, unless
    # a separate voting channel is explicitly configured, for publishing
    # contestant profiles / running the voting workflow. Fixing this in
    # config (rather than asking the host to pick a channel per giveaway)
    # is what makes "Create Giveaway" require zero questions.
    required_channel = _normalize_chat_ref(_optional("REQUIRED_CHANNEL_USERNAME", "TheNextLevelOfficial"))
    voting_channel = _normalize_chat_ref(_optional("VOTING_CHANNEL_ID", "")) or required_channel

    mod_alert_raw = _optional("MODERATION_ALERT_CHAT_ID")
    moderation_alert_chat_id = int(mod_alert_raw) if mod_alert_raw else default_review_chat_id

    # How many of their OWN channels a Premium host may connect (spec:
    # "n number of GC/channel can be added"). Free hosts connect zero —
    # they always use the bot's single default channel instead (see
    # handlers/channel.py + handlers/giveaway_wizard.py). 0 or a negative
    # value here means "no limit" for Premium hosts.
    premium_max_channels_raw = _optional("PREMIUM_MAX_CHANNELS", "10")
    try:
        premium_max_channels = int(premium_max_channels_raw)
    except ValueError:
        premium_max_channels = 10

    # Optional proxy for reaching api.telegram.org. Leave blank on a normal
    # connection. Set this (e.g. "http://127.0.0.1:10809" or
    # "socks5://127.0.0.1:1080") if this machine's ISP/network/firewall
    # blocks or throttles Telegram directly — that shows up as
    # httpcore.ConnectTimeout -> telegram.error.TimedOut on every request,
    # including the very first get_me() call at startup.
    proxy_url = _optional("PROXY_URL") or None

    # How long to wait when opening the TCP connection / reading a response
    # before PTB raises TimedOut. The library defaults (~5s connect) are too
    # short on slower or congested networks and turn brief hiccups into hard
    # crashes. Override via .env if needed.
    try:
        connect_timeout = float(_optional("CONNECT_TIMEOUT", "20"))
    except ValueError:
        connect_timeout = 20.0
    try:
        read_timeout = float(_optional("READ_TIMEOUT", "20"))
    except ValueError:
        read_timeout = 20.0

    # How long to wait on a single Gemini call before giving up on that key
    # and either trying another key or falling back to UNCERTAIN (manual
    # review). Previously there was NO timeout at all on these calls, so a
    # slow/hanging Gemini response made entry submission hang indefinitely
    # for that user — this is what made the AI moderation feature feel
    # "very slow". A name only ever needs at most two such calls
    # (first check + double-check for a SUSPICIOUS result), so a modest
    # per-call timeout keeps the worst case bounded and fast.
    try:
        ai_moderation_timeout = float(_optional("AI_MODERATION_TIMEOUT_SECONDS", "8"))
    except ValueError:
        ai_moderation_timeout = 8.0

    return Config(
        bot_token=bot_token,
        owner_id=owner_id,
        storage_chat_id=storage_chat_id,
        default_review_chat_id=default_review_chat_id,
        google_api_keys=google_keys,
        payment_provider=_optional("PAYMENT_PROVIDER", "MANUAL"),
        payment_api_key=_optional("PAYMENT_API_KEY"),
        payment_api_secret=_optional("PAYMENT_API_SECRET"),
        manual_payment_instructions=_optional(
            "MANUAL_PAYMENT_INSTRUCTIONS",
            "Contact the giveaway host for payment instructions.",
        ),
        required_channel=required_channel,
        voting_channel=voting_channel,
        moderation_alert_chat_id=moderation_alert_chat_id,
        premium_max_channels=premium_max_channels,
        proxy_url=proxy_url,
        connect_timeout=connect_timeout,
        read_timeout=read_timeout,
        ai_moderation_timeout=ai_moderation_timeout,
    )


CONFIG = load_config()
