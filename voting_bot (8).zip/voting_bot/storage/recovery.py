"""
storage/recovery.py
Corruption-tolerant helpers used at startup (spec section 88): if a record
in the local snapshot is malformed, skip it, log a sanitized warning, and
keep booting rather than crashing the whole bot.
"""
from __future__ import annotations
import logging

logger = logging.getLogger("storage.recovery")


async def safe_boot(storage, owner_notifier=None) -> dict:
    """
    Wraps rebuild_indexes with a top-level guard. If indexing itself throws
    (e.g. disk unreadable), the bot still starts with an empty index rather
    than refusing to boot, and the owner is notified if a notifier callback
    is supplied.
    """
    try:
        result = await storage.rebuild_indexes()
        if result["corrupt"] > 0 and owner_notifier:
            await owner_notifier(
                f"⚠️ Storage recovery: {result['corrupt']} record(s) were "
                f"corrupt and skipped. {result['loaded']} loaded successfully."
            )
        return result
    except Exception as e:
        logger.error("Fatal error during index rebuild, booting empty: %s", e)
        if owner_notifier:
            await owner_notifier(
                "🚨 Storage failed to load at startup. Bot is running with "
                "an EMPTY index. Check logs and /admin -> Storage."
            )
        return {"loaded": 0, "corrupt": 0, "fatal": str(e)}
