"""
storage/telegram_storage.py

Persistent storage engine that uses a private Telegram chat as the record
store, as required. Read this module's docstring in full — it documents a
real Telegram Bot API limitation and the legitimate workaround used here.

=====================================================================
KNOWN TELEGRAM LIMITATION (documented per project instructions)
=====================================================================
The Bot API has no method for a bot to fetch historical message content by
message_id, and no "list/search chat history" method. A bot only ever sees
message content at the moment it sends or receives it. This means a bot
cannot, by itself, reconstruct message *content* from Telegram after total
loss of local state — there is no legitimate way around this, and this
codebase does not pretend otherwise.

The closest correct, honest design (used here) is a two-tier model:

  1. TELEGRAM CHAT = durable, human-readable, tamper-evident record of
     everything that ever happened (every record version and audit event
     is posted as its own message). A human (owner) can always scroll it,
     search it, or export it. This satisfies "private Telegram storage"
     and "audit trail" requirements.

  2. LOCAL SNAPSHOT FILE (runtime_cache/snapshot.json) = the fast index
     the bot actually reads from. It is written synchronously every time
     a record is saved/updated, so a normal restart (the common case:
     process restart, redeploy without volume loss) recovers instantly
     with zero Telegram API calls. This file holds only structured data
     the bot itself generated — never secrets.

If the local snapshot is ever lost (e.g. a fresh volume) the bot CANNOT
automatically replay history from Telegram — no Bot API call makes that
possible. In that disaster scenario the bot starts with an empty index
but keeps posting new records normally; the OWNER can manually reconcile
using the human-readable message history in the storage chat. This is
called out explicitly in /admin -> Storage rather than silently failing
or falsely claiming full auto-recovery.

For typical hosting (Railway with a persistent volume, or any host that
keeps the working directory between restarts) this gives real crash
recovery. If you deploy somewhere with an ephemeral filesystem on every
restart, mount a small persistent volume for `runtime_cache/` — that is
the one piece of local disk this design relies on. This is a deliberate,
documented trade-off, not a hidden shortcut.
=====================================================================
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Any, Optional

from telegram import Bot
from telegram.error import TelegramError

from storage.models import Record, new_id

logger = logging.getLogger("storage")

SNAPSHOT_DIR = "runtime_cache"
SNAPSHOT_PATH = os.path.join(SNAPSHOT_DIR, "snapshot.json")


class TelegramStorage:
    """
    save_record / update_record / get_record / search_records / list_records
    / append_event / create_version / recover_record / rebuild_indexes
    """

    def __init__(self, bot: Bot, storage_chat_id: int):
        self.bot = bot
        self.storage_chat_id = storage_chat_id
        self._lock = asyncio.Lock()

        # In-memory indexes (the runtime cache described above)
        self._by_id: dict[str, Record] = {}
        self._by_type: dict[str, set[str]] = {}
        self._write_failures = 0
        self._last_write_ok: float | None = None
        self._last_write_error: str | None = None

        # ------------------------------------------------------------
        # PERF: background write-behind queue.
        # The bot's own responsiveness (vote confirmed, button updates,
        # etc.) must never wait on a Telegram HTTP round-trip. The index
        # + local snapshot (see _persist_snapshot) are the bot's real
        # source of truth and are updated synchronously and instantly;
        # the copy posted to the human-readable storage chat is posted
        # by a single background worker that drains this queue in order,
        # so the audit trail still lands in the same order it was
        # produced, it just no longer blocks the caller. See start().
        # ------------------------------------------------------------
        self._write_queue: asyncio.Queue[Record] = asyncio.Queue()
        self._writer_task: asyncio.Task | None = None
        self._pending_writes = 0

        os.makedirs(SNAPSHOT_DIR, exist_ok=True)

    def start(self) -> None:
        """Start the background Telegram-writer task. Call once, after the
        event loop is running (e.g. from post_init). Safe to call more
        than once — later calls are no-ops while a task is already alive."""
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def stop(self) -> None:
        """Drain the queue and stop the worker (best-effort, for clean shutdown).

        Cancelling the task alone only *schedules* the cancellation — the
        task is still "pending" until the event loop actually runs it one
        more time to deliver the CancelledError. If nothing awaits it
        after cancel(), the loop can close first (e.g. right after
        Application.shutdown()), which is exactly what produced:
            Task was destroyed but it is pending!
            ...
            RuntimeError: Event loop is closed
        Awaiting the task here (swallowing the expected CancelledError)
        makes sure it actually finishes before the loop goes away.
        """
        if self._writer_task is not None:
            await self._write_queue.join()
            self._writer_task.cancel()
            try:
                await self._writer_task
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.exception("Writer task raised during shutdown")

    # ------------------------------------------------------------------
    # Startup / recovery
    # ------------------------------------------------------------------
    async def rebuild_indexes(self) -> dict[str, Any]:
        """
        Startup sequence per spec section 5/88:
        load local snapshot (fast path) -> validate -> build indexes.
        Telegram itself cannot be replayed (see module docstring), so the
        snapshot IS the recovery mechanism.
        """
        loaded = 0
        corrupt = 0
        if os.path.exists(SNAPSHOT_PATH):
            try:
                with open(SNAPSHOT_PATH, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                for rid, payload in raw.get("records", {}).items():
                    try:
                        rec = Record.from_wire(payload, message_id=payload.get("message_id"))
                        self._index_record(rec)
                        loaded += 1
                    except Exception:
                        corrupt += 1
                        logger.warning("Skipped corrupt snapshot record %s", rid)
            except Exception as e:
                logger.error("Snapshot unreadable, starting with empty index: %s", e)
        else:
            logger.warning(
                "No local snapshot found. Starting with an EMPTY index. "
                "Telegram message history cannot be auto-replayed (see "
                "storage/telegram_storage.py docstring) — this is expected "
                "on first run, or requires manual owner reconciliation "
                "after a disaster loss of runtime_cache/."
            )

        return {"loaded": loaded, "corrupt": corrupt}

    def _index_record(self, rec: Record) -> None:
        self._by_id[rec.id] = rec
        self._by_type.setdefault(rec.type, set()).add(rec.id)

    def _persist_snapshot(self) -> None:
        """Synchronous, atomic local checkpoint. Called after every write."""
        tmp_path = SNAPSHOT_PATH + ".tmp"
        payload = {
            "saved_at": time.time(),
            "records": {
                rid: {**rec.to_wire(), "message_id": rec.message_id}
                for rid, rec in self._by_id.items()
            },
        }
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
        os.replace(tmp_path, SNAPSHOT_PATH)

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------
    async def save_record(
        self, type_: str, data: dict[str, Any], status: str = "active", record_id: str | None = None
    ) -> Record:
        """Create a brand-new record and post it to the storage chat."""
        async with self._lock:
            rid = record_id or new_id(type_.lower())
            rec = Record(type=type_, id=rid, version=1, status=status, data=data)
            self._index_record(rec)
            self._persist_snapshot()
            self._queue_write(rec)
            return rec

    async def update_record(
        self, record_id: str, data: dict[str, Any] | None = None, status: str | None = None
    ) -> Optional[Record]:
        """
        Idempotent update: bumps version, posts a NEW message (never
        destructive-edits history) so audit history is preserved, and
        updates the index to point at the latest version.
        """
        async with self._lock:
            rec = self._by_id.get(record_id)
            if rec is None:
                return None
            new_rec = Record(
                type=rec.type,
                id=rec.id,
                version=rec.version + 1,
                status=status or rec.status,
                data={**rec.data, **(data or {})},
                created_at=rec.created_at,
            )
            self._index_record(new_rec)
            self._persist_snapshot()
            self._queue_write(new_rec)
            return new_rec

    async def get_record(self, record_id: str) -> Optional[Record]:
        return self._by_id.get(record_id)

    async def try_transition(
        self, record_id: str, expected_status: str, new_status: str,
        data: dict[str, Any] | None = None,
    ) -> Optional[Record]:
        """
        Atomic compare-and-swap on a record's status. Only applies the
        transition if the record's CURRENT status still equals
        expected_status at the moment the lock is held — closing the
        check-then-write race where two concurrent callback presses
        (e.g. two admins double-tapping Approve, or a duplicated/retried
        callback) could otherwise both pass a status check before either
        write lands (spec sections 20, 43, 60).

        Returns the updated Record on success, or None if the record was
        missing or had already moved to a different status (i.e. someone
        else won the race, or this is a stale/replayed action).
        """
        async with self._lock:
            rec = self._by_id.get(record_id)
            if rec is None or rec.status != expected_status:
                return None
            new_rec = Record(
                type=rec.type,
                id=rec.id,
                version=rec.version + 1,
                status=new_status,
                data={**rec.data, **(data or {})},
                created_at=rec.created_at,
            )
            self._index_record(new_rec)
            self._persist_snapshot()
            self._queue_write(new_rec)
            return new_rec

    async def save_if_unique(
        self, type_: str, unique_fields: dict[str, Any], data: dict[str, Any], status: str = "active",
    ) -> tuple[Record, bool]:
        """
        Atomic find-or-create: checks whether a record of this type already
        matches unique_fields and, if not, creates one — all under a single
        lock acquisition, so two near-simultaneous requests for the same
        unique key (e.g. the same voter double-tapping Vote) cannot both
        pass the "does this exist yet" check before either has written
        (spec section 20: "only the legitimate single vote should be
        recorded" under near-simultaneous requests).

        Returns (record, created) — created=False means an existing
        matching record was returned instead of creating a new one.
        """
        async with self._lock:
            for rid in self._by_type.get(type_, set()):
                rec = self._by_id[rid]
                if all(rec.data.get(k) == v for k, v in unique_fields.items()):
                    return rec, False
            rid = new_id(type_.lower())
            rec = Record(type=type_, id=rid, version=1, status=status, data=data)
            self._index_record(rec)
            self._persist_snapshot()
            self._queue_write(rec)
            return rec, True

    async def list_records(self, type_: str, status: str | None = None) -> list[Record]:
        ids = self._by_type.get(type_, set())
        recs = [self._by_id[i] for i in ids]
        if status:
            recs = [r for r in recs if r.status == status]
        return sorted(recs, key=lambda r: r.created_at)

    async def search_records(self, type_: str, predicate) -> list[Record]:
        """predicate: Callable[[Record], bool]"""
        return [r for r in await self.list_records(type_) if predicate(r)]

    async def append_event(self, type_: str, data: dict[str, Any]) -> Record:
        """For append-only logs (audit events, vote events). Always a new record."""
        return await self.save_record(type_, data, status="logged")

    async def create_version(self, record_id: str, data: dict[str, Any]) -> Optional[Record]:
        """Explicit alias of update_record for callers that want to be explicit."""
        return await self.update_record(record_id, data=data)

    async def recover_record(self, record_id: str) -> Optional[Record]:
        """
        Attempt to recover a record the in-memory index has lost track of.
        Since content re-fetch by message_id is not possible via Bot API
        (see module docstring), recovery is limited to what's still in the
        local snapshot on disk. Returns None if truly gone.
        """
        if record_id in self._by_id:
            return self._by_id[record_id]
        if os.path.exists(SNAPSHOT_PATH):
            try:
                with open(SNAPSHOT_PATH, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                payload = raw.get("records", {}).get(record_id)
                if payload:
                    rec = Record.from_wire(payload, message_id=payload.get("message_id"))
                    self._index_record(rec)
                    return rec
            except Exception:
                pass
        return None

    # ------------------------------------------------------------------
    # Telegram write path
    # ------------------------------------------------------------------
    def _queue_write(self, rec: Record) -> None:
        """Hand a record off to the background writer instead of posting
        to Telegram inline. The caller already has the record indexed
        in-memory and checkpointed to the local snapshot at this point —
        that's what makes votes/approvals/etc. feel instant. The human
        audit-trail message in the storage chat follows a moment later,
        in the same order records were produced (single worker, FIFO
        queue), without anyone waiting on it."""
        self._pending_writes += 1
        self._write_queue.put_nowait(rec)

    async def _writer_loop(self) -> None:
        """Background worker: drains the write queue one record at a
        time and posts each to the storage chat, so Telegram write
        latency (and Telegram's own rate limits) never blocks a user
        waiting on a vote/approval/etc. Retries transient failures a
        few times with backoff before giving up on that single message;
        health()/consecutive_failures still reflects real trouble so the
        owner sees it in /admin -> Storage."""
        while True:
            rec = await self._write_queue.get()
            try:
                for attempt in range(3):
                    try:
                        await self._send_to_telegram(rec)
                        break
                    except TelegramError as e:
                        self._write_failures += 1
                        self._last_write_error = str(e)
                        logger.error(
                            "Storage write failed for %s (attempt %d/3): %s",
                            rec.id, attempt + 1, e,
                        )
                        if attempt < 2:
                            await asyncio.sleep(1.5 * (attempt + 1))
                        else:
                            logger.error(
                                "Giving up on storage write for %s after 3 attempts — "
                                "it stays in the local index/snapshot (bot keeps working "
                                "correctly) but is missing from the Telegram audit chat "
                                "until an owner reconciles it.", rec.id,
                            )
                else:
                    pass
                if rec.message_id is not None:
                    async with self._lock:
                        self._persist_snapshot()
            finally:
                self._pending_writes = max(0, self._pending_writes - 1)
                self._write_queue.task_done()

    async def _send_to_telegram(self, rec: Record) -> None:
        text = self._format_message(rec)
        msg = await self.bot.send_message(
            chat_id=self.storage_chat_id,
            text=text,
            parse_mode="HTML",
        )
        rec.message_id = msg.message_id
        self._last_write_ok = time.time()
        self._write_failures = 0

    @staticmethod
    def _format_message(rec: Record) -> str:
        body = json.dumps(rec.to_wire(), ensure_ascii=False, indent=2, default=str)
        return (
            f"<b>STORAGE_RECORD</b>\n"
            f"TYPE: {rec.type}\n"
            f"ID: {rec.id}\n"
            f"VERSION: {rec.version}\n\n"
            f"<pre>{_escape_html(body)}</pre>"
        )

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------
    def health(self) -> dict[str, Any]:
        return {
            "records": len(self._by_id),
            "last_write_ok": self._last_write_ok,
            "last_write_error": self._last_write_error,
            "consecutive_failures": self._write_failures,
            "pending_writes": self._pending_writes,
            "status": "ONLINE" if self._write_failures == 0 else "DEGRADED",
        }


def _escape_html(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
