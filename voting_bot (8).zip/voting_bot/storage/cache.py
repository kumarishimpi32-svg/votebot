"""
storage/cache.py
Pure in-memory, non-persistent caches for things that don't need to survive
a restart: rate-limit buckets and processed-callback dedup (replay
protection). These are intentionally NOT written to Telegram or the
snapshot — they're ephemeral by design.
"""
from __future__ import annotations
import time
from collections import defaultdict, deque


class RateLimiter:
    def __init__(self, max_calls: int, per_seconds: float):
        self.max_calls = max_calls
        self.per_seconds = per_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        now = time.time()
        bucket = self._hits[key]
        while bucket and now - bucket[0] > self.per_seconds:
            bucket.popleft()
        if len(bucket) >= self.max_calls:
            return False
        bucket.append(now)
        return True


class ReplayGuard:
    """Prevents the same callback_query id (or any one-shot token) firing twice."""

    def __init__(self, ttl_seconds: float = 300):
        self.ttl = ttl_seconds
        self._seen: dict[str, float] = {}

    def seen_before(self, token: str) -> bool:
        now = time.time()
        # sweep occasionally
        if len(self._seen) > 5000:
            self._seen = {k: v for k, v in self._seen.items() if now - v < self.ttl}
        if token in self._seen and now - self._seen[token] < self.ttl:
            return True
        self._seen[token] = now
        return False
