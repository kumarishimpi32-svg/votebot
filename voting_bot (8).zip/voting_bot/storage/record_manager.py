"""
storage/record_manager.py
Thin typed convenience layer over TelegramStorage so services don't have
to remember record-type strings everywhere.
"""
from __future__ import annotations
from typing import Any
from storage.telegram_storage import TelegramStorage
from storage.models import Record


class RecordManager:
    def __init__(self, storage: TelegramStorage):
        self.storage = storage

    # Generic passthroughs
    async def save(self, type_: str, data: dict[str, Any], **kw) -> Record:
        return await self.storage.save_record(type_, data, **kw)

    async def update(self, record_id: str, **kw) -> Record | None:
        return await self.storage.update_record(record_id, **kw)

    async def try_transition(
        self, record_id: str, expected_status: str, new_status: str, data: dict[str, Any] | None = None
    ) -> Record | None:
        """Atomic compare-and-swap — see TelegramStorage.try_transition."""
        return await self.storage.try_transition(record_id, expected_status, new_status, data=data)

    async def save_if_unique(
        self, type_: str, unique_fields: dict[str, Any], data: dict[str, Any], status: str = "active"
    ) -> tuple[Record, bool]:
        """Atomic find-or-create — see TelegramStorage.save_if_unique."""
        return await self.storage.save_if_unique(type_, unique_fields, data, status=status)

    async def get(self, record_id: str) -> Record | None:
        return await self.storage.get_record(record_id)

    async def list(self, type_: str, status: str | None = None) -> list[Record]:
        return await self.storage.list_records(type_, status=status)

    async def find(self, type_: str, **field_equals) -> list[Record]:
        def pred(r: Record) -> bool:
            return all(r.data.get(k) == v for k, v in field_equals.items())
        return await self.storage.search_records(type_, pred)

    async def find_one(self, type_: str, **field_equals) -> Record | None:
        results = await self.find(type_, **field_equals)
        return results[0] if results else None
