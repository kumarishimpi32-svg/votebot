"""
storage/models.py
Defines the record envelope used for every persisted object.
"""
from __future__ import annotations
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


RECORD_TYPES = {
    "USER",
    "GIVEAWAY",
    "PARTICIPANT",
    "VOTE",
    "VOTE_DEDUCTION",
    "VOTE_RESTORATION",
    "MANUAL_VOTE",
    "AUDIT",
    "MANUAL_REVIEW",
    "PREMIUM_PLAN",
    "PREMIUM_ACCOUNT",
    "PREMIUM_PAYMENT",
    "PREMIUM_TRANSACTION",
    "PREMIUM_AUDIT",
    "CONFIG",
    "STORAGE_META",
    "CONTESTANT_PUBLISH",   # dedup key: one per approved participant ever published to the voting channel
    "MODERATION_ALERT",     # dedup key: one per (chat_id, message_id) channel-content moderation alert
    "PAYMENT_ADMIN_GRANT",
    "CHANNEL",              # a host's connected Telegram channel (multi-channel CONNECT system)
}


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


@dataclass
class Record:
    type: str
    id: str
    version: int
    status: str
    data: dict[str, Any]
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    message_id: int | None = None  # Telegram message id holding this record's latest version

    def to_wire(self) -> dict[str, Any]:
        """The JSON body actually written into the Telegram message text."""
        return {
            "type": self.type,
            "id": self.id,
            "version": self.version,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "data": self.data,
        }

    @staticmethod
    def from_wire(payload: dict[str, Any], message_id: int | None = None) -> "Record":
        return Record(
            type=payload["type"],
            id=payload["id"],
            version=payload.get("version", 1),
            status=payload.get("status", "active"),
            data=payload.get("data", {}),
            created_at=payload.get("created_at", time.time()),
            updated_at=payload.get("updated_at", time.time()),
            message_id=message_id,
        )
