"""
services/winner_service.py
Winner selection with minimum-vote gating and tie handling (spec 33-34).
"""
from __future__ import annotations
import random
from storage.record_manager import RecordManager
from services.audit_service import AuditService


class WinnerService:
    def __init__(self, records: RecordManager, audit: AuditService):
        self.records = records
        self.audit = audit

    async def select_winners(self, giveaway_id: str, actor_id: int):
        giveaway = await self.records.get(giveaway_id)
        if giveaway is None:
            return []

        min_votes = giveaway.data.get("min_votes", 0)
        max_winners = giveaway.data.get("max_winners", 1)
        tie_rule = giveaway.data.get("tie_rule", "all")

        participants = await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)
        eligible = [
            p for p in participants
            if p.status == "approved" and p.data.get("votes", 0) >= min_votes
        ]

        if not eligible:
            await self.audit.log("winner_selection_empty", actor_id, giveaway_id=giveaway_id)
            return []

        eligible.sort(key=lambda p: p.data.get("votes", 0), reverse=True)
        top_score = eligible[0].data.get("votes", 0)
        tied_at_top = [p for p in eligible if p.data.get("votes", 0) == top_score]

        winners: list = []
        if len(tied_at_top) <= max_winners:
            winners = eligible[:max_winners]
        else:
            # More ties at the top than slots available
            if tie_rule == "all":
                winners = tied_at_top
            elif tie_rule == "random":
                winners = random.sample(tied_at_top, k=max_winners)
            elif tie_rule == "host":
                # Flag for host manual selection; return the tied pool, caller
                # (handlers/host.py) presents a picker instead of finalizing.
                await self.audit.log(
                    "winner_tie_needs_host_selection", actor_id, giveaway_id=giveaway_id,
                    details={"tied_participant_ids": [p.id for p in tied_at_top]},
                )
                return {"needs_host_selection": True, "candidates": tied_at_top}
            else:
                winners = tied_at_top[:max_winners]

        for w in winners:
            await self.records.save(
                "AUDIT",
                {
                    "action": "winner_selected",
                    "actor_id": actor_id,
                    "giveaway_id": giveaway_id,
                    "details": {"participant_id": w.id, "votes": w.data.get("votes", 0)},
                },
            )
        return winners
