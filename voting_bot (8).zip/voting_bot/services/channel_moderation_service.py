"""
services/channel_moderation_service.py

This is the ACTUAL moderation requirement: detect potentially prohibited
content posted in the managed voting channel and alert an admin to review
and remove it. This is a different concept from the old "Image Protection"
participant-photo-submission flow (removed) — that made participants
submit a photo of themselves; this watches what actually gets posted in
the channel by anyone.

Event-driven + idempotent by design:
  - runs once per incoming channel post (a live Telegram update), never on
    a timer/poll, so it cannot spam the channel just because a background
    job woke up
  - every message is recorded exactly once in a MODERATION_ALERT record
    keyed by (chat_id, message_id) via the atomic save_if_unique — a
    duplicate delivery of the same update (Telegram retry, restart, etc.)
    is always a no-op on the second pass
  - normal content produces NO message anywhere (no channel reply, no DM)
  - flagged content produces exactly ONE alert, sent to the moderation
    admins, never to the channel itself (so the bot never publicly spams
    the channel it's supposed to be protecting)
"""
from __future__ import annotations
import logging
from telegram import Bot
from telegram.error import TelegramError
from storage.record_manager import RecordManager
from services.name_filter import NameFilter
from services.ai_moderation import AiModerationService, Classification
from services.image_moderation import ImageModerationService
from services.premium_service import PremiumService
from utils.formatting import spoiler_mask

logger = logging.getLogger("channel_moderation")


class ChannelModerationService:
    def __init__(self, records: RecordManager, name_filter: NameFilter, ai: AiModerationService,
                 alert_chat_id: int | None, image_moderation: ImageModerationService | None = None,
                 premium_service: PremiumService | None = None):
        self.records = records
        self.name_filter = name_filter
        self.ai = ai
        self.alert_chat_id = alert_chat_id
        self.image_moderation = image_moderation
        self.premium_service = premium_service

    async def _is_bootstrap_channel(self, chat_id: int) -> bool:
        """The single pre-configured CONFIG.voting_channel (back-compat,
        no CHANNEL record) always counts as the bot owner's own — always
        monitored, Premium or not."""
        rec = await self.records.find_one("CHANNEL", chat_id=chat_id)
        return rec is None

    async def channel_owner_has_premium(self, chat_id: int) -> bool:
        """Photo monitoring (spec 'IN PREMIUM IT WILL MONITOR ALL PHOTOS')
        is a Premium-only feature for a host's OWN connected channel — the
        bot's own bootstrap channel is always monitored regardless."""
        if await self._is_bootstrap_channel(chat_id):
            return True
        if self.premium_service is None:
            return False
        rec = await self.records.find_one("CHANNEL", chat_id=chat_id)
        if rec is None or rec.status != "active":
            return False
        owner_id = rec.data.get("owner_id")
        if not owner_id:
            return False
        return await self.premium_service.is_active(owner_id)

    async def _resolve_alert_chat_id(self, chat_id: int) -> int | None:
        """Prefer the specific channel's connecting admin (the person who
        actually owns/manages that channel) over the single global
        fallback — a moderation alert for Channel A should reach Channel
        A's admin, not necessarily whoever configured the bot overall."""
        channel_rec = await self.records.find_one("CHANNEL", chat_id=chat_id)
        if channel_rec is not None and channel_rec.status == "active":
            owner_id = channel_rec.data.get("owner_id")
            if owner_id:
                return owner_id
        return self.alert_chat_id

    async def _classify(self, text: str) -> tuple[Classification, str]:
        if self.name_filter.is_blocked(text):
            return Classification.REJECT, "Blocked term detected"

        first, reason1 = await self.ai.classify_text(text)
        if first in (Classification.SAFE, Classification.UNCERTAIN):
            return first, reason1
        if first == Classification.REJECT:
            return first, reason1

        # SUSPICIOUS -> a single second-pass check, same conservative
        # pattern as the participant-name pipeline. We deliberately do NOT
        # loop further or escalate on our own — a human makes the final
        # call, this service only decides whether to alert them.
        second, reason2 = await self.ai.double_check(text)
        if second == Classification.SUSPICIOUS:
            return Classification.SUSPICIOUS, reason2
        return second, reason2

    async def evaluate_channel_post(self, chat_id: int, message_id: int, text: str, sender_id: int | None) -> dict | None:
        """Returns a dict describing the alert if one was (just now) raised,
        or None if the content was fine or this message was already
        processed before. Never raises for ordinary moderation outcomes —
        only a genuine Telegram/storage failure propagates."""
        claim, created = await self.records.save_if_unique(
            "MODERATION_ALERT",
            unique_fields={"chat_id": chat_id, "message_id": message_id},
            data={"chat_id": chat_id, "message_id": message_id, "sender_id": sender_id},
            status="checked",
        )
        if not created:
            # Already evaluated this exact message before — never re-alert.
            return None

        if not text or not text.strip():
            return None

        classification, reason = await self._classify(text)
        await self.records.update(claim.id, data={"classification": classification.value, "reason": reason})

        if classification not in (Classification.REJECT, Classification.SUSPICIOUS):
            return None  # SAFE or UNCERTAIN -> do nothing, never alert on ambiguity

        await self.records.update(claim.id, status="alerted")
        return {
            "kind": "text",
            "chat_id": chat_id,
            "message_id": message_id,
            "sender_id": sender_id,
            "classification": classification.value,
            "reason": reason,
        }

    async def evaluate_channel_photo(self, chat_id: int, message_id: int, file_id: str, sender_id: int | None) -> dict | None:
        """Same idempotent, event-driven design as evaluate_channel_post,
        but for a photo posted in the channel (spec: 'IN PREMIUM IT WILL
        MONITOR ALL PHOTOS ... ON THE CHANNEL'). Gated to Premium at the
        call site (handlers/channel_moderation.py) via
        channel_owner_has_premium — this method itself just classifies
        and records, so it stays testable independent of billing state."""
        if self.image_moderation is None:
            return None

        claim, created = await self.records.save_if_unique(
            "MODERATION_ALERT",
            unique_fields={"chat_id": chat_id, "message_id": message_id},
            data={"chat_id": chat_id, "message_id": message_id, "sender_id": sender_id, "media": "photo"},
            status="checked",
        )
        if not created:
            return None  # already evaluated this exact message before

        classification, reason = await self.image_moderation.classify_photo(file_id)
        await self.records.update(claim.id, data={"classification": classification.value, "reason": reason})

        if classification not in (Classification.REJECT, Classification.SUSPICIOUS):
            return None  # SAFE or UNCERTAIN -> do nothing, never alert on ambiguity

        await self.records.update(claim.id, status="alerted")
        return {
            "kind": "photo",
            "chat_id": chat_id,
            "message_id": message_id,
            "sender_id": sender_id,
            "classification": classification.value,
            "reason": reason,
        }

    async def send_alert(self, bot: Bot, alert: dict) -> bool:
        chat_id = alert["chat_id"]
        message_id = alert["message_id"]

        target_chat_id = await self._resolve_alert_chat_id(chat_id)
        if target_chat_id is None:
            logger.warning("Moderation alert raised but no alert chat is configured: %s", alert)
            return False

        link = None
        try:
            chat = await bot.get_chat(chat_id)
            if chat.username:
                link = f"https://t.me/{chat.username}/{message_id}"
        except TelegramError:
            pass  # link is a convenience only — never block the alert on this

        sender_line = f"\n👤 Sender ID: <code>{alert['sender_id']}</code>" if alert.get("sender_id") else ""
        link_line = f"\n🔗 {link}" if link else f"\n🆔 Message ID: <code>{message_id}</code>"
        media_label = "photo" if alert.get("kind") == "photo" else "message"

        # The reason is never shown in plain text — see spoiler_mask():
        # the bot must never plainly state or describe content that
        # violates Telegram's rules, even while flagging it for review.
        reason = alert.get("reason") or ""
        reason_line = f"\n🔎 Why: {spoiler_mask(reason)}" if reason else ""

        text = (
            "⚠️ <b>MODERATION ALERT</b>\n\n"
            f"A potentially rule-violating {media_label} was posted in a channel you manage.\n"
            "Nothing was posted publicly about this — please review it yourself and remove it if necessary."
            f"{sender_line}{link_line}{reason_line}"
        )
        try:
            await bot.send_message(chat_id=target_chat_id, text=text, parse_mode="HTML")
            return True
        except TelegramError as e:
            logger.warning("Could not deliver moderation alert: %s", e)
            return False
