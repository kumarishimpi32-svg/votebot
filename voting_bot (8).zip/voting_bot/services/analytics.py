"""
services/analytics.py
Aggregates counts for host/owner dashboards (spec 65).
"""
from __future__ import annotations
from storage.record_manager import RecordManager


class AnalyticsService:
    def __init__(self, records: RecordManager):
        self.records = records

    async def giveaway_stats(self, giveaway_id: str) -> dict:
        participants = await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)
        votes = await self.records.find("VOTE", giveaway_id=giveaway_id)
        manual = await self.records.find("MANUAL_VOTE", giveaway_id=giveaway_id)
        deductions = [v for v in votes if v.status == "deducted"]
        restored = [v for v in votes if v.data.get("restored")]
        pending = [p for p in participants if p.status == "pending_review"]

        return {
            "participants": len(participants),
            "approved": len([p for p in participants if p.status == "approved"]),
            "rejected": len([p for p in participants if p.status == "rejected"]),
            "pending_review": len(pending),
            "valid_votes": len([v for v in votes if v.status == "valid"]),
            "deducted_votes": len(deductions),
            "restored_votes": len(restored),
            "manual_votes": len(manual),
        }

    async def owner_overview(self) -> dict:
        giveaways = await self.records.list("GIVEAWAY")
        payments = await self.records.list("PREMIUM_PAYMENT")
        premium_accounts = await self.records.list("PREMIUM_ACCOUNT")
        return {
            "total_giveaways": len(giveaways),
            "active_giveaways": len([g for g in giveaways if g.data.get("state") == "ACTIVE"]),
            "pending_payments": len([p for p in payments if p.status == "pending"]),
            "approved_payments": len([p for p in payments if p.status == "approved"]),
            "premium_accounts": len(premium_accounts),
        }
