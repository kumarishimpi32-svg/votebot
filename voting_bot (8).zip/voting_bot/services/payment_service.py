"""
services/payment_service.py
Manual INR payment submission/verification flow (spec 38-47, 58-60).
Premium activation NEVER happens automatically off a user claim — only an
authorized payment admin's APPROVE action triggers PremiumService.
"""
from __future__ import annotations
from storage.record_manager import RecordManager
from services.audit_service import AuditService
from services.premium_service import PremiumService


class PaymentError(Exception):
    pass


class PaymentService:
    def __init__(self, records: RecordManager, audit: AuditService, premium: PremiumService):
        self.records = records
        self.audit = audit
        self.premium = premium

    async def submit_payment(self, user_id: int, plan_record_id: str, reference: str, proof_file_id: str | None = None):
        plan = await self.records.get(plan_record_id)
        if plan is None or not plan.data.get("active"):
            raise PaymentError("invalid_plan")

        # Never trust a user-submitted amount/duration: derive from the plan.
        rec = await self.records.save(
            "PREMIUM_PAYMENT",
            {
                "user_id": user_id,
                "plan_record_id": plan_record_id,
                "plan_id": plan.data.get("plan_id"),
                "amount_inr": plan.data.get("price_inr"),
                "duration_days": plan.data.get("duration_days"),
                "reference": reference,
                "proof_file_id": proof_file_id,  # stored, never shown publicly
            },
            status="pending",
        )
        await self.audit.log("payment_submitted", user_id, details={"payment_id": rec.id, "reference": reference})
        return rec

    async def list_pending(self):
        return await self.records.list("PREMIUM_PAYMENT", status="pending")

    async def user_history(self, user_id: int):
        return await self.records.find("PREMIUM_PAYMENT", user_id=user_id)

    async def approve(self, payment_id: str, verifier_id: int):
        payment = await self.records.get(payment_id)
        if payment is None:
            raise PaymentError("not_found")

        # Atomic compare-and-swap (spec 47, 60): a plain "check status then
        # update" here would let two concurrent approve presses (e.g. two
        # Payment Admins double-tapping, or a retried callback) both pass
        # the pending-status check before either write landed, activating
        # Premium twice off a single payment.
        claimed = await self.records.try_transition(payment_id, "pending", "approved")
        if claimed is None:
            raise PaymentError("not_pending")  # duplicate-approval guard (spec 47)
        payment = claimed

        # Duplicate-reference guard, checked AFTER this payment has already
        # won its own pending->approved transition — not before. find()/get()
        # are unlocked reads (only try_transition/update/save take the
        # storage lock), so checking first would leave a race: two DIFFERENT
        # payment records sharing the same reference could both pass the
        # "no approved duplicate yet" check before either had transitioned,
        # then both independently win their own compare-and-swap (each is
        # scoped to its own record_id, not to the reference), silently
        # activating Premium twice off one real payment. Checking after
        # guarantees at most one winner: whichever payment's transition
        # commits first is already visible when the other's check runs.
        reference = payment.data.get("reference")
        same_ref = await self.records.find("PREMIUM_PAYMENT", reference=reference)
        other_approved = [p for p in same_ref if p.status == "approved" and p.id != payment_id]
        if other_approved:
            # Lost the race (or this reference was already legitimately
            # used elsewhere) — revert and refuse to activate Premium.
            await self.records.update(
                payment_id, status="rejected",
                data={"reject_reason": "Duplicate payment reference"},
            )
            await self.audit.log(
                "payment_duplicate_reference_blocked", verifier_id,
                details={"payment_id": payment_id, "reference": reference},
            )
            raise PaymentError("duplicate_reference_already_approved")

        acc, prev_expiry, new_expiry = await self.premium.activate_or_extend(
            user_id=payment.data["user_id"],
            actor_id=verifier_id,
            duration_days=payment.data["duration_days"],
            source="payment",
            plan_id=payment.data.get("plan_id"),
        )
        await self.records.save(
            "PREMIUM_TRANSACTION",
            {
                "user_id": payment.data["user_id"],
                "payment_id": payment_id,
                "plan_id": payment.data.get("plan_id"),
                "amount_inr": payment.data.get("amount_inr"),
                "verified_by": verifier_id,
                "previous_expiry": prev_expiry,
                "new_expiry": new_expiry,
            },
            status="completed",
        )
        await self.audit.log("payment_approved", verifier_id, details={"payment_id": payment_id})
        return acc, prev_expiry, new_expiry

    async def reject(self, payment_id: str, verifier_id: int, reason: str):
        payment = await self.records.get(payment_id)
        if payment is None:
            raise PaymentError("not_found")
        # Atomic compare-and-swap — see approve() above for why this can't
        # be a plain check-then-write.
        claimed = await self.records.try_transition(payment_id, "pending", "rejected", data={"reject_reason": reason})
        if claimed is None:
            raise PaymentError("not_pending")
        payment = claimed
        await self.audit.log("payment_rejected", verifier_id, details={"payment_id": payment_id, "reason": reason})
        return payment
