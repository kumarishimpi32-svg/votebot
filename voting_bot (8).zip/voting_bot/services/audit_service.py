"""
services/audit_service.py
Every important state change gets an AUDIT record. Never store secrets here.
"""
from __future__ import annotations
from typing import Any
from storage.record_manager import RecordManager


class AuditService:
    def __init__(self, records: RecordManager):
        self.records = records

    async def log(
        self,
        action: str,
        actor_id: int,
        giveaway_id: str | None = None,
        details: dict[str, Any] | None = None,
    ):
        return await self.records.save(
            "AUDIT",
            {
                "action": action,
                "actor_id": actor_id,
                "giveaway_id": giveaway_id,
                "details": details or {},
            },
        )

    async def for_giveaway(self, giveaway_id: str):
        return await self.records.find("AUDIT", giveaway_id=giveaway_id)

    async def global_log(self, limit: int = 50):
        all_logs = await self.records.list("AUDIT")
        return all_logs[-limit:]
