"""
services/ai_moderation.py
AI name moderation via Google Generative AI (Gemini), using the key pool
for failover. Returns one of SAFE / SUSPICIOUS / REJECT / UNCERTAIN.

Per spec section 16/19: if the AI is unavailable, this must NOT blindly
approve — callers route UNCERTAIN to manual review.
"""
from __future__ import annotations
import asyncio
import json
import logging
from enum import Enum

from google import genai

from config import CONFIG
from services.api_pool import ApiKeyPool

logger = logging.getLogger("ai_moderation")

# Transient errors worth one immediate retry on a different key — a 503
# "high demand" or 429 rate-limit is usually momentary and often succeeds
# on a different key/request a moment later, whereas something like an
# invalid/revoked key won't, so there's no point retrying those.
_RETRYABLE_MARKERS = ("UNAVAILABLE", "503", "429", "RESOURCE_EXHAUSTED", "DEADLINE_EXCEEDED")


def _is_retryable(error: str) -> bool:
    return any(marker in error for marker in _RETRYABLE_MARKERS)


MODERATION_PROMPT = """You are a strict but fair content-moderation classifier for \
participant display names in a Telegram giveaway/voting bot. The bot serves users \
worldwide in many languages and scripts.

Classify the given name into exactly one category:
- SAFE: an ordinary, legitimate display name (any language, culture, transliteration).
- SUSPICIOUS: contains something borderline — mild impersonation attempt, ambiguous \
  slur-adjacent term, or something that needs a second look, but isn't clearly abusive.
- REJECT: clearly abusive, hateful, sexually explicit, impersonating officials/support/\
  admin, or otherwise clearly policy-violating.

Do NOT reject a name merely for being uncommon, foreign, historical, or written in a \
non-Latin script. Respond ONLY with strict JSON: {"classification": "SAFE|SUSPICIOUS|REJECT", "reason": "short reason"}

Name to classify: {name}
"""

CHANNEL_CONTENT_PROMPT = """You are a strict but fair content-moderation classifier for messages \
posted in a Telegram giveaway/voting channel. The channel serves users worldwide in many \
languages and scripts.

Classify the given message into exactly one category:
- SAFE: ordinary channel activity (giveaway discussion, votes, congratulations, questions, etc.).
- SUSPICIOUS: contains something borderline that needs a second look, but isn't clearly abusive.
- REJECT: clearly abusive, hateful, sexually explicit, spam/scam links, or otherwise clearly \
  policy-violating content that an admin should review and likely remove.

Do NOT reject a message merely for being off-topic, critical, or written in a non-Latin script. \
Respond ONLY with strict JSON: {"classification": "SAFE|SUSPICIOUS|REJECT", "reason": "short reason"}

Message to classify: {content}
"""


class Classification(str, Enum):
    SAFE = "SAFE"
    SUSPICIOUS = "SUSPICIOUS"
    REJECT = "REJECT"
    UNCERTAIN = "UNCERTAIN"  # AI unavailable / could not confidently classify


class AiModerationService:
    def __init__(self, pool: ApiKeyPool, client_factory=genai.Client):
        """
        client_factory is injectable so tests can supply a fake Gemini
        client instead of making real network calls. Defaults to the real
        google.genai.Client constructor.
        """
        self.pool = pool
        self._client_factory = client_factory

    async def classify_name(self, name: str) -> tuple[Classification, str]:
        if not self.pool.has_keys():
            logger.warning("No Google API keys configured; AI moderation disabled.")
            return Classification.UNCERTAIN, "AI moderation not configured"

        key_status = self.pool.get_available_key()
        if key_status is None:
            return Classification.UNCERTAIN, "All API keys temporarily unavailable"

        prompt = MODERATION_PROMPT.replace("{name}", name)
        tried: list = []
        while True:
            try:
                client = self._client_factory(api_key=key_status.key)
                response = await asyncio.wait_for(
                    client.aio.models.generate_content(model="gemini-2.5-flash", contents=prompt),
                    timeout=CONFIG.ai_moderation_timeout,
                )
                raw = (response.text or "").strip()
                raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
                parsed = json.loads(raw)
                classification = Classification(parsed.get("classification", "SUSPICIOUS"))
                reason = parsed.get("reason", "")
                self.pool.report_success(key_status)
                return classification, reason
            except json.JSONDecodeError:
                self.pool.report_success(key_status)  # model answered, just malformed -> treat as uncertain
                return Classification.UNCERTAIN, "Could not parse AI response"
            except asyncio.TimeoutError:
                # No response within the budget — never let a hung Gemini
                # call hang the whole entry submission. Treated the same
                # as any other transient/overload error: fail this key
                # over to cooldown and try once on a different key.
                err = f"AI request timed out after {CONFIG.ai_moderation_timeout}s (DEADLINE_EXCEEDED)"
                self.pool.report_failure(key_status, err)
                logger.error("AI moderation call timed out for key: %s", key_status.key[:8])
                tried.append(key_status)
                if not tried[1:]:
                    next_key = self.pool.get_available_key(exclude=key_status)
                    if next_key is not None:
                        key_status = next_key
                        continue
                return Classification.UNCERTAIN, "AI request timed out"
            except Exception as e:
                self.pool.report_failure(key_status, str(e))
                logger.error("AI moderation call failed: %s", e)
                tried.append(key_status)
                # One retry on a different key for transient/overload errors only.
                if not tried[1:] and _is_retryable(str(e)):
                    next_key = self.pool.get_available_key(exclude=key_status)
                    if next_key is not None:
                        key_status = next_key
                        continue
                return Classification.UNCERTAIN, "AI request failed"

    async def double_check(self, name: str) -> tuple[Classification, str]:
        """Second pass for SUSPICIOUS results (spec section 17)."""
        classification, reason = await self.classify_name(name)
        # A second SUSPICIOUS verdict routes to manual review, never auto-approve/reject
        if classification == Classification.SUSPICIOUS:
            return Classification.UNCERTAIN, reason
        return classification, reason

    async def classify_text(self, text: str) -> tuple[Classification, str]:
        """Classifies arbitrary free text posted in a managed channel — used
        for channel-content moderation (distinct from participant-name
        moderation above). Same conservative contract: if the AI is
        unavailable, this returns UNCERTAIN rather than pretending the
        content is safe."""
        if not self.pool.has_keys():
            return Classification.UNCERTAIN, "AI moderation not configured"

        key_status = self.pool.get_available_key()
        if key_status is None:
            return Classification.UNCERTAIN, "All API keys temporarily unavailable"

        prompt = CHANNEL_CONTENT_PROMPT.replace("{content}", text)
        tried: list = []
        while True:
            try:
                client = self._client_factory(api_key=key_status.key)
                response = await asyncio.wait_for(
                    client.aio.models.generate_content(model="gemini-2.5-flash", contents=prompt),
                    timeout=CONFIG.ai_moderation_timeout,
                )
                raw = (response.text or "").strip()
                raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
                parsed = json.loads(raw)
                classification = Classification(parsed.get("classification", "SUSPICIOUS"))
                reason = parsed.get("reason", "")
                self.pool.report_success(key_status)
                return classification, reason
            except json.JSONDecodeError:
                self.pool.report_success(key_status)
                return Classification.UNCERTAIN, "Could not parse AI response"
            except asyncio.TimeoutError:
                err = f"AI request timed out after {CONFIG.ai_moderation_timeout}s (DEADLINE_EXCEEDED)"
                self.pool.report_failure(key_status, err)
                logger.error("AI channel-content moderation call timed out for key: %s", key_status.key[:8])
                tried.append(key_status)
                if not tried[1:]:
                    next_key = self.pool.get_available_key(exclude=key_status)
                    if next_key is not None:
                        key_status = next_key
                        continue
                return Classification.UNCERTAIN, "AI request timed out"
            except Exception as e:
                self.pool.report_failure(key_status, str(e))
                logger.error("AI channel-content moderation call failed: %s", e)
                tried.append(key_status)
                if not tried[1:] and _is_retryable(str(e)):
                    next_key = self.pool.get_available_key(exclude=key_status)
                    if next_key is not None:
                        key_status = next_key
                        continue
                return Classification.UNCERTAIN, "AI request failed"
