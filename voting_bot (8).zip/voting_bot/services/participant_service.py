"""
services/participant_service.py
Participant registration + moderation outcome handling (spec 14, 20, 21).
"""
from __future__ import annotations
from storage.record_manager import RecordManager
from services.audit_service import AuditService
from services.moderation_pipeline import ModerationPipeline, ModerationOutcome


class ParticipantService:
    def __init__(self, records: RecordManager, audit: AuditService, moderation: ModerationPipeline):
        self.records = records
        self.audit = audit
        self.moderation = moderation

    # Statuses that mean "this person already has a live entry" — a
    # REJECTED (or superseded) entry must NEVER count as already-joined.
    # This is the fix for the reported bug: a rejected participant was
    # being told "You have already joined the giveaway" because the old
    # already_registered() matched ANY existing record regardless of
    # status, including rejected ones.
    _ACTIVE_STATUSES = {"approved", "pending_review"}

    async def get_active_entry(self, giveaway_id: str, telegram_id: int):
        """Returns the participant's current live entry (pending or
        approved), or None if they have no live entry — a rejected entry
        does not count as live, so this correctly returns None for someone
        free to (re)submit."""
        existing = await self.records.find(
            "PARTICIPANT", giveaway_id=giveaway_id, telegram_id=telegram_id
        )
        for rec in existing:
            if rec.status in self._ACTIVE_STATUSES:
                return rec
        return None

    async def latest_entry(self, giveaway_id: str, telegram_id: int):
        """Returns the most recent entry regardless of status (including a
        rejected one) — used to show a correct REJECTED message with the
        reason, distinct from an 'already joined' message."""
        existing = await self.records.find(
            "PARTICIPANT", giveaway_id=giveaway_id, telegram_id=telegram_id
        )
        return sorted(existing, key=lambda r: r.created_at)[-1] if existing else None

    async def already_registered(self, giveaway_id: str, telegram_id: int) -> bool:
        return await self.get_active_entry(giveaway_id, telegram_id) is not None

    async def register(self, giveaway_id: str, telegram_id: int, name: str):
        if await self.already_registered(giveaway_id, telegram_id):
            return None, "already_registered"

        outcome, reason = await self.moderation.evaluate(name)

        status_map = {
            ModerationOutcome.APPROVE: "approved",
            ModerationOutcome.REJECT: "rejected",
            ModerationOutcome.MANUAL_REVIEW: "pending_review",
        }
        status = status_map[outcome]

        rec = await self.records.save(
            "PARTICIPANT",
            {
                "giveaway_id": giveaway_id,
                "telegram_id": telegram_id,
                "name": name,
                "votes": 0,
                "moderation_reason": reason,
            },
            status=status,
        )
        await self.audit.log(
            f"participant_{status}",
            telegram_id,
            giveaway_id=giveaway_id,
            details={"participant_id": rec.id, "reason": reason},
        )
        return rec, status

    async def approve(self, participant_id: str, reviewer_id: int):
        rec = await self.records.update(participant_id, status="approved")
        await self.audit.log(
            "participant_manual_approve", reviewer_id,
            giveaway_id=rec.data.get("giveaway_id") if rec else None,
            details={"participant_id": participant_id},
        )
        return rec

    async def reject(self, participant_id: str, reviewer_id: int, reason: str = ""):
        rec = await self.records.update(participant_id, status="rejected", data={"reject_reason": reason})
        await self.audit.log(
            "participant_manual_reject", reviewer_id,
            giveaway_id=rec.data.get("giveaway_id") if rec else None,
            details={"participant_id": participant_id, "reason": reason},
        )
        return rec

    async def list_for_giveaway(self, giveaway_id: str, status: str | None = None):
        results = await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)
        if status:
            results = [r for r in results if r.status == status]
        return results
