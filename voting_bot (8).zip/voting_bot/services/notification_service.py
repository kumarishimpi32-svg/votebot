"""
services/notification_service.py
Central place to send user-facing notifications so message text/format
stays consistent and it's easy to add anti-spam throttling later.
"""
from __future__ import annotations
import logging
from telegram import Bot
from telegram.error import TelegramError
from utils.formatting import esc, spoiler_mask

logger = logging.getLogger("notifications")


class NotificationService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def send(self, chat_id: int, text: str, reply_markup=None):
        try:
            await self.bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=reply_markup)
        except TelegramError as e:
            # e.g. user blocked the bot — never crash the caller over this
            logger.info("Notification to %s failed: %s", chat_id, e)

    async def participant_approved(self, user_id: int, giveaway_title: str):
        await self.send(user_id, f"✅ <b>You're in!</b>\nYour entry for <b>{esc(giveaway_title)}</b> was approved.")

    async def participant_rejected(self, user_id: int, giveaway_title: str, reason: str):
        # spoiler_mask, not esc — this can carry an AI moderation reason,
        # and the bot must never plainly state rule-violating content.
        await self.send(user_id, f"❌ <b>Entry not approved</b>\nGiveaway: {esc(giveaway_title)}\nReason: {spoiler_mask(reason)}")

    async def vote_deducted(self, user_id: int, giveaway_title: str):
        await self.send(
            user_id,
            f"⚠️ <b>Vote deducted</b>\nA vote for you in <b>{esc(giveaway_title)}</b> was invalidated "
            f"because the voter left a required channel.",
        )

    async def vote_restored(self, user_id: int, giveaway_title: str):
        await self.send(user_id, f"🔄 <b>Vote restored</b>\nA previously deducted vote for <b>{esc(giveaway_title)}</b> is valid again.")

    async def premium_activated(self, user_id: int, plan_name: str, expires_at_str: str):
        await self.send(
            user_id,
            f"🎉 <b>PREMIUM ACTIVATED</b>\n\n💎 Plan: {esc(plan_name)}\n📅 Expires: {expires_at_str}",
        )

    async def premium_renewed(self, user_id: int, plan_name: str, prev_str: str, new_str: str):
        await self.send(
            user_id,
            f"💎 <b>PREMIUM RENEWED</b>\n\nPrevious expiry: {prev_str}\nNew expiry: {new_str}\nPlan: {esc(plan_name)}",
        )

    async def payment_rejected(self, user_id: int, reason: str):
        await self.send(
            user_id,
            f"❌ <b>PAYMENT REJECTED</b>\n\nYour Premium payment could not be verified.\n"
            f"Reason: {esc(reason)}\n\nPremium has NOT been activated. You may submit a new valid payment.",
        )

    async def premium_expiry_warning(self, user_id: int, days_left: int, expires_at_str: str):
        if days_left <= 1:
            urgency = "⏰"
            headline = "Your Premium expires tomorrow!"
        else:
            urgency = "⚠️"
            headline = f"Your Premium expires in {days_left} days."
        await self.send(
            user_id,
            f"{urgency} <b>PREMIUM EXPIRING SOON</b>\n\n{headline}\nExpires: {expires_at_str}\n\n"
            f"Use /plans to renew and keep your Premium features.",
        )

    async def premium_expired(self, user_id: int):
        await self.send(
            user_id,
            "🔴 <b>PREMIUM EXPIRED</b>\n\nYour Premium has expired and you've been moved to Free features. "
            "Use /plans to renew anytime — your data and history are untouched.",
        )
