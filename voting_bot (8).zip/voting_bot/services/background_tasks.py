"""
services/background_tasks.py
Periodic jobs registered on the PTB JobQueue: giveaway auto-end, membership
monitoring (poll — Telegram has no push event for "user left a channel" a
bot can subscribe to for arbitrary users), premium expiry sweep.
"""
from __future__ import annotations
import time
import logging
from telegram.ext import ContextTypes
from utils.formatting import esc

logger = logging.getLogger("background")


async def job_auto_end_giveaways(context: ContextTypes.DEFAULT_TYPE):
    giveaway_service = context.bot_data["giveaway_service"]
    winner_service = context.bot_data["winner_service"]
    now = time.time()
    active = await giveaway_service.list_active()
    for g in active:
        end_time = g.data.get("end_time")
        if end_time and now >= end_time:
            ended = await giveaway_service.end_giveaway(g.id, actor_id=g.data["host_id"], reason="auto_end_time_reached")
            if ended is None:
                # Already ended (e.g. the host ended it manually moments
                # ago) — winners were already selected/announced there.
                continue
            winners = await winner_service.select_winners(g.id, actor_id=g.data["host_id"])
            if isinstance(winners, list) and winners:
                lines = ["🏆 <b>GIVEAWAY ENDED</b>\n"]
                for w in winners:
                    lines.append(
                        f"🥇 Winner: {esc(w.data['name'])}\n🆔 Telegram ID: <code>{w.data['telegram_id']}</code>\n"
                        f"🗳 Valid Votes: {w.data.get('votes', 0)}"
                    )
                try:
                    await context.bot.send_message(
                        chat_id=g.data["channel_id"], text="\n\n".join(lines), parse_mode="HTML"
                    )
                except Exception as e:
                    logger.warning("Could not announce winners for %s: %s", g.id, e)


async def job_membership_monitor(context: ContextTypes.DEFAULT_TYPE):
    """
    Polls required-channel membership for voters on active giveaways and
    deducts/restores votes accordingly (spec 28-30). This is a poll, not a
    push subscription — Bot API has no "notify me when any user leaves"
    event for channels the bot doesn't own every member's client for.
    """
    giveaway_service = context.bot_data["giveaway_service"]
    vote_service = context.bot_data["vote_service"]
    membership_service = context.bot_data["membership_service"]
    notifications = context.bot_data["notifications"]
    premium_service = context.bot_data["premium_service"]
    contestant_service = context.bot_data.get("contestant_service")

    active = await giveaway_service.list_active()
    for g in active:
        required = g.data.get("required_channels", [])
        if not required:
            continue
        # Membership-based vote deduction/restoration is a Premium host
        # feature — free hosts can still require channel membership to
        # vote in the first place (checked at vote time), but ongoing
        # after-the-fact deduction if someone leaves is Premium-only.
        if not await premium_service.is_active(g.data["host_id"]):
            continue
        votes = await vote_service.records.find("VOTE", giveaway_id=g.id)
        for v in votes:
            if v.status not in ("valid", "deducted"):
                continue
            voter_id = v.data["voter_id"]
            is_member, _ = await membership_service.is_member_of_all(voter_id, required)
            participant_id = v.data["participant_id"]
            if v.status == "valid" and not is_member:
                await vote_service.deduct_for_membership_leave(g.id, voter_id, participant_id)
                # BUG FIX: this used to only ever write the new total to
                # storage — the "Vote - N" button in the giveaway channel
                # kept showing the stale pre-deduction count until
                # someone happened to press Vote again (which edits the
                # message as a side effect). Refresh it explicitly so a
                # voter leaving is reflected in the channel immediately,
                # not just in the DB.
                if contestant_service is not None:
                    await contestant_service.refresh_card(context.bot, participant_id)
                participant = await vote_service.records.get(participant_id)
                if participant:
                    await notifications.vote_deducted(participant.data["telegram_id"], g.data.get("title", ""))
            elif v.status == "deducted" and is_member:
                await vote_service.restore_after_membership_rejoin(g.id, voter_id, participant_id)
                if contestant_service is not None:
                    await contestant_service.refresh_card(context.bot, participant_id)
                participant = await vote_service.records.get(participant_id)
                if participant:
                    await notifications.vote_restored(participant.data["telegram_id"], g.data.get("title", ""))


async def job_premium_expiry(context: ContextTypes.DEFAULT_TYPE):
    premium_service = context.bot_data["premium_service"]
    notifications = context.bot_data["notifications"]

    newly_expired = await premium_service.check_and_expire_all()
    for acc in newly_expired:
        try:
            await notifications.premium_expired(acc.data["user_id"])
        except Exception as e:
            logger.warning("Could not notify user %s of expiry: %s", acc.data.get("user_id"), e)


async def job_premium_expiry_warnings(context: ContextTypes.DEFAULT_TYPE):
    """Spec 52: warn at 7/3/1 days before expiry, without spamming or firing
    stale warnings after a renewal (handled in PremiumService)."""
    premium_service = context.bot_data["premium_service"]
    notifications = context.bot_data["notifications"]

    from utils.formatting import fmt_time
    import time as _time

    due = await premium_service.accounts_needing_expiry_warning()
    for acc, threshold, covered in due:
        remaining_days = max(1, round((acc.data.get("expires_at", 0) - _time.time()) / 86400))
        try:
            await notifications.premium_expiry_warning(
                acc.data["user_id"], remaining_days, fmt_time(acc.data.get("expires_at"))
            )
        except Exception as e:
            logger.warning("Could not send expiry warning to %s: %s", acc.data.get("user_id"), e)
        await premium_service.mark_warned(acc.id, covered)


def register_jobs(application) -> None:
    jq = application.job_queue
    jq.run_repeating(job_auto_end_giveaways, interval=60, first=10, name="auto_end_giveaways")
    jq.run_repeating(job_membership_monitor, interval=300, first=30, name="membership_monitor")
    jq.run_repeating(job_premium_expiry, interval=3600, first=60, name="premium_expiry")
    jq.run_repeating(job_premium_expiry_warnings, interval=21600, first=90, name="premium_expiry_warnings")
