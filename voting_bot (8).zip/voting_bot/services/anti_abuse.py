"""
services/anti_abuse.py
Rate limiting, callback replay protection, rapid-vote / rapid-join-leave
detection (spec section 31). Honest limitation: the bot cannot know
whether two different Telegram accounts belong to the same real person —
this only detects abuse patterns from a SINGLE account's behavior.
"""
from __future__ import annotations
import time
from collections import defaultdict, deque
from storage.cache import RateLimiter, ReplayGuard


class AntiAbuseService:
    def __init__(self):
        self.vote_limiter = RateLimiter(max_calls=5, per_seconds=10)
        self.registration_limiter = RateLimiter(max_calls=3, per_seconds=60)
        self.ai_limiter = RateLimiter(max_calls=20, per_seconds=60)
        self.export_limiter = RateLimiter(max_calls=3, per_seconds=300)
        self.payment_limiter = RateLimiter(max_calls=5, per_seconds=300)
        self.channel_connect_limiter = RateLimiter(max_calls=5, per_seconds=60)
        self.replay_guard = ReplayGuard()
        self._join_leave_events: dict[int, deque] = defaultdict(deque)

    def allow_vote(self, user_id: int) -> bool:
        return self.vote_limiter.allow(f"vote:{user_id}")

    def allow_registration(self, user_id: int) -> bool:
        return self.registration_limiter.allow(f"reg:{user_id}")

    def allow_ai_call(self, scope: str = "global") -> bool:
        return self.ai_limiter.allow(f"ai:{scope}")

    def allow_export(self, user_id: int) -> bool:
        return self.export_limiter.allow(f"export:{user_id}")

    def allow_payment_submission(self, user_id: int) -> bool:
        return self.payment_limiter.allow(f"pay:{user_id}")

    def allow_channel_connect(self, user_id: int) -> bool:
        """Each attempt costs 1-3 live Telegram API calls (get_chat +
        get_chat_member x2) — without a cap, repeated Add Channel
        submissions become a cheap way to burn API quota/rate limits."""
        return self.channel_connect_limiter.allow(f"chconnect:{user_id}")

    def is_replay(self, callback_query_id: str) -> bool:
        return self.replay_guard.seen_before(callback_query_id)

    def record_join_leave(self, user_id: int) -> bool:
        """Returns True if this user is flapping join/leave suspiciously fast."""
        now = time.time()
        bucket = self._join_leave_events[user_id]
        bucket.append(now)
        while bucket and now - bucket[0] > 3600:
            bucket.popleft()
        return len(bucket) >= 6  # 6 join/leave events within an hour = suspicious
