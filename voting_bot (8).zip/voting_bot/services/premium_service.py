"""
services/premium_service.py
Premium plans, activation, renewal (add-to-existing-expiry), expiry
monitoring, manual owner grant/revoke (spec 37-38, 48-57, 62).
"""
from __future__ import annotations
import time
from storage.record_manager import RecordManager
from services.audit_service import AuditService

DAY_SECONDS = 86400


class PremiumService:
    def __init__(self, records: RecordManager, audit: AuditService):
        self.records = records
        self.audit = audit

    # ---------------- Plans ----------------
    async def create_plan(self, actor_id: int, plan_id: str, name: str, duration_days: int,
                           price_inr: int, description: str = "", features: list[str] | None = None):
        rec = await self.records.save(
            "PREMIUM_PLAN",
            {
                "plan_id": plan_id,
                "name": name,
                "duration_days": duration_days,
                "price_inr": price_inr,
                "description": description,
                "features": features or [],
                "active": True,
            },
        )
        await self.audit.log("premium_plan_created", actor_id, details={"plan_id": plan_id})
        return rec

    async def list_active_plans(self):
        plans = await self.records.list("PREMIUM_PLAN")
        return [p for p in plans if p.data.get("active")]

    async def get_plan(self, plan_id: str):
        return await self.records.find_one("PREMIUM_PLAN", plan_id=plan_id)

    async def set_plan_active(self, actor_id: int, plan_record_id: str, active: bool):
        rec = await self.records.update(plan_record_id, data={"active": active})
        await self.audit.log("premium_plan_toggled", actor_id, details={"plan_record_id": plan_record_id, "active": active})
        return rec

    # ---------------- Account status ----------------
    async def get_account(self, user_id: int):
        return await self.records.find_one("PREMIUM_ACCOUNT", user_id=user_id)

    async def is_active(self, user_id: int) -> bool:
        acc = await self.get_account(user_id)
        if acc is None:
            return False
        return acc.data.get("expires_at", 0) > time.time()

    async def activate_or_extend(self, user_id: int, actor_id: int, duration_days: int,
                                  source: str, plan_id: str | None = None):
        """
        Spec 48-49: fresh activation starts now; existing active premium
        extends from current expiry (never loses remaining time).
        """
        acc = await self.get_account(user_id)
        now = time.time()
        added_seconds = duration_days * DAY_SECONDS

        if acc is None:
            new_expiry = now + added_seconds
            rec, created = await self.records.save_if_unique(
                "PREMIUM_ACCOUNT", {"user_id": user_id},
                {"user_id": user_id, "started_at": now, "expires_at": new_expiry, "plan_id": plan_id},
            )
            if not created:
                # Lost the race: another concurrent activation already
                # created the account moments ago. Fall through to the
                # extend path below against what actually exists now,
                # rather than silently leaving a second orphaned record.
                acc = rec
                previous_expiry = acc.data.get("expires_at", now)
                base = previous_expiry if previous_expiry > now else now
                new_expiry = base + added_seconds
                updated = await self.records.update(
                    acc.id, data={"expires_at": new_expiry, "plan_id": plan_id}, status="active",
                )
                rec = updated or acc
                event = "premium_renewed" if previous_expiry > now else "premium_activated"
            else:
                event = "premium_activated"
                previous_expiry = None
        else:
            previous_expiry = acc.data.get("expires_at", now)
            base = previous_expiry if previous_expiry > now else now
            new_expiry = base + added_seconds
            # BUG FIX: must also reset status back to "active" here, not
            # just bump expires_at. check_and_expire_all() flips status to
            # "expired" once an account lapses, and update_record() leaves
            # status untouched unless explicitly passed. Without this, a
            # host who lets Premium lapse and then renews keeps a
            # permanently-stuck status="expired" record: is_active() still
            # reads correctly off expires_at so access itself isn't
            # affected, but accounts_needing_expiry_warning() (which
            # filters on status="active") would silently stop sending
            # 7/3/1-day warnings for that user forever, and
            # check_and_expire_all()'s `status != "expired"` guard would
            # never fire again on their NEXT expiry either — so a renewed
            # user's second expiry would go completely unnotified.
            updated = await self.records.update(
                acc.id, data={"expires_at": new_expiry, "plan_id": plan_id, "warned_thresholds": []},
                status="active",
            )
            if updated is None:
                # Defensive: the account record vanished between read and
                # write (should not happen under the single-process lock,
                # but never silently proceed with a stale reference).
                raise RuntimeError(f"Premium account record {acc.id} disappeared during update")
            rec = updated
            event = "premium_renewed" if previous_expiry > now else "premium_activated"

        await self.audit.log(
            event, actor_id, details={
                "user_id": user_id, "duration_days": duration_days, "source": source,
                "previous_expiry": previous_expiry, "new_expiry": new_expiry,
            },
        )
        return rec, previous_expiry, new_expiry

    async def revoke(self, user_id: int, actor_id: int, reason: str = ""):
        acc = await self.get_account(user_id)
        if acc is None:
            return None
        rec = await self.records.update(acc.id, data={"expires_at": time.time()})
        await self.audit.log("premium_revoked", actor_id, details={"user_id": user_id, "reason": reason})
        return rec

    async def check_and_expire_all(self):
        """Called by background task (spec 51)."""
        accounts = await self.records.list("PREMIUM_ACCOUNT")
        now = time.time()
        newly_expired = []
        for acc in accounts:
            if acc.data.get("expires_at", 0) <= now and acc.status != "expired":
                await self.records.update(acc.id, status="expired")
                newly_expired.append(acc)
        return newly_expired

    async def accounts_needing_expiry_warning(self, thresholds_days: tuple[int, ...] = (7, 3, 1)):
        """
        Spec 52: warn at 7/3/1 days before expiry, avoiding spam and avoiding
        outdated warnings if the user already renewed. Returns a list of
        (account, threshold_to_send, thresholds_to_mark_covered) tuples.

        If multiple thresholds have already been crossed by the time a sweep
        runs (e.g. a short-duration plan, or the job was down for a while),
        we send only the single most urgent/accurate one — but mark ALL
        crossed thresholds as covered, so a stale "7 days left" notice never
        goes out after we've already told the user "1 day left".
        """
        accounts = await self.records.list("PREMIUM_ACCOUNT", status="active")
        now = time.time()
        due = []
        for acc in accounts:
            expires_at = acc.data.get("expires_at", 0)
            if expires_at <= now:
                continue
            remaining_days = (expires_at - now) / DAY_SECONDS
            already_warned = set(acc.data.get("warned_thresholds", []))
            crossed = sorted(t for t in thresholds_days if remaining_days <= t)
            uncovered = [t for t in crossed if t not in already_warned]
            if uncovered:
                most_urgent = uncovered[0]  # smallest = most urgent/accurate
                due.append((acc, most_urgent, crossed))
        return due

    async def mark_warned(self, account_record_id: str, thresholds_covered: list[int] | int):
        acc = await self.records.get(account_record_id)
        if acc is None:
            return
        if isinstance(thresholds_covered, int):
            thresholds_covered = [thresholds_covered]
        warned = list(set(acc.data.get("warned_thresholds", [])) | set(thresholds_covered))
        await self.records.update(account_record_id, data={"warned_thresholds": warned})
