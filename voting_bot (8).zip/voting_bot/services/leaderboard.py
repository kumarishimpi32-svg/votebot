"""
services/leaderboard.py
Free (top ranking) vs Premium (historical, growth, filtering) leaderboards.
"""
from __future__ import annotations
from storage.record_manager import RecordManager
from utils.formatting import leaderboard_header, esc
from utils.premium_style import badge

MEDALS = ["🥇", "🥈", "🥉"]


class LeaderboardService:
    def __init__(self, records: RecordManager):
        self.records = records

    async def top(self, giveaway_id: str, limit: int = 10):
        participants = await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)
        approved = [p for p in participants if p.status == "approved"]
        ranked = sorted(approved, key=lambda p: p.data.get("votes", 0), reverse=True)
        return ranked[:limit]

    def format_free(self, ranked) -> str:
        lines = [leaderboard_header(premium=False), ""]
        for i, p in enumerate(ranked):
            medal = MEDALS[i] if i < 3 else f"{i + 1}."
            lines.append(f"{medal} <b>{esc(p.data.get('name'))}</b> — {badge(str(p.data.get('votes', 0)))}")
        return "\n".join(lines) if len(ranked) else leaderboard_header(premium=False) + "\n\nNo participants yet."

    async def premium_stats(self, giveaway_id: str):
        """Advanced ranking with vote-growth using vote timestamps."""
        votes = await self.records.find("VOTE", giveaway_id=giveaway_id)
        participants = {p.id: p for p in await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)}
        growth: dict[str, list[float]] = {}
        for v in votes:
            if v.status != "valid":
                continue
            growth.setdefault(v.data["participant_id"], []).append(v.created_at)
        stats = []
        for pid, p in participants.items():
            timestamps = sorted(growth.get(pid, []))
            stats.append(
                {
                    "name": p.data.get("name"),
                    "votes": p.data.get("votes", 0),
                    "first_vote_at": timestamps[0] if timestamps else None,
                    "last_vote_at": timestamps[-1] if timestamps else None,
                    "vote_timestamps": timestamps,
                }
            )
        return sorted(stats, key=lambda s: s["votes"], reverse=True)
