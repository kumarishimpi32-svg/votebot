"""
services/image_moderation.py
Optional Premium image/content protection (spec 63-64). Downloads a
Telegram photo via the Bot API (a fully supported operation) and asks
Gemini's vision model to classify it. Conservative: only a clear REJECT
triggers moderation action, and only if the bot actually has permission
to delete/restrict in that chat — never attempts to bypass Telegram
permissions.
"""
from __future__ import annotations
import logging
from telegram import Bot, File as TgFile
from google import genai
from google.genai import types as genai_types
from services.api_pool import ApiKeyPool
from services.ai_moderation import Classification, _is_retryable

logger = logging.getLogger("image_moderation")

IMAGE_PROMPT = """Classify this image for a public giveaway/voting bot's participant \
content. Respond ONLY with strict JSON: {"classification": "SAFE|SUSPICIOUS|REJECT", "reason": "short reason"}
REJECT = clearly prohibited (explicit sexual content, graphic violence, hate symbols).
SUSPICIOUS = borderline, needs human review.
SAFE = ordinary content."""


class ImageModerationService:
    def __init__(self, bot: Bot, pool: ApiKeyPool, client_factory=genai.Client):
        self.bot = bot
        self.pool = pool
        self._client_factory = client_factory

    async def classify_photo(self, file_id: str) -> tuple[Classification, str]:
        if not self.pool.has_keys():
            return Classification.UNCERTAIN, "AI moderation not configured"
        key_status = self.pool.get_available_key()
        if key_status is None:
            return Classification.UNCERTAIN, "All API keys temporarily unavailable"

        try:
            tg_file: TgFile = await self.bot.get_file(file_id)
            image_bytes = bytes(await tg_file.download_as_bytearray())
        except Exception as e:
            logger.error("Image moderation download failed: %s", e)
            return Classification.UNCERTAIN, "Could not download image"

        import json
        tried: list = []
        while True:
            try:
                client = self._client_factory(api_key=key_status.key)
                response = await client.aio.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=[
                        IMAGE_PROMPT,
                        genai_types.Part.from_bytes(data=image_bytes, mime_type="image/jpeg"),
                    ],
                )
                raw = (response.text or "").strip()
                raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
                parsed = json.loads(raw)
                classification = Classification(parsed.get("classification", "SUSPICIOUS"))
                self.pool.report_success(key_status)
                return classification, parsed.get("reason", "")
            except Exception as e:
                self.pool.report_failure(key_status, str(e))
                logger.error("Image moderation failed: %s", e)
                tried.append(key_status)
                if not tried[1:] and _is_retryable(str(e)):
                    next_key = self.pool.get_available_key(exclude=key_status)
                    if next_key is not None:
                        key_status = next_key
                        continue
                return Classification.UNCERTAIN, "AI request failed"
