"""
services/api_pool.py
Manages up to 40 Google AI API keys (see config.py: GOOGLE_API_KEY_1..40)
for reliability/failover ONLY. This does not and must not be used to
bypass Google's quotas, rate limits, or billing/ToS — it just picks a
healthy key at random so one exhausted/cooling-down/invalid key doesn't
take moderation offline. Nothing below is hardcoded to any particular
count: the pool just works with however many keys config.py hands it.
"""
from __future__ import annotations
import random
import time
from dataclasses import dataclass


@dataclass
class KeyStatus:
    key: str
    healthy: bool = True
    cooldown_until: float = 0.0
    last_success: float | None = None
    last_error: str | None = None

    def label(self) -> str:
        # never expose the actual key
        return f"key_ending_{self.key[-4:]}" if len(self.key) >= 4 else "key_***"


class ApiKeyPool:
    def __init__(self, keys: list[str]):
        self._statuses: list[KeyStatus] = [KeyStatus(key=k) for k in keys]

    def has_keys(self) -> bool:
        return len(self._statuses) > 0

    def get_available_key(self, exclude: "KeyStatus | None" = None) -> KeyStatus | None:
        now = time.time()
        available = [
            s for s in self._statuses
            if s.healthy and s.cooldown_until <= now and s is not exclude
        ]
        if not available:
            return None
        return random.choice(available)

    def report_success(self, status: KeyStatus) -> None:
        status.healthy = True
        status.cooldown_until = 0.0
        status.last_success = time.time()
        status.last_error = None

    def report_failure(self, status: KeyStatus, error: str, cooldown_seconds: int = 60) -> None:
        status.last_error = error
        status.cooldown_until = time.time() + cooldown_seconds
        # After repeated cooldowns in a row it stays "healthy" but cooling;
        # only mark unhealthy on clearly permanent errors (e.g. invalid key).
        if "API_KEY_INVALID" in error or "PERMISSION_DENIED" in error:
            status.healthy = False

    def health_report(self) -> dict:
        now = time.time()
        return {
            "configured_keys": len(self._statuses),
            "healthy": sum(1 for s in self._statuses if s.healthy and s.cooldown_until <= now),
            "cooldown": sum(1 for s in self._statuses if s.cooldown_until > now),
            "unhealthy": sum(1 for s in self._statuses if not s.healthy),
            "keys": [
                {
                    "label": s.label(),
                    "healthy": s.healthy,
                    "cooldown_remaining": max(0, round(s.cooldown_until - now)),
                    "last_success": s.last_success,
                    "last_error": s.last_error,
                }
                for s in self._statuses
            ],
        }
