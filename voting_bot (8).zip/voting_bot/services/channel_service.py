"""
services/channel_service.py

Multi-channel CONNECT system (mega-prompt Phase 2 / spec §5, §6, §9-§14).

Every host can connect one or more Telegram channels they administer.
Nothing here ever trusts client-supplied state:
  - "Is the bot actually in this channel?" is checked live via
    Bot.get_chat_member(chat_id, bot.id) at connect time AND at every
    re-verification — never assumed from a prior successful connect.
  - "Is the requesting user actually an admin of this channel?" is checked
    live via Bot.get_chat_member(chat_id, user_id) — a user can never
    connect a channel they don't themselves administer, which is what
    stops User A from claiming/hijacking User B's channel by guessing or
    supplying its numeric id.
  - Ownership of an already-connected CHANNEL record is re-checked from
    the stored record itself on every protected operation (see
    security.permissions.Permissions.is_channel_owner) — never from
    callback_data, which only ever carries the internal record id.

Data model: one CHANNEL record per connected Telegram channel, keyed
uniquely on chat_id (storage.save_if_unique) so the same channel can never
be connected twice. A separate lightweight USER record stores which of a
host's channels is currently "active" (the one new giveaways/leaderboards/
banned-word edits apply to), so switching the active channel is a single
atomic record update and never touches another host's data.
"""
from __future__ import annotations
import logging
import time
from dataclasses import dataclass
from typing import Any

from telegram import Bot
from telegram.error import TelegramError, Forbidden, BadRequest

from storage.record_manager import RecordManager
from services.audit_service import AuditService

logger = logging.getLogger("channel_service")

# Permissions the bot needs on a channel to actually run giveaways there:
# posting the announcement/leaderboard cards and editing them in place
# (live participant count, vote-count refresh) rather than re-sending.
REQUIRED_BOT_PERMISSIONS = ("can_post_messages", "can_edit_messages")


class ChannelError(Exception):
    """Raised with a stable `code` the handler maps to user-facing text.

    Codes: invalid_input, not_found, not_a_channel, requester_not_admin,
    bot_absent, bot_not_admin, missing_permissions, already_connected_self,
    already_connected_other.
    """
    def __init__(self, code: str, detail: str = ""):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


@dataclass
class VerificationResult:
    bot_present: bool
    bot_is_admin: bool
    missing_permissions: list[str]
    chat_id: int | None = None
    chat_title: str | None = None
    chat_username: str | None = None

    @property
    def ok(self) -> bool:
        return self.bot_present and self.bot_is_admin and not self.missing_permissions


def _normalize_channel_ref(raw: str) -> str:
    """Accepts '@name', 'name', 'https://t.me/name', or a numeric chat id
    string and returns whatever the Bot API expects as a chat_id value."""
    raw = (raw or "").strip()
    if raw.startswith("https://t.me/"):
        raw = raw[len("https://t.me/"):]
    elif raw.startswith("http://t.me/"):
        raw = raw[len("http://t.me/"):]
    raw = raw.split("?")[0].strip("/")
    if not raw:
        return raw
    if raw.lstrip("-").isdigit():
        return raw
    return raw if raw.startswith("@") else f"@{raw}"


class ChannelService:
    def __init__(self, bot: Bot, records: RecordManager, audit: AuditService):
        self.bot = bot
        self.records = records
        self.audit = audit

    # ------------------------------------------------------------------
    # Live Telegram verification — never assumed, always re-checked
    # ------------------------------------------------------------------
    async def _verify_live(self, chat_id: int | str) -> VerificationResult:
        try:
            member = await self.bot.get_chat_member(chat_id=chat_id, user_id=self.bot.id)
        except Forbidden:
            # Bot API returns Forbidden when the bot isn't a member at all
            # (or was kicked) — treat identically to "not present".
            return VerificationResult(bot_present=False, bot_is_admin=False, missing_permissions=[])
        except BadRequest:
            return VerificationResult(bot_present=False, bot_is_admin=False, missing_permissions=[])
        except TelegramError as e:
            logger.warning("Transient error verifying bot membership on %s: %s", chat_id, e)
            return VerificationResult(bot_present=False, bot_is_admin=False, missing_permissions=[])

        is_admin = member.status in ("administrator", "creator")
        missing: list[str] = []
        if is_admin and member.status == "administrator":
            for perm in REQUIRED_BOT_PERMISSIONS:
                if not getattr(member, perm, False):
                    missing.append(perm)
        elif is_admin and member.status == "creator":
            pass  # the channel creator implicitly has every permission
        return VerificationResult(bot_present=True, bot_is_admin=is_admin, missing_permissions=missing)

    async def _requester_is_channel_admin(self, chat_id: int | str, user_id: int) -> bool:
        try:
            member = await self.bot.get_chat_member(chat_id=chat_id, user_id=user_id)
            return member.status in ("administrator", "creator")
        except TelegramError:
            return False

    # ------------------------------------------------------------------
    # Add Channel
    # ------------------------------------------------------------------
    async def add_channel(self, owner_id: int, raw_ref: str):
        """Returns the CHANNEL Record on success. Raises ChannelError on
        any validation/verification failure — never partially saves a
        channel that failed verification."""
        ref = _normalize_channel_ref(raw_ref)
        if not ref:
            raise ChannelError("invalid_input", "Empty channel reference.")

        chat_id_arg: int | str = int(ref) if ref.lstrip("-").isdigit() else ref

        try:
            chat = await self.bot.get_chat(chat_id=chat_id_arg)
        except TelegramError as e:
            raise ChannelError("not_found", str(e))

        if chat.type not in ("channel",):
            raise ChannelError("not_a_channel", f"'{chat.type}' is not a channel.")

        # The requesting user must themselves currently administer the
        # channel — this is what stops connecting someone else's channel
        # by supplying its @username or numeric id.
        if not await self._requester_is_channel_admin(chat.id, owner_id):
            raise ChannelError("requester_not_admin")

        verification = await self._verify_live(chat.id)
        if not verification.bot_present:
            raise ChannelError("bot_absent")
        if not verification.bot_is_admin:
            raise ChannelError("bot_not_admin")
        if verification.missing_permissions:
            raise ChannelError("missing_permissions", ",".join(verification.missing_permissions))

        rec, created = await self.records.save_if_unique(
            "CHANNEL",
            unique_fields={"chat_id": chat.id},
            data={
                "owner_id": owner_id,
                "chat_id": chat.id,
                "title": chat.title or chat.username or str(chat.id),
                "username": chat.username,
                "verified": True,
                "last_verified_at": time.time(),
            },
            status="active",
        )
        if not created:
            if rec.data.get("owner_id") == owner_id:
                raise ChannelError("already_connected_self")
            raise ChannelError("already_connected_other")

        await self.audit.log("channel_connected", owner_id, details={"channel_id": rec.id, "chat_id": chat.id})
        return rec

    # ------------------------------------------------------------------
    # My Channels / lookups
    # ------------------------------------------------------------------
    async def list_for_owner(self, owner_id: int):
        chans = await self.records.find("CHANNEL", owner_id=owner_id)
        return [c for c in chans if c.status == "active"]

    async def get(self, channel_record_id: str):
        rec = await self.records.get(channel_record_id)
        if rec is None or rec.type != "CHANNEL" or rec.status != "active":
            return None
        return rec

    async def get_owned(self, channel_record_id: str, owner_id: int):
        """Returns the record only if it exists, is active, AND belongs to
        owner_id — the single call every protected handler should use
        instead of trusting a bare `get()`."""
        rec = await self.get(channel_record_id)
        if rec is None or rec.data.get("owner_id") != owner_id:
            return None
        return rec

    # ------------------------------------------------------------------
    # Re-verification (presence/admin status/permissions can change after
    # the initial connect — e.g. the bot is demoted or removed later)
    # ------------------------------------------------------------------
    async def reverify(self, channel_record_id: str, owner_id: int):
        rec = await self.get_owned(channel_record_id, owner_id)
        if rec is None:
            raise ChannelError("not_found")
        verification = await self._verify_live(rec.data["chat_id"])
        updated = await self.records.update(
            channel_record_id,
            data={
                "verified": verification.ok,
                "last_verified_at": time.time(),
                "last_missing_permissions": verification.missing_permissions,
            },
        )
        return updated, verification

    # ------------------------------------------------------------------
    # Remove/disconnect — lets a host drop a connected channel (spec:
    # "the user can remove the verification/main channel ... and can
    # add his channel"). Soft-delete only: the CHANNEL record's status
    # flips to 'removed' rather than being erased, so audit history and
    # any giveaway that already ran there stay intact.
    # ------------------------------------------------------------------
    async def remove_channel(self, owner_id: int, channel_record_id: str):
        """Raises ChannelError('not_found') if the channel doesn't exist,
        isn't active, or isn't owned by owner_id. If it was the host's
        active channel, clears that pointer too so a stale id is never
        left behind pointing at a removed channel."""
        rec = await self.get_owned(channel_record_id, owner_id)
        if rec is None:
            raise ChannelError("not_found")

        updated = await self.records.update(channel_record_id, status="removed")

        user_rec = await self.records.find_one("USER", user_id=owner_id)
        if user_rec is not None and user_rec.data.get("active_channel_id") == channel_record_id:
            await self.records.update(user_rec.id, data={"active_channel_id": None})

        await self.audit.log("channel_removed", owner_id, details={"channel_id": channel_record_id})
        return updated or rec

    # ------------------------------------------------------------------
    # Active channel — per-host pointer, isolated from every other host
    # ------------------------------------------------------------------
    async def get_active_channel(self, owner_id: int):
        user_rec = await self.records.find_one("USER", user_id=owner_id)
        if user_rec is None:
            return None
        active_id = user_rec.data.get("active_channel_id")
        if not active_id:
            return None
        return await self.get_owned(active_id, owner_id)

    async def set_active_channel(self, owner_id: int, channel_record_id: str):
        """Raises ChannelError('not_found') if the channel doesn't exist,
        isn't active, or isn't owned by owner_id — never lets one host's
        active-channel pointer be set to another host's channel."""
        rec = await self.get_owned(channel_record_id, owner_id)
        if rec is None:
            raise ChannelError("not_found")

        # Re-verify before switching — a channel that passed verification
        # at connect time may have lost bot admin rights since (spec 2.5).
        verification = await self._verify_live(rec.data["chat_id"])
        await self.records.update(
            channel_record_id,
            data={
                "verified": verification.ok,
                "last_verified_at": time.time(),
                "last_missing_permissions": verification.missing_permissions,
            },
        )
        if not verification.ok:
            raise ChannelError(
                "bot_not_admin" if verification.bot_present else "bot_absent",
                ",".join(verification.missing_permissions),
            )

        user_rec = await self.records.find_one("USER", user_id=owner_id)
        if user_rec is None:
            await self.records.save("USER", {"user_id": owner_id, "active_channel_id": channel_record_id}, status="active")
        else:
            await self.records.update(user_rec.id, data={"active_channel_id": channel_record_id})

        await self.audit.log("active_channel_changed", owner_id, details={"channel_id": channel_record_id})
        return rec
