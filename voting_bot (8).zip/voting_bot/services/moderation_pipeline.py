"""
services/moderation_pipeline.py
Implements the exact flow from spec section 14/16/17:
local filter -> AI check -> (suspicious) second AI check -> manual review.
"""
from __future__ import annotations
from enum import Enum
from services.name_filter import NameFilter
from services.ai_moderation import AiModerationService, Classification


class ModerationOutcome(str, Enum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    MANUAL_REVIEW = "MANUAL_REVIEW"


class ModerationPipeline:
    def __init__(self, name_filter: NameFilter, ai: AiModerationService):
        self.name_filter = name_filter
        self.ai = ai

    async def evaluate(self, name: str) -> tuple[ModerationOutcome, str]:
        if self.name_filter.is_blocked(name):
            return ModerationOutcome.REJECT, "Blocked by local name filter"

        first, reason1 = await self.ai.classify_name(name)

        if first == Classification.SAFE:
            return ModerationOutcome.APPROVE, reason1
        if first == Classification.REJECT:
            return ModerationOutcome.REJECT, reason1
        if first == Classification.UNCERTAIN:
            # AI unavailable/unclear -> never blindly approve, go to manual review
            return ModerationOutcome.MANUAL_REVIEW, reason1

        # SUSPICIOUS -> second check
        second, reason2 = await self.ai.double_check(name)
        if second == Classification.SAFE:
            return ModerationOutcome.APPROVE, reason2
        if second == Classification.REJECT:
            return ModerationOutcome.REJECT, reason2
        return ModerationOutcome.MANUAL_REVIEW, reason2
