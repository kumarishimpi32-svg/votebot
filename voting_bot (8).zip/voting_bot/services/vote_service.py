"""
services/vote_service.py
Implements spec sections 22-31, 24-26: voting, self-voting, anti-multi-vote,
host add/remove vote, undo, vote deduction/restoration on membership change.
"""
from __future__ import annotations
from storage.record_manager import RecordManager
from services.audit_service import AuditService


class VoteError(Exception):
    pass


class VoteService:
    def __init__(self, records: RecordManager, audit: AuditService):
        self.records = records
        self.audit = audit

    # ------------------------------------------------------------------
    # Normal voting
    # ------------------------------------------------------------------
    async def has_voted(self, giveaway_id: str, voter_id: int) -> bool:
        """One vote per voter PER GIVEAWAY (not per participant) — a voter
        who already voted for one contestant cannot then also vote for a
        different contestant in the same giveaway."""
        existing = await self.records.find_one(
            "VOTE", giveaway_id=giveaway_id, voter_id=voter_id
        )
        return existing is not None and existing.status == "valid"

    async def _get_scoped_participant(self, giveaway_id: str, participant_id: str):
        """Loophole close: callback_data (and /addvote's typed participant_id)
        both carry a giveaway_id and a participant_id as two SEPARATE, unlinked
        values. Without this check, nothing stops a forged callback_query — or
        a host running /addvote with a participant_id copied from someone
        else's giveaway — from crediting votes to a participant who doesn't
        actually belong to that giveaway, or who was never approved. Every
        vote mutation must go through here rather than trusting the pair as
        given."""
        participant = await self.records.get(participant_id)
        if participant is None or participant.type != "PARTICIPANT":
            return None
        if participant.data.get("giveaway_id") != giveaway_id:
            return None
        return participant

    async def cast_vote(self, giveaway_id: str, participant_id: str, voter_id: int):
        """
        One voter gets exactly ONE vote per giveaway, for exactly one
        contestant, and self-voting is disabled (a participant cannot vote
        for their own entry).

        Uses an atomic find-or-create keyed on (giveaway_id, voter_id) —
        NOT (giveaway_id, participant_id, voter_id) as before, which
        wrongly allowed the same voter to cast one vote per contestant
        instead of one vote for the whole giveaway. A plain check-then-write
        here would also let two near-simultaneous vote presses from the
        same voter (e.g. a rapid double-tap producing two distinct
        callback_query ids, which the replay guard does not catch) both
        pass the "not voted yet" check before either write landed,
        recording a duplicate vote.
        """
        participant = await self._get_scoped_participant(giveaway_id, participant_id)
        if participant is None:
            raise VoteError("invalid_participant")
        if participant.status != "approved":
            # Blocks voting for a still-pending or already-rejected entry —
            # a forged/replayed callback pointing at one of those must not
            # count, even if the giveaway_id/participant_id pair is real.
            raise VoteError("not_approved")
        if participant.data.get("telegram_id") == voter_id:
            raise VoteError("self_vote")

        vote, created = await self.records.save_if_unique(
            "VOTE",
            unique_fields={
                "giveaway_id": giveaway_id,
                "voter_id": voter_id,
            },
            data={
                "giveaway_id": giveaway_id,
                "participant_id": participant_id,
                "voter_id": voter_id,
                "kind": "NORMAL",
            },
            status="valid",
        )
        if not created:
            raise VoteError("already_voted")

        await self._bump_participant_votes(participant_id, +1)
        await self.audit.log(
            "vote_cast", voter_id, giveaway_id=giveaway_id,
            details={"participant_id": participant_id, "vote_id": vote.id},
        )
        return vote

    # ------------------------------------------------------------------
    # Host manual votes (spec 24-26)
    # ------------------------------------------------------------------
    async def add_manual_vote(self, giveaway_id: str, participant_id: str, host_id: int, amount: int):
        if amount <= 0:
            raise VoteError("invalid_amount")
        if await self._get_scoped_participant(giveaway_id, participant_id) is None:
            raise VoteError("invalid_participant")
        vote = await self.records.save(
            "MANUAL_VOTE",
            {
                "giveaway_id": giveaway_id,
                "participant_id": participant_id,
                "host_id": host_id,
                "amount": amount,
                "direction": "ADD",
            },
            status="valid",
        )
        await self._bump_participant_votes(participant_id, amount)
        await self.audit.log(
            "manual_vote_add", host_id, giveaway_id=giveaway_id,
            details={"participant_id": participant_id, "amount": amount, "vote_id": vote.id},
        )
        return vote

    async def remove_manual_vote(self, giveaway_id: str, participant_id: str, host_id: int, amount: int):
        if amount <= 0:
            raise VoteError("invalid_amount")
        if await self._get_scoped_participant(giveaway_id, participant_id) is None:
            raise VoteError("invalid_participant")
        vote = await self.records.save(
            "MANUAL_VOTE",
            {
                "giveaway_id": giveaway_id,
                "participant_id": participant_id,
                "host_id": host_id,
                "amount": amount,
                "direction": "REMOVE",
            },
            status="valid",
        )
        await self._bump_participant_votes(participant_id, -amount)
        await self.audit.log(
            "manual_vote_remove", host_id, giveaway_id=giveaway_id,
            details={"participant_id": participant_id, "amount": amount, "vote_id": vote.id},
        )
        return vote

    async def undo_last_manual_action(self, giveaway_id: str, host_id: int):
        """Undo the most recent MANUAL_VOTE by this host for this giveaway.

        Returns (undo_rec, participant_id) — callers need participant_id
        to refresh that contestant's live vote-count button in the
        channel (undoing a manual vote changes the total just like the
        original add/remove did, so the channel card must be re-synced
        the same way)."""
        manual_votes = await self.records.find("MANUAL_VOTE", giveaway_id=giveaway_id, host_id=host_id)
        if not manual_votes:
            raise VoteError("nothing_to_undo")
        last = sorted(manual_votes, key=lambda r: r.created_at)[-1]
        if last.data.get("undone"):
            raise VoteError("already_undone")

        participant_id = last.data["participant_id"]
        reverse_amount = -last.data["amount"] if last.data["direction"] == "ADD" else last.data["amount"]
        await self._bump_participant_votes(participant_id, reverse_amount)
        await self.records.update(last.id, data={"undone": True})
        undo_rec = await self.records.save(
            "AUDIT",
            {
                "action": "undo_event",
                "actor_id": host_id,
                "giveaway_id": giveaway_id,
                "details": {"reverted_vote_id": last.id, "amount": reverse_amount},
            },
        )
        return undo_rec, participant_id

    # ------------------------------------------------------------------
    # Membership-driven deduction / restoration (spec 29-30)
    # ------------------------------------------------------------------
    async def deduct_for_membership_leave(self, giveaway_id: str, voter_id: int, participant_id: str):
        vote = await self.records.find_one(
            "VOTE", giveaway_id=giveaway_id, participant_id=participant_id, voter_id=voter_id
        )
        if not vote or vote.status != "valid":
            return None  # nothing to deduct — idempotent no-op
        await self.records.update(vote.id, status="deducted", data={"deduction_reason": "left_required_channel"})
        await self._bump_participant_votes(participant_id, -1)
        await self.audit.log(
            "vote_deducted", voter_id, giveaway_id=giveaway_id,
            details={"participant_id": participant_id, "vote_id": vote.id},
        )
        return vote

    async def restore_after_membership_rejoin(self, giveaway_id: str, voter_id: int, participant_id: str):
        vote = await self.records.find_one(
            "VOTE", giveaway_id=giveaway_id, participant_id=participant_id, voter_id=voter_id
        )
        if not vote or vote.status != "deducted":
            return None  # idempotent no-op (e.g. already valid, or never voted)
        await self.records.update(vote.id, status="valid", data={"restored": True})
        await self._bump_participant_votes(participant_id, +1)
        await self.audit.log(
            "vote_restored", voter_id, giveaway_id=giveaway_id,
            details={"participant_id": participant_id, "vote_id": vote.id},
        )
        return vote

    # ------------------------------------------------------------------
    async def _bump_participant_votes(self, participant_id: str, delta: int):
        p = await self.records.get(participant_id)
        if p is None:
            return
        new_total = max(0, p.data.get("votes", 0) + delta)
        await self.records.update(participant_id, data={"votes": new_total})
