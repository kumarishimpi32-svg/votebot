"""
services/export_service.py
Premium export of giveaway results (spec 67). Detailed per-voter export
requires host authorization; the public export never leaks the full voter
list — only participant name/id/votes/rank/winner status.
"""
from __future__ import annotations
import csv
import io
import json
from openpyxl import Workbook
from storage.record_manager import RecordManager


class ExportService:
    def __init__(self, records: RecordManager):
        self.records = records

    async def _ranked_results(self, giveaway_id: str, winners_ids: set[str]):
        participants = await self.records.find("PARTICIPANT", giveaway_id=giveaway_id)
        approved = [p for p in participants if p.status == "approved"]
        approved.sort(key=lambda p: p.data.get("votes", 0), reverse=True)
        rows = []
        for i, p in enumerate(approved, start=1):
            rows.append({
                "rank": i,
                "name": p.data.get("name"),
                "telegram_id": p.data.get("telegram_id"),
                "votes": p.data.get("votes", 0),
                "winner": p.id in winners_ids,
            })
        return rows

    async def export_csv(self, giveaway_id: str, winners_ids: set[str]) -> bytes:
        rows = await self._ranked_results(giveaway_id, winners_ids)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=["rank", "name", "telegram_id", "votes", "winner"])
        writer.writeheader()
        writer.writerows(rows)
        return buf.getvalue().encode("utf-8")

    async def export_xlsx(self, giveaway_id: str, winners_ids: set[str]) -> bytes:
        rows = await self._ranked_results(giveaway_id, winners_ids)
        wb = Workbook()
        ws = wb.active
        ws.title = "Results"
        ws.append(["Rank", "Name", "Telegram ID", "Votes", "Winner"])
        for r in rows:
            ws.append([r["rank"], r["name"], r["telegram_id"], r["votes"], "Yes" if r["winner"] else ""])
        buf = io.BytesIO()
        wb.save(buf)
        return buf.getvalue()

    async def export_json(self, giveaway_id: str, winners_ids: set[str]) -> bytes:
        rows = await self._ranked_results(giveaway_id, winners_ids)
        return json.dumps(rows, ensure_ascii=False, indent=2).encode("utf-8")

    async def export_detailed_vote_history(self, giveaway_id: str) -> bytes:
        """Host-authorized only — caller must check permissions before calling this."""
        votes = await self.records.find("VOTE", giveaway_id=giveaway_id)
        rows = [
            {
                "voter_id": v.data.get("voter_id"),
                "participant_id": v.data.get("participant_id"),
                "status": v.status,
                "created_at": v.created_at,
                "restored": v.data.get("restored", False),
            }
            for v in votes
        ]
        return json.dumps(rows, ensure_ascii=False, indent=2).encode("utf-8")
