"""
services/contestant_service.py

Publishes an APPROVED participant as a contestant profile in the voting
channel. This is the piece that was entirely missing from the previous
build: approval only ever updated a database row and DMed the participant
— the contestant stayed invisible inside the bot, so nobody could vote for
them. /publish existed as a manual host command, but nothing called it
automatically on approval.

Idempotency: publishing is guarded by an atomic find-or-create on a
CONTESTANT_PUBLISH record keyed by participant_id (see
storage/telegram_storage.py:save_if_unique, which takes the write lock
for the whole check-then-write). This means:
  - two concurrent approvals of the same participant (double-tapped
    Approve, or an auto-approve racing a manual override) can only ever
    result in ONE channel post
  - a bot restart, a repeated background scan, or calling publish() again
    for an already-published contestant is always a safe no-op
  - the manual /publish (bulk "catch up") path and the automatic
    on-approval path share this exact same function, so there is one
    authoritative implementation, not two competing ones
"""
from __future__ import annotations
import logging
from telegram import Bot
from telegram.error import TelegramError
from storage.record_manager import RecordManager
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from utils.formatting import participant_card
from utils.keyboards import vote_button

logger = logging.getLogger("contestant_service")


class ContestantService:
    def __init__(self, records: RecordManager, giveaway_service: GiveawayService, participant_service: ParticipantService):
        self.records = records
        self.giveaway_service = giveaway_service
        self.participant_service = participant_service

    async def publish_if_needed(self, bot: Bot, giveaway_id: str, participant_id: str) -> bool:
        """Returns True if this call actually published the contestant just
        now, False if it was already published, not approved, or failed."""
        participant = await self.records.get(participant_id)
        if participant is None or participant.type != "PARTICIPANT":
            return False
        if participant.status != "approved":
            return False  # only APPROVED participants ever become contestants

        giveaway = await self.giveaway_service.get(giveaway_id)
        if giveaway is None:
            return False

        # Atomic claim: only the caller that actually creates this record
        # gets to post the channel message. Every other (concurrent or
        # later) caller sees created=False and does nothing.
        claim, created = await self.records.save_if_unique(
            "CONTESTANT_PUBLISH",
            unique_fields={"participant_id": participant_id},
            data={"participant_id": participant_id, "giveaway_id": giveaway_id},
            status="pending",
        )
        if not created:
            return False

        try:
            msg = await bot.send_message(
                chat_id=giveaway.data["channel_id"],
                text=participant_card(participant.data["name"], participant.data["telegram_id"], participant.data.get("votes", 0)),
                parse_mode="HTML",
                reply_markup=vote_button(giveaway_id, participant_id, participant.data.get("votes", 0)),
            )
        except TelegramError as e:
            # Channel post genuinely failed (bot not admin, missing Post
            # Messages right, channel gone, etc.) — release the claim so a
            # later retry (e.g. host fixes permissions and re-runs the
            # manual publish) can actually succeed, instead of silently
            # believing it already worked (spec: no silent false-success).
            logger.warning("Failed to publish contestant %s to channel %s: %s", participant_id, giveaway.data.get("channel_id"), e)
            await self.records.update(claim.id, status="failed", data={"error": str(e)[:300]})
            return False

        await self.records.update(claim.id, status="done", data={"message_id": msg.message_id})
        await self.participant_service.records.update(
            participant_id,
            data={
                "published": True,
                "channel_id": giveaway.data["channel_id"],
                "message_id": msg.message_id,
            },
        )
        return True

    async def publish_all_pending(self, bot: Bot, giveaway_id: str) -> int:
        """Catch-up publish for any approved-but-not-yet-published entries
        (e.g. approvals that happened before this feature existed, or a
        channel-permission failure that needs retrying). Safe to call as
        often as needed — already-published contestants are always
        no-ops."""
        approved = await self.participant_service.list_for_giveaway(giveaway_id, status="approved")
        count = 0
        for p in approved:
            if await self.publish_if_needed(bot, giveaway_id, p.id):
                count += 1
        return count

    # ------------------------------------------------------------------
    # Live vote-count refresh
    # ------------------------------------------------------------------
    async def refresh_card(self, bot: Bot, participant_id: str) -> bool:
        """Re-syncs the Vote button on a published contestant's channel
        card with their current vote count.

        Bug fixed: cast_vote (the public Vote button) always kept its own
        card in sync because it edits the exact message the tapped
        callback_query came from — but every OTHER path that changes a
        participant's vote count (host /addvote, /removevote, /undo, and
        the membership-leave/rejoin deduction+restoration in
        services/background_tasks.job_membership_monitor) only ever wrote
        the new total to storage. None of them touched the channel
        message, so the "Vote - N" button shown to everyone silently went
        stale the moment a host adjusted votes manually or a voter left
        the required channel. Every one of those call sites should call
        this right after mutating votes.

        No-op (never raises) if the participant was never published, or
        if the channel post is gone/uneditable (e.g. deleted, or the bot
        lost Post/Edit rights) — vote totals themselves are already
        correct in storage regardless of whether the card can be
        refreshed, so a display-refresh failure must never surface as an
        error to the caller.
        """
        participant = await self.records.get(participant_id)
        if participant is None or participant.type != "PARTICIPANT":
            return False
        channel_id = participant.data.get("channel_id")
        message_id = participant.data.get("message_id")
        if not channel_id or not message_id:
            return False  # never published (or publish failed) — nothing to refresh

        giveaway_id = participant.data.get("giveaway_id")
        votes = participant.data.get("votes", 0)
        try:
            await bot.edit_message_reply_markup(
                chat_id=channel_id,
                message_id=message_id,
                reply_markup=vote_button(giveaway_id, participant_id, votes),
            )
        except TelegramError as e:
            logger.warning(
                "Could not refresh vote card for participant %s in channel %s: %s",
                participant_id, channel_id, e,
            )
            return False
        return True
