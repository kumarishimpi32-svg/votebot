"""
services/membership_service.py
Checks required-channel membership before voting, and via background
polling afterward (spec section 28). Uses Bot.get_chat_member, the
legitimate Bot API method for this — bots CANNOT be notified in real time
of arbitrary users leaving a channel, so ongoing monitoring is done by
periodic polling in a background task (see services/background_tasks.py),
not a push webhook (Telegram doesn't offer one for this).
"""
from __future__ import annotations
import asyncio
from telegram import Bot
from telegram.error import TelegramError

ACTIVE_STATUSES = {"member", "administrator", "creator"}


class MembershipService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def is_member_of_all(self, user_id: int, channel_ids: list[int]) -> tuple[bool, list[int]]:
        # PERF: these are independent network calls (one per required
        # channel) — run them concurrently instead of one-at-a-time so a
        # host with several required channels doesn't multiply vote
        # latency by the channel count.
        results = await asyncio.gather(*(self.is_member(user_id, cid) for cid in channel_ids))
        missing = [cid for cid, ok in zip(channel_ids, results) if not ok]
        return (len(missing) == 0, missing)

    async def is_member(self, user_id: int, channel_id: int) -> bool:
        try:
            member = await self.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            return member.status in ACTIVE_STATUSES
        except TelegramError:
            # If the bot can't check (not admin in that channel, user never
            # started interacting, etc.) fail closed: treat as not-a-member
            # rather than silently allowing the vote.
            return False
