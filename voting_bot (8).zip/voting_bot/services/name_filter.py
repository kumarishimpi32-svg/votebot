"""
services/name_filter.py
Local, offline blocked-name filter. Conservative by design: this catches
obvious blocked terms; anything not caught here still goes through AI
moderation / manual review, so this file does not need to be exhaustive.
"""
from __future__ import annotations
import re
import unicodedata

BLOCKED_NAMES_PATH = "filters/blocked_names.txt"


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text


class NameFilter:
    def __init__(self, path: str = BLOCKED_NAMES_PATH):
        self.path = path
        self._blocked: set[str] = set()
        self.reload()

    def reload(self) -> int:
        blocked = set()
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    blocked.add(_normalize(line))
        except FileNotFoundError:
            pass
        self._blocked = blocked
        return len(self._blocked)

    def add(self, term: str) -> None:
        norm = _normalize(term)
        if norm and norm not in self._blocked:
            self._blocked.add(norm)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(term.strip() + "\n")

    def remove(self, term: str) -> bool:
        norm = _normalize(term)
        if norm in self._blocked:
            self._blocked.discard(norm)
            self._rewrite()
            return True
        return False

    def _rewrite(self) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            for term in sorted(self._blocked):
                f.write(term + "\n")

    def is_blocked(self, name: str) -> bool:
        norm = _normalize(name)
        if not norm:
            return False
        if norm in self._blocked:
            return True
        # substring match on whole blocked phrases (not single chars) to
        # avoid being unnecessarily aggressive on short/common fragments
        for term in self._blocked:
            if len(term) >= 3 and term in norm:
                return True
        return False

    def stats(self) -> dict:
        return {"blocked_terms": len(self._blocked)}
