"""
services/giveaway_service.py
Giveaway creation, configuration and lifecycle (spec sections 10-12, 32).
"""
from __future__ import annotations
import time
from typing import Any
from config import CONFIG
from storage.record_manager import RecordManager
from services.audit_service import AuditService


class GiveawayService:
    def __init__(self, records: RecordManager, audit: AuditService):
        self.records = records
        self.audit = audit

    async def create_giveaway(self, host_id: int, channel_id: int, config: dict[str, Any]):
        """
        config keys (all optional unless noted, spec section 11):
        title* description prize start_time end_time min_votes max_winners
        required_channels[] review_chat_id moderation_settings voting_settings
        winner_rule('highest'|'random_tie'|'host_select')
        tie_rule('all'|'random'|'host')

        Note: there is deliberately no 'image_protection' option here —
        that was a participant-photo-submission feature, removed from the
        product entirely (see the deleted handlers/image_protection.py).
        """
        data = {
            "host_id": host_id,
            "channel_id": channel_id,
            "title": config.get("title", "Untitled Giveaway"),
            "description": config.get("description", ""),
            "prize": config.get("prize", ""),
            "start_time": config.get("start_time", time.time()),
            "end_time": config.get("end_time"),
            "min_votes": config.get("min_votes", 0),
            "max_winners": config.get("max_winners", 1),
            # Channels a participant must have joined to enter/vote in this
            # giveaway. Free hosts always fall back to the bot's single
            # default channel (spec: mandatory subscription); Premium hosts
            # may instead require their own connected channel(s) — see
            # handlers/giveaway_wizard.py, which is what actually decides
            # this list at creation time. This default only matters for
            # callers that don't pass it explicitly (e.g. tests).
            "required_channels": config.get("required_channels") or [CONFIG.required_channel],
            "review_chat_id": config.get("review_chat_id"),
            "moderation_settings": config.get("moderation_settings", {}),
            "voting_settings": config.get("voting_settings", {}),
            "winner_rule": config.get("winner_rule", "highest"),
            "tie_rule": config.get("tie_rule", "all"),
            "state": "ACTIVE",  # ACTIVE -> ENDED
        }
        rec = await self.records.save("GIVEAWAY", data, status="ACTIVE")
        await self.audit.log("giveaway_created", host_id, giveaway_id=rec.id, details={"title": data["title"]})
        return rec

    async def get(self, giveaway_id: str):
        return await self.records.get(giveaway_id)

    async def is_host(self, giveaway_id: str, user_id: int) -> bool:
        rec = await self.records.get(giveaway_id)
        return bool(rec and rec.data.get("host_id") == user_id)

    async def update_config(self, giveaway_id: str, actor_id: int, **fields):
        rec = await self.records.update(giveaway_id, data=fields)
        await self.audit.log("giveaway_updated", actor_id, giveaway_id=giveaway_id, details=fields)
        return rec

    async def end_giveaway(self, giveaway_id: str, actor_id: int, reason: str):
        """
        Atomic ACTIVE -> ENDED transition (spec section 33: ending must be
        idempotent — a double-tapped "End" button, or two admins ending the
        same giveaway at once, must not run winner selection or announce
        winners twice). A plain read-then-write here would let both calls
        see state=="ACTIVE" and both proceed.

        Returns the updated record, or None if the giveaway was already
        ended (or never existed) — callers must treat None as "someone
        already handled this", not as an error, and must NOT re-run winner
        selection or re-announce in that case.
        """
        rec = await self.records.try_transition(
            giveaway_id, "ACTIVE", "ENDED", data={"ended_reason": reason, "state": "ENDED"}
        )
        if rec is None:
            return None
        await self.audit.log("giveaway_ended", actor_id, giveaway_id=giveaway_id, details={"reason": reason})
        return rec

    async def list_active(self):
        return await self.records.find("GIVEAWAY", state="ACTIVE")

    async def list_by_host(self, host_id: int):
        return await self.records.find("GIVEAWAY", host_id=host_id)
