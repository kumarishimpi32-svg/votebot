"""
security/secrets.py
Nothing sensitive is ever put in Telegram storage, logs, or /admin output.
This module exists as the single place other code should go through if it
ever needs to reason about "is this a secret" — keeping the policy in one
spot instead of scattered checks.
"""
from __future__ import annotations

SECRET_ENV_VARS = {
    "BOT_TOKEN",
    "PAYMENT_API_KEY",
    "PAYMENT_API_SECRET",
    *(f"GOOGLE_API_KEY_{i}" for i in range(1, 41)),
}


def redact(value: str, keep_last: int = 4) -> str:
    if not value:
        return ""
    if len(value) <= keep_last:
        return "*" * len(value)
    return "*" * (len(value) - keep_last) + value[-keep_last:]


def assert_not_secret_leaked(payload: dict) -> None:
    """Defensive check before writing anything to Telegram storage or logs."""
    for key in payload:
        if key.upper() in SECRET_ENV_VARS or "token" in key.lower() or "secret" in key.lower():
            raise ValueError(f"Refusing to persist a field that looks like a secret: {key}")
