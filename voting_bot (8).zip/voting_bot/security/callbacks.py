"""
security/callbacks.py
Structured, size-safe callback_data encoding. Telegram limits callback_data
to 64 bytes, so we use short action codes plus IDs, never raw user input.
Format: "action:field1:field2..."
"""
from __future__ import annotations


def encode(action: str, *parts: str) -> str:
    data = ":".join([action, *[str(p) for p in parts]])
    if len(data.encode("utf-8")) > 64:
        raise ValueError(f"callback_data too long: {data}")
    return data


def decode(data: str) -> tuple[str, list[str]]:
    pieces = data.split(":")
    return pieces[0], pieces[1:]
