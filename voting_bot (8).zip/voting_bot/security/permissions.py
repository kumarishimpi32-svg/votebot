"""
security/permissions.py
Roles per spec section 73: Normal User, Participant, Giveaway Host,
Review Admin, Payment Admin, Channel Admin, Bot Owner.

CRITICAL: never trust username/display-name/callback-data claims — always
verify against the storage record or live Telegram admin status.
"""
from __future__ import annotations
from telegram import Bot
from telegram.error import TelegramError
from config import CONFIG
from storage.record_manager import RecordManager


class Permissions:
    def __init__(self, bot: Bot, records: RecordManager, payment_admin_ids: set[int] | None = None):
        self.bot = bot
        self.records = records
        # Payment Admin is a distinct role from Telegram group admin (spec 71).
        # Owner can grant this role at runtime via /admin; seeded with owner only.
        self.payment_admin_ids: set[int] = payment_admin_ids or {CONFIG.owner_id}

    def is_owner(self, user_id: int) -> bool:
        return user_id == CONFIG.owner_id

    async def is_giveaway_host(self, giveaway_id: str, user_id: int) -> bool:
        rec = await self.records.get(giveaway_id)
        return bool(rec and rec.data.get("host_id") == user_id)

    async def is_channel_owner(self, channel_record_id: str, user_id: int) -> bool:
        """Verifies that `user_id` is the account that connected the given
        CHANNEL record (by its internal record id, never the raw Telegram
        chat_id — see security/callbacks.py: callback_data must only ever
        carry the record id, and this check must be re-run inside the
        handler regardless of what the UI showed). Returns False (never
        raises) for a missing/removed channel so callers can safely show
        Access Denied instead of leaking whether the id ever existed.
        """
        if self.records is None:
            return False
        rec = await self.records.get(channel_record_id)
        if rec is None or rec.type != "CHANNEL" or rec.status != "active":
            return False
        return rec.data.get("owner_id") == user_id

    async def is_channel_admin(self, channel_id: int, user_id: int) -> bool:
        try:
            member = await self.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            return member.status in ("administrator", "creator")
        except TelegramError:
            return False

    async def is_review_admin(self, giveaway_id: str, user_id: int) -> bool:
        """Only current admins of the giveaway's configured review chat —
        OR, when the review chat is a private DM (positive chat_id, i.e.
        it's simply a user's own chat with the bot, not a group/channel),
        only that same user. This matters because the default review
        chat for every giveaway is now the host's own DM (see
        handlers/giveaway_wizard.py) rather than a group/channel: Bot API
        get_chat_member has no concept of "admins" on a 1-on-1 private
        chat and raises for it, so falling through to the live
        admin-status check there would make review buttons unusable for
        every host, forever."""
        rec = await self.records.get(giveaway_id)
        if rec is None:
            return False
        review_chat_id = rec.data.get("review_chat_id")
        if review_chat_id is None:
            return False
        # Telegram chat_id convention: private (user) chats are positive
        # and equal to the user's own id; groups/supergroups/channels are
        # negative (supergroups/channels start with -100).
        if review_chat_id > 0:
            return user_id == review_chat_id
        return await self.is_channel_admin(review_chat_id, user_id)

    def is_payment_admin(self, user_id: int) -> bool:
        return self.is_owner(user_id) or user_id in self.payment_admin_ids

    def grant_payment_admin(self, user_id: int) -> None:
        self.payment_admin_ids.add(user_id)

    def revoke_payment_admin(self, user_id: int) -> None:
        self.payment_admin_ids.discard(user_id)

    # ------------------------------------------------------------------
    # Persistence (spec section 51: a restart must not silently reset
    # granted roles). grant/revoke above stay synchronous and in-memory-only
    # so existing callers/tests are unaffected; these async helpers persist
    # the same change to storage and restore it on the next boot.
    # ------------------------------------------------------------------
    async def persist_payment_admin_grant(self, user_id: int) -> None:
        if self.records is None:
            return
        existing = await self.records.find_one("PAYMENT_ADMIN_GRANT", user_id=user_id)
        if existing is None:
            await self.records.save("PAYMENT_ADMIN_GRANT", {"user_id": user_id}, status="active")
        elif existing.status != "active":
            await self.records.update(existing.id, status="active")

    async def persist_payment_admin_revoke(self, user_id: int) -> None:
        if self.records is None:
            return
        existing = await self.records.find_one("PAYMENT_ADMIN_GRANT", user_id=user_id)
        if existing is not None and existing.status == "active":
            await self.records.update(existing.id, status="revoked")

    async def load_payment_admins(self) -> None:
        """Call once at startup, after rebuild_indexes, to restore any
        owner-granted Payment Admins from before the last restart."""
        if self.records is None:
            return
        grants = await self.records.list("PAYMENT_ADMIN_GRANT", status="active")
        for g in grants:
            uid = g.data.get("user_id")
            if uid is not None:
                self.payment_admin_ids.add(uid)
