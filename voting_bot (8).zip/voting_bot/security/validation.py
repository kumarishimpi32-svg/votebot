"""
security/validation.py
Basic input validation. Never trust client-side/user-submitted amounts,
plan details, or IDs — always re-derive from stored records.
"""
from __future__ import annotations

MAX_NAME_LEN = 64
MIN_NAME_LEN = 1


def validate_display_name(name: str) -> tuple[bool, str]:
    name = name.strip()
    if not (MIN_NAME_LEN <= len(name) <= MAX_NAME_LEN):
        return False, f"Name must be {MIN_NAME_LEN}-{MAX_NAME_LEN} characters."
    if "\n" in name or "\t" in name:
        return False, "Name cannot contain line breaks or tabs."
    return True, ""


def validate_vote_amount(raw: str) -> tuple[bool, int, str]:
    try:
        amount = int(raw)
    except ValueError:
        return False, 0, "Amount must be a whole number."
    if amount <= 0 or amount > 100000:
        return False, 0, "Amount must be between 1 and 100000."
    return True, amount, ""


def validate_payment_reference(raw: str) -> tuple[bool, str]:
    ref = raw.strip()
    if not (4 <= len(ref) <= 100):
        return False, "Reference must be 4-100 characters."
    return True, ref
