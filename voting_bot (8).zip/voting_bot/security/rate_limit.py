"""
security/rate_limit.py
Thin helper so handlers can bail out early with a friendly message instead
of hammering downstream services. Actual buckets live in services/anti_abuse.py
so both handlers and services share the same limiter instances.
"""
from __future__ import annotations
from telegram import Update


async def reject_if_limited(update: Update, allowed: bool, message: str = "⏳ Please slow down and try again shortly.") -> bool:
    """Returns True if the request was rejected (caller should stop processing)."""
    if allowed:
        return False
    if update.callback_query:
        await update.callback_query.answer(message, show_alert=True)
    elif update.message:
        await update.message.reply_text(message)
    return True
