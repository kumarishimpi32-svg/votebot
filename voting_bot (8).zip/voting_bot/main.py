"""
main.py
Application entry point. Builds the PTB Application, constructs every
service with its dependencies, registers handlers, restores storage state,
and starts polling.
"""
from __future__ import annotations
import asyncio
import logging

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import BadRequest, NetworkError, TimedOut
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from telegram.request import HTTPXRequest

from config import CONFIG
from utils.logging import setup_logging
from utils.helpers import USER_FACING_ERROR
from utils.formatting import esc
from utils import premium_emoji

from storage.telegram_storage import TelegramStorage
from storage.record_manager import RecordManager
from storage.recovery import safe_boot
from storage.cache import RateLimiter

from services.api_pool import ApiKeyPool
from services.ai_moderation import AiModerationService
from services.image_moderation import ImageModerationService
from services.name_filter import NameFilter
from services.moderation_pipeline import ModerationPipeline
from services.audit_service import AuditService
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.vote_service import VoteService
from services.membership_service import MembershipService
from services.anti_abuse import AntiAbuseService
from services.leaderboard import LeaderboardService
from services.winner_service import WinnerService
from services.premium_service import PremiumService
from services.payment_service import PaymentService
from services.notification_service import NotificationService
from services.analytics import AnalyticsService
from services.export_service import ExportService
from services.contestant_service import ContestantService
from services.channel_moderation_service import ChannelModerationService
from services.channel_service import ChannelService
from services.background_tasks import register_jobs

from security.permissions import Permissions

from handlers.start import start_cmd, home_callback, giveaways_menu_callback, profile_menu_callback, check_membership_callback
from handlers.giveaway import my_giveaways_cmd
from handlers.giveaway_wizard import start_wizard
from handlers.participant import join_cmd, handle_free_text, resubmit_callback, check_giveaway_membership_callback
from handlers.moderation import review_callback
from handlers.channel_moderation import channel_post_handler
from handlers.channel import (
    channels_menu_callback, add_channel_start_callback, select_channel_callback,
    handle_channel_input_text, remove_channel_start_callback, remove_channel_confirm_callback,
    channels_cmd,
)
from handlers.voting import publish_cmd, vote_callback
from handlers.host import (
    dashboard_cmd, addvote_cmd, removevote_cmd, undo_cmd, end_cmd, export_cmd,
    tie_pick_callback, tie_confirm_callback, dashboard_action_callback, imageprotection_cmd,
)
from handlers.pickers import (
    giveaways_menu_action_callback, giveaway_selected_callback, participant_selected_callback,
    handle_custom_vote_amount_text,
)
from handlers.leaderboard import leaderboard_cmd
from handlers.premium import (
    premium_menu_cmd, premium_menu_callback, plans_cmd, plan_selected_callback, payment_done_callback,
)
from handlers.payment import handle_payment_reference_text, handle_payment_screenshot_photo, payment_review_callback
from handlers.owner import admin_cmd, broadcast_cmd, handle_banner_photo, handle_payment_qr_photo
from handlers.admin import payments_cmd
from handlers.image_protection import submitphoto_cmd, handle_photo_message

logger = logging.getLogger("main")


async def post_init(application: Application) -> None:
    """Runs once after the bot connects, before polling starts (spec section 5)."""
    bot = application.bot
    storage = TelegramStorage(bot, CONFIG.storage_chat_id)
    storage.start()  # background writer: keeps Telegram audit writes off the hot path (see storage/telegram_storage.py)

    async def notify_owner(text: str) -> None:
        try:
            await bot.send_message(chat_id=CONFIG.owner_id, text=text)
        except Exception:
            logger.warning("Could not notify owner during boot.")

    await safe_boot(storage, owner_notifier=notify_owner)

    records = RecordManager(storage)
    audit = AuditService(records)
    permissions = Permissions(bot, records)
    await permissions.load_payment_admins()  # restore owner-granted roles after a restart

    pool = ApiKeyPool(CONFIG.google_api_keys)
    ai = AiModerationService(pool)
    image_moderation = ImageModerationService(bot, pool)
    name_filter = NameFilter()
    pipeline = ModerationPipeline(name_filter, ai)

    giveaway_service = GiveawayService(records, audit)
    participant_service = ParticipantService(records, audit, pipeline)
    vote_service = VoteService(records, audit)
    membership_service = MembershipService(bot)
    anti_abuse = AntiAbuseService()
    leaderboard = LeaderboardService(records)
    winner_service = WinnerService(records, audit)
    premium_service = PremiumService(records, audit)
    payment_service = PaymentService(records, audit, premium_service)
    notifications = NotificationService(bot)
    analytics = AnalyticsService(records)
    export_service = ExportService(records)
    contestant_service = ContestantService(records, giveaway_service, participant_service)
    channel_moderation = ChannelModerationService(
        records, name_filter, ai, CONFIG.moderation_alert_chat_id,
        image_moderation=image_moderation, premium_service=premium_service,
    )
    channel_service = ChannelService(bot, records, audit)

    application.bot_data.update({
        "storage": storage,
        "records": records,
        "audit_service": audit,
        "permissions": permissions,
        "api_pool": pool,
        "ai_moderation": ai,
        "image_moderation": image_moderation,
        "name_filter": name_filter,
        "moderation_pipeline": pipeline,
        "giveaway_service": giveaway_service,
        "participant_service": participant_service,
        "vote_service": vote_service,
        "membership_service": membership_service,
        "anti_abuse": anti_abuse,
        "leaderboard": leaderboard,
        "winner_service": winner_service,
        "premium_service": premium_service,
        "payment_service": payment_service,
        "notifications": notifications,
        "analytics": analytics,
        "export_service": export_service,
        "contestant_service": contestant_service,
        "channel_moderation": channel_moderation,
        "channel_service": channel_service,
    })

    register_jobs(application)
    logger.info("Startup complete. Storage: %s", storage.health())

    try:
        await bot.send_message(chat_id=CONFIG.owner_id, text="✅ Bot started and storage index rebuilt.")
    except Exception:
        pass


async def post_shutdown(application: Application) -> None:
    """Runs once as the bot shuts down (Ctrl+C, SIGTERM, etc.), before the
    event loop closes. Nothing previously called TelegramStorage.stop(),
    so its background writer task was simply abandoned mid-`await
    queue.get()` every time the bot stopped — harmless in effect (the
    queue is empty at that point almost every time), but it logged an
    ugly 'Task was destroyed but it is pending!' / 'RuntimeError: Event
    loop is closed' on every shutdown. Stopping it properly here — after
    the JobQueue/scheduler has already stopped producing new writes —
    lets it drain and exit cleanly instead."""
    storage = application.bot_data.get("storage")
    if storage is not None:
        try:
            await storage.stop()
        except Exception:
            logger.exception("Error stopping storage writer during shutdown")

    await _probe_premium_icon_support(bot)


async def _probe_premium_icon_support(bot) -> None:
    """One-time capability check, run once per process start.

    icon_custom_emoji_id (the premium button icons) either works for
    EVERY button or NONE of them, decided entirely by Telegram based on
    the bot owner's account — not something this code can fix by trying
    harder. Rather than let the first real user hit that failure, send
    one throwaway probe message to the owner with an icon attached; if
    Telegram accepts it we leave icons on (default), and if it rejects it
    we flip the one global switch (utils/premium_emoji.set_icons_supported)
    so every keyboard built anywhere in the app quietly stops attempting
    icons from this point on. Either way the owner gets a clear, plain
    explanation — never a raw stack trace.
    """
    if not premium_emoji.PREMIUM_EMOJI_IDS:
        return
    sample_id = next(iter(premium_emoji.PREMIUM_EMOJI_IDS.values()))
    probe_markup = InlineKeyboardMarkup([[
        InlineKeyboardButton("Checking icon support", callback_data="noop:probe", icon_custom_emoji_id=sample_id)
    ]])
    try:
        sent = await bot.send_message(
            chat_id=CONFIG.owner_id,
            text="🔧 Checking premium emoji icon support…",
            reply_markup=probe_markup,
        )
    except BadRequest as e:
        premium_emoji.set_icons_supported(False)
        logger.warning("Premium emoji button icons disabled: %s", e)
        try:
            await bot.send_message(
                chat_id=CONFIG.owner_id,
                text=(
                    "ℹ️ Premium emoji icons on buttons are OFF for now — Telegram rejected them. "
                    "This needs either a Fragment-purchased username on this bot, or your own "
                    "Telegram account to have an active Premium subscription. The bot itself "
                    "works normally either way; buttons just show plain emoji until then."
                ),
            )
        except Exception:
            pass
        return
    except Exception as e:
        # Any other failure (network hiccup, owner blocked the bot, etc.)
        # is not evidence icons don't work — leave the flag as-is so we
        # don't disable a feature over an unrelated transient error.
        logger.warning("Premium emoji probe inconclusive, leaving icons enabled: %s", e)
        return

    logger.info("Premium emoji button icons confirmed working.")
    try:
        await bot.delete_message(chat_id=CONFIG.owner_id, message_id=sent.message_id)
    except Exception:
        pass


# Caps how often this handler will speak into any single chat/DM when the
# same error condition keeps firing (e.g. a stuck API key). Without this,
# a persistent bug would resend "Something went wrong" on every single
# retry — the exact repeat-spam behavior this must never do again.
_error_reply_limiter = RateLimiter(max_calls=1, per_seconds=120)


_ICON_ERROR_HINTS = ("icon_custom_emoji", "icon custom emoji", "button icon")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Unhandled exception while processing update: %s", context.error, exc_info=context.error)

    # Safety net for the startup probe in _probe_premium_icon_support:
    # covers a Premium subscription lapsing (or a Fragment username being
    # dropped) mid-run, well after the one-time boot-time check passed.
    # Trips the same global switch so every keyboard built anywhere in the
    # app stops attempting icons from here on — the update that hit this
    # still shows the generic error below to whoever triggered it, but no
    # one else pays that cost again.
    if (
        premium_emoji.icons_supported()
        and isinstance(context.error, BadRequest)
        and any(hint in str(context.error).lower() for hint in _ICON_ERROR_HINTS)
    ):
        premium_emoji.set_icons_supported(False)
        logger.warning("Premium emoji button icons disabled mid-run: %s", context.error)
        if _error_reply_limiter.allow(f"icons_disabled:{CONFIG.owner_id}"):
            try:
                await context.bot.send_message(
                    chat_id=CONFIG.owner_id,
                    text=(
                        "ℹ️ Premium emoji icons on buttons just got turned OFF automatically — "
                        "Telegram started rejecting them (likely your account's Premium lapsed, "
                        "or the Fragment username changed). The bot keeps working normally with "
                        "plain emoji; re-run it after fixing that to try icons again."
                    ),
                )
            except Exception:
                pass

    is_channel_post = isinstance(update, Update) and update.channel_post is not None
    channel_chat_id = update.channel_post.chat.id if is_channel_post else None

    if isinstance(update, Update) and not is_channel_post:
        # Private chats / groups only. A channel post must NEVER get a
        # public reply here — that is the exact "spam in the channel"
        # failure mode this bot must not have. Channel-facing content
        # moderation has its own silent, private-alert-only pipeline
        # (services/channel_moderation_service.py); this generic handler
        # has no business posting into a channel under any circumstance.
        try:
            if update.callback_query:
                await update.callback_query.answer(USER_FACING_ERROR, show_alert=True)
            elif update.effective_message:
                await update.effective_message.reply_text(USER_FACING_ERROR)
        except Exception:
            pass

    if is_channel_post and channel_chat_id is not None:
        # Notify whoever actually connected/administers this channel —
        # not a random global fallback — so the right person can act.
        # Friendly, non-technical wording only: this admin is not
        # necessarily the bot operator and must never receive raw
        # exception internals (spec: no internal details to non-owners).
        try:
            records = context.bot_data.get("records")
            owner_id = None
            if records is not None:
                rec = await records.find_one("CHANNEL", chat_id=channel_chat_id)
                if rec is not None:
                    owner_id = rec.data.get("owner_id")
            if owner_id and _error_reply_limiter.allow(f"chowner:{owner_id}:{channel_chat_id}"):
                await context.bot.send_message(
                    chat_id=owner_id,
                    text=(
                        "⚠️ <b>ACTION NEEDED IN YOUR CHANNEL</b>\n\n"
                        "The bot ran into a problem handling recent activity "
                        "in a channel you manage. Nothing was posted publicly "
                        "there. If this keeps happening, contact the bot owner."
                    ),
                    parse_mode="HTML",
                )
        except Exception:
            pass  # best-effort only — never let this block owner alerting below

    # Also alert the owner directly in Telegram, not just server logs — so
    # errors are visible immediately without needing hosting-panel access.
    # Sanitized: exception type + message only, never secrets, never a full
    # stack trace (which could leak file paths / internals to a DM).
    try:
        error_type = type(context.error).__name__ if context.error else "UnknownError"
        error_msg = esc(str(context.error)[:300]) if context.error else "—"
        where = ""
        if isinstance(update, Update) and update.effective_message:
            raw_text = update.effective_message.text or update.effective_message.caption or "—"
            where = f"\nCommand/text: {esc(raw_text)}"
        await context.bot.send_message(
            chat_id=CONFIG.owner_id,
            text=(
                f"🚨 <b>BOT ERROR</b>\n\n"
                f"Type: <code>{esc(error_type)}</code>\n"
                f"Message: {error_msg}{where}\n\n"
                f"Check your hosting logs for the full traceback."
            ),
            parse_mode="HTML",
        )
    except Exception:
        pass  # never let error reporting itself crash the error handler


async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Routes free-text messages to whichever flow is waiting on this user.
    Order matters: only one state should be active at a time per user.

    Guard: this must never touch context.user_data for an update that has
    no effective_user (e.g. an anonymous channel post) — PTB can't key
    per-user state without a user id, so doing that unconditionally used
    to raise on every text channel post, which the global error handler
    then "recovered" from by replying into the channel itself (exactly
    the public spam this bot must never produce). Channel content has its
    own dedicated, silent pipeline — see handlers/channel_moderation.py.
    """
    if update.effective_user is None or update.channel_post is not None:
        return
    if context.user_data.get("awaiting_channel_input"):
        if await handle_channel_input_text(update, context):
            return
    if context.user_data.get("awaiting_payment_reference_for"):
        if await handle_payment_reference_text(update, context):
            return
    if context.user_data.get("awaiting_vote_amount"):
        if await handle_custom_vote_amount_text(update, context):
            return
    if context.user_data.get("awaiting_name_for"):
        await handle_free_text(update, context)
        return
    # No active state — ignore free text outside of any flow.


async def photo_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Same guard as text_router — see its docstring."""
    if update.effective_user is None or update.channel_post is not None:
        return
    if await handle_banner_photo(update, context):
        return
    if await handle_payment_qr_photo(update, context):
        return
    if await handle_photo_message(update, context):
        return
    await handle_payment_screenshot_photo(update, context)


def build_application() -> Application:
    # Longer connect/read timeouts (default is ~5s, too short on a slow or
    # congested network) and an optional proxy for networks that block
    # api.telegram.org directly — this is what was producing
    # httpcore.ConnectTimeout -> telegram.error.TimedOut on every call,
    # including the first get_me() during startup. Two separate
    # HTTPXRequest instances match python-telegram-bot's own default split
    # (one pool for normal calls, one with a longer read timeout for the
    # long-poll getUpdates call).
    request_kwargs = dict(
        connect_timeout=CONFIG.connect_timeout,
        read_timeout=CONFIG.read_timeout,
        write_timeout=CONFIG.connect_timeout,
        pool_timeout=CONFIG.connect_timeout,
    )
    if CONFIG.proxy_url:
        request_kwargs["proxy"] = CONFIG.proxy_url

    get_updates_kwargs = dict(request_kwargs)
    get_updates_kwargs["read_timeout"] = max(CONFIG.read_timeout, 30.0)

    app = (
        ApplicationBuilder()
        .token(CONFIG.bot_token)
        .request(HTTPXRequest(**request_kwargs))
        .get_updates_request(HTTPXRequest(**get_updates_kwargs))
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    # Commands
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("creategiveaway", start_wizard))
    app.add_handler(CommandHandler("mygiveaways", my_giveaways_cmd))
    app.add_handler(CommandHandler("join", join_cmd))
    app.add_handler(CommandHandler("publish", publish_cmd))
    app.add_handler(CommandHandler("dashboard", dashboard_cmd))
    app.add_handler(CommandHandler("addvote", addvote_cmd))
    app.add_handler(CommandHandler("removevote", removevote_cmd))
    app.add_handler(CommandHandler("undo", undo_cmd))
    app.add_handler(CommandHandler("end", end_cmd))
    app.add_handler(CommandHandler("export", export_cmd))
    app.add_handler(CommandHandler("premium", premium_menu_cmd))
    app.add_handler(CommandHandler("submitphoto", submitphoto_cmd))
    app.add_handler(CommandHandler("imageprotection", imageprotection_cmd))
    app.add_handler(CommandHandler("plans", plans_cmd))
    app.add_handler(CommandHandler("leaderboard", leaderboard_cmd))
    app.add_handler(CommandHandler("payments", payments_cmd))
    app.add_handler(CommandHandler("admin", admin_cmd))
    app.add_handler(CommandHandler("channels", channels_cmd))
    app.add_handler(CommandHandler(["broadcast", "boadcast"], broadcast_cmd))

    # Callback queries (button presses) — routed by action prefix
    app.add_handler(CallbackQueryHandler(home_callback, pattern=r"^home(:|$)"))
    app.add_handler(CallbackQueryHandler(giveaways_menu_callback, pattern=r"^giveaways(:|$)"))
    app.add_handler(CallbackQueryHandler(profile_menu_callback, pattern=r"^profile(:|$)"))
    app.add_handler(CallbackQueryHandler(channels_menu_callback, pattern=r"^channels(:|$)"))
    app.add_handler(CallbackQueryHandler(add_channel_start_callback, pattern=r"^ch_add(:|$)"))
    app.add_handler(CallbackQueryHandler(select_channel_callback, pattern=r"^ch_select(:|$)"))
    app.add_handler(CallbackQueryHandler(remove_channel_start_callback, pattern=r"^ch_remove(:|$)"))
    app.add_handler(CallbackQueryHandler(remove_channel_confirm_callback, pattern=r"^ch_remove_confirm(:|$)"))
    app.add_handler(CallbackQueryHandler(premium_menu_callback, pattern=r"^premium(:|$)"))
    app.add_handler(CallbackQueryHandler(check_membership_callback, pattern=r"^check_membership(:|$)"))
    app.add_handler(CallbackQueryHandler(check_giveaway_membership_callback, pattern=r"^check_giveaway_membership(:|$)"))
    app.add_handler(CallbackQueryHandler(resubmit_callback, pattern=r"^resubmit(:|$)"))
    app.add_handler(CallbackQueryHandler(review_callback, pattern=r"^review_(ok|no)(:|$)"))
    app.add_handler(CallbackQueryHandler(vote_callback, pattern=r"^vote(:|$)"))
    app.add_handler(CallbackQueryHandler(plan_selected_callback, pattern=r"^plan(:|$)"))
    app.add_handler(CallbackQueryHandler(payment_done_callback, pattern=r"^premium_done(:|$)"))
    app.add_handler(CallbackQueryHandler(payment_review_callback, pattern=r"^pay_(ok|no|view)(:|$)"))
    app.add_handler(CallbackQueryHandler(tie_pick_callback, pattern=r"^tiepick(:|$)"))
    app.add_handler(CallbackQueryHandler(tie_confirm_callback, pattern=r"^tieconfirm(:|$)"))
    app.add_handler(CallbackQueryHandler(dashboard_action_callback, pattern=r"^h_(participants|votes|leaderboard|reviews|undo|analytics|export|end)(:|$)"))
    app.add_handler(CallbackQueryHandler(giveaways_menu_action_callback, pattern=r"^gw_(create|manage)(:|$)"))
    app.add_handler(CallbackQueryHandler(giveaway_selected_callback, pattern=r"^pg_(dash|publish|addv|remv|undo|end|exp|lb)(:|$)"))
    app.add_handler(CallbackQueryHandler(participant_selected_callback, pattern=r"^pp_(addv|remv)(:|$)"))

    # Free text router (name entry / payment reference / custom vote amount).
    # BUG FIX: filters.TEXT/filters.PHOTO match update.effective_message,
    # which is the channel_post for a channel-post update too — without
    # the explicit filters.UpdateType.MESSAGE restriction below, a text or
    # photo channel post would match THESE handlers first (registration
    # order decides which single handler in a group runs) and would be
    # silently swallowed by their "not a real user message" guard, so
    # handlers/channel_moderation.py's channel_post_handler further down
    # would never even run — i.e. channel moderation (text AND the new
    # Premium photo monitoring) would silently never fire. Restricting to
    # real user messages here is what lets channel posts actually reach
    # the CHANNEL_POST handler below.
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.UpdateType.MESSAGE, text_router))
    # Photo router (owner-only banner / payment QR uploads) — same fix.
    app.add_handler(MessageHandler(filters.PHOTO & filters.UpdateType.MESSAGE, photo_router))
    # Channel-content moderation: watches posts in the configured voting
    # channel and alerts an admin on potentially prohibited content. Event
    # driven off live channel_post updates only — never a poll, so it can
    # never spam the channel just because a background job woke up.
    app.add_handler(MessageHandler(filters.UpdateType.CHANNEL_POST, channel_post_handler))

    app.add_error_handler(error_handler)
    return app


def main() -> None:
    setup_logging()

    # The very first thing PTB does is call getMe() to identify the bot.
    # If this machine can't reach api.telegram.org at all (no internet,
    # DNS failure, or a firewall/antivirus/ISP blocking Telegram) that call
    # times out and PTB raises immediately, crashing the process before any
    # of the bot's own code runs. Retrying with backoff instead of dying
    # outright means a slow/rate-limited/briefly-down connection recovers
    # on its own instead of requiring a manual restart every time.
    max_attempts = 5
    delay = 5
    for attempt in range(1, max_attempts + 1):
        try:
            app = build_application()
            logger.info("Starting bot (polling mode)...")
            app.run_polling(allowed_updates=Update.ALL_TYPES)
            return
        except (TimedOut, NetworkError) as exc:
            if attempt == max_attempts:
                logger.error(
                    "Could not reach Telegram after %d attempts: %s\n"
                    "This is a network problem, not a bug in the bot — the "
                    "process can't open a connection to api.telegram.org "
                    "from this machine. Check: (1) this machine has working "
                    "internet access, (2) api.telegram.org isn't blocked by "
                    "a firewall, antivirus, or your ISP/network, (3) no "
                    "stray HTTP_PROXY/HTTPS_PROXY environment variables are "
                    "pointing at a dead proxy, and (4) if Telegram is "
                    "blocked on this network, set PROXY_URL in .env to a "
                    "working proxy.",
                    attempt,
                    exc,
                )
                raise
            logger.warning(
                "Network error reaching Telegram (attempt %d/%d): %s — "
                "retrying in %ds",
                attempt,
                max_attempts,
                exc,
                delay,
            )
            asyncio.run(asyncio.sleep(delay))
            delay = min(delay * 2, 60)


if __name__ == "__main__":
    main()
