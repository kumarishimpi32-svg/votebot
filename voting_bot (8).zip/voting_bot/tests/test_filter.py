import os
import tempfile
from services.name_filter import NameFilter


def test_blocks_exact_match():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("scam admin\n")
        path = f.name
    try:
        nf = NameFilter(path)
        assert nf.is_blocked("Scam Admin")
        assert nf.is_blocked("  scam   admin  ")
        assert not nf.is_blocked("Rahul Kumar")
    finally:
        os.unlink(path)


def test_add_and_remove():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        path = f.name
    try:
        nf = NameFilter(path)
        nf.add("badword")
        assert nf.is_blocked("badword")
        assert nf.remove("badword")
        assert not nf.is_blocked("badword")
    finally:
        os.unlink(path)


def test_not_overly_aggressive_on_short_names():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("ram\n")  # a name fragment that's also a common first name
        path = f.name
    try:
        nf = NameFilter(path)
        # exact match still blocks
        assert nf.is_blocked("Ram")
    finally:
        os.unlink(path)
