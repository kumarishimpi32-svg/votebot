from utils.premium_style import premium_font, premium_font_italic, premium_mono, badge


def test_premium_font_preserves_length():
    text = "Giveaway Dashboard 123"
    styled = premium_font(text)
    assert len(styled) == len(text)


def test_premium_font_transforms_letters_and_digits():
    styled = premium_font("A9")
    assert styled != "A9"
    assert styled[0] == "\U0001D5D4"  # Mathematical Sans-Serif Bold Capital A
    assert styled[1] == "\U0001D7F5"  # Mathematical Sans-Serif Bold Digit Nine


def test_premium_font_passes_through_non_latin_and_emoji():
    text = "🎁 गिवअवे ¡Hola!"
    styled = premium_font(text)
    assert "🎁" in styled
    assert "गिवअवे" in styled  # non-Latin scripts untouched
    assert "¡" in styled and "!" in styled


def test_premium_font_roundtrip_via_unicodedata_category_is_letter_like():
    styled = premium_font("Vote")
    # Every transformed char should differ from ASCII but still be a single
    # printable code point (not decomposed / not empty)
    assert all(len(ch.encode("utf-8")) > 0 for ch in styled)


def test_italic_and_mono_variants_differ_from_bold():
    text = "Premium"
    assert premium_font(text) != premium_font_italic(text)
    assert premium_font(text) != premium_mono(text)


def test_badge_format():
    assert badge("PREMIUM") == "⟦ PREMIUM ⟧"
