import asyncio
import time
import pytest
from services.premium_service import PremiumService


@pytest.mark.asyncio
async def test_fresh_activation(records, audit):
    ps = PremiumService(records, audit)
    acc, prev, new = await ps.activate_or_extend(user_id=1, actor_id=1, duration_days=30, source="test")
    assert prev is None
    assert new > time.time()
    assert await ps.is_active(1)


@pytest.mark.asyncio
async def test_renewal_extends_not_resets(records, audit):
    ps = PremiumService(records, audit)
    _, _, first_expiry = await ps.activate_or_extend(user_id=1, actor_id=1, duration_days=10, source="test")
    _, prev_expiry, new_expiry = await ps.activate_or_extend(user_id=1, actor_id=1, duration_days=10, source="test")
    assert prev_expiry == first_expiry
    assert new_expiry > first_expiry
    # Duration added should be ~10 days, not reset to "now + 10 days"
    assert abs((new_expiry - first_expiry) - 10 * 86400) < 5


@pytest.mark.asyncio
async def test_revoke(records, audit):
    ps = PremiumService(records, audit)
    await ps.activate_or_extend(user_id=1, actor_id=1, duration_days=30, source="test")
    await ps.revoke(1, actor_id=1)
    assert not await ps.is_active(1)


@pytest.mark.asyncio
async def test_expiry_warning_fires_once_per_threshold(records, audit):
    ps = PremiumService(records, audit)
    acc, _, _ = await ps.activate_or_extend(user_id=7, actor_id=1, duration_days=1, source="test")

    due = await ps.accounts_needing_expiry_warning(thresholds_days=(7, 3, 1))
    assert len(due) == 1
    matched_acc, threshold, covered = due[0]
    # Most urgent/accurate threshold is chosen for the message...
    assert threshold == 1
    # ...but ALL crossed thresholds get marked covered so no stale
    # "7 days left" message can go out after this.
    assert set(covered) == {1, 3, 7}
    await ps.mark_warned(matched_acc.id, covered)

    # Second sweep before any time passes should NOT fire again (no spam)
    due_again = await ps.accounts_needing_expiry_warning(thresholds_days=(7, 3, 1))
    assert len(due_again) == 0


@pytest.mark.asyncio
async def test_renewal_resets_expiry_warnings_for_next_cycle(records, audit):
    ps = PremiumService(records, audit)
    acc, _, _ = await ps.activate_or_extend(user_id=8, actor_id=1, duration_days=1, source="test")
    due = await ps.accounts_needing_expiry_warning()
    assert len(due) == 1
    _, _, covered = due[0]
    await ps.mark_warned(due[0][0].id, covered)

    # Renew far into the future — warned_thresholds should be cleared so the
    # NEXT time this account approaches expiry, warnings fire again.
    await ps.activate_or_extend(user_id=8, actor_id=1, duration_days=365, source="test")
    refreshed = await ps.get_account(8)
    assert refreshed.data.get("warned_thresholds") == []


@pytest.mark.asyncio
async def test_concurrent_first_activation_creates_only_one_account(records, audit):
    """Regression test: two payments for the same brand-new user (no
    PREMIUM_ACCOUNT yet) approved at the same moment used to be able to
    both pass the 'does an account exist yet' read before either had
    written, each creating its OWN PREMIUM_ACCOUNT record for the same
    user_id. get_account()/find_one() would then return only one of them
    arbitrarily, silently dropping whichever payment's duration landed on
    the record nobody looks at again."""
    ps = PremiumService(records, audit)
    results = await asyncio.gather(
        ps.activate_or_extend(user_id=55, actor_id=1, duration_days=10, source="test"),
        ps.activate_or_extend(user_id=55, actor_id=1, duration_days=20, source="test"),
    )
    accounts = await records.find("PREMIUM_ACCOUNT", user_id=55)
    assert len(accounts) == 1  # never two separate account records for one user
    # Both durations should be reflected — either as two sequential
    # extensions or as the "lost the race, extend what exists" fallback —
    # never as one payment's days simply vanishing.
    final_expiry = accounts[0].data["expires_at"]
    assert final_expiry > time.time() + 25 * 86400  # ~10+20 days, not just one
