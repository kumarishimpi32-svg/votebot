"""
tests/test_keyboard_compat.py
Proves the app doesn't hard-crash if deployed against an older
python-telegram-bot that predates the `style` field (added in 22.7 for
Bot API 9.4). This exact scenario — a stale/cached dependency install —
is a realistic real-world failure mode, not a hypothetical: every single
keyboard in the app uses `style`, so without a fallback, an old library
would break literally every button, including /start's home menu.
"""
from __future__ import annotations
from utils import keyboards


class OldInlineKeyboardButton:
    """Simulates python-telegram-bot < 22.7: no `style` kwarg accepted."""
    def __init__(self, text, callback_data=None, url=None):
        if callback_data is not None:
            self.callback_data = callback_data
        if url is not None:
            self.url = url
        self.text = text

    def __repr__(self):
        return f"OldButton({self.text!r})"


def test_btn_falls_back_when_style_unsupported(monkeypatch):
    monkeypatch.setattr(keyboards, "InlineKeyboardButton", OldInlineKeyboardButton)
    btn = keyboards._btn("Vote", "vote:g1:p1", style="success")
    assert btn.callback_data == "vote:g1:p1"
    assert not hasattr(btn, "style")  # never crashed, just degraded


def test_btn_uses_style_when_supported():
    # Sanity check the normal (current, real) path still applies style
    btn = keyboards._btn("Vote", "vote:g1:p1", style="success")
    assert btn.to_dict().get("style") == "success"


def test_url_btn_falls_back_when_style_unsupported(monkeypatch):
    monkeypatch.setattr(keyboards, "InlineKeyboardButton", OldInlineKeyboardButton)
    btn = keyboards._url_btn("Open", "https://example.com", style="primary")
    assert btn.url == "https://example.com"
    assert not hasattr(btn, "style")


def test_full_keyboard_builds_without_crashing_on_old_library(monkeypatch):
    """The actual scenario from the bug report: does /start's home_menu()
    survive an old-library environment instead of throwing?"""
    monkeypatch.setattr(keyboards, "InlineKeyboardButton", OldInlineKeyboardButton)
    kb = keyboards.home_menu()  # must not raise
    assert len(kb.inline_keyboard) == 2

    kb2 = keyboards.host_dashboard("giveaway_abc123456789")  # must not raise
    assert len(kb2.inline_keyboard) == 6
