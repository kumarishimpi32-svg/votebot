"""
tests/conftest.py
A minimal fake Bot so services can be tested without hitting the real
Telegram API or needing a live BOT_TOKEN.
"""
from __future__ import annotations
import asyncio
import pytest
from storage.telegram_storage import TelegramStorage
from storage.record_manager import RecordManager
from services.audit_service import AuditService


class FakeMessage:
    def __init__(self, message_id: int):
        self.message_id = message_id


class FakeBot:
    def __init__(self):
        self._next_id = 1
        self.sent = []

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        await asyncio.sleep(0)  # real network calls always yield — force genuine interleaving in concurrency tests
        msg = FakeMessage(self._next_id)
        self._next_id += 1
        self.sent.append((chat_id, text))
        return msg


@pytest.fixture
def fake_bot():
    return FakeBot()


@pytest.fixture
def storage(fake_bot, tmp_path, monkeypatch):
    import storage.telegram_storage as ts_mod
    monkeypatch.setattr(ts_mod, "SNAPSHOT_DIR", str(tmp_path))
    monkeypatch.setattr(ts_mod, "SNAPSHOT_PATH", str(tmp_path / "snapshot.json"))
    return TelegramStorage(fake_bot, storage_chat_id=-100123)


@pytest.fixture
def records(storage):
    return RecordManager(storage)


@pytest.fixture
def audit(records):
    return AuditService(records)
