"""
tests/test_channel_service.py

Multi-channel CONNECT system (mega-prompt Phase 2 / spec §5, §6, §9-§14).
Covers: Add Channel verification (presence/admin/permissions/requester-
admin), duplicate-connection prevention, per-owner data isolation, and
active-channel switching (including re-verification and blocking a
switch when the bot's admin rights were revoked after the initial
connect).
"""
from __future__ import annotations
import asyncio
import pytest
from telegram.error import Forbidden, BadRequest
from services.channel_service import ChannelService, ChannelError
from security.permissions import Permissions

ALICE, BOB = 1001, 2002
BOT_ID = 999


class FakeChat:
    def __init__(self, id, type, title=None, username=None):
        self.id, self.type, self.title, self.username = id, type, title, username


class FakeMember:
    def __init__(self, status, can_post_messages=False, can_edit_messages=False):
        self.status = status
        self.can_post_messages = can_post_messages
        self.can_edit_messages = can_edit_messages


class FakeChannelBot:
    """A fake Bot exposing just enough of get_chat/get_chat_member to drive
    every branch in ChannelService, with a fixed cast of channels/members."""

    def __init__(self):
        self.id = BOT_ID
        self.chats = {
            -100111: FakeChat(-100111, "channel", "Alice's Channel", "alice_channel"),
            -100222: FakeChat(-100222, "channel", "Bob's Channel", "bob_channel"),
            -100333: FakeChat(-100333, "channel", "No-Perms Channel", "noperm_channel"),
            -100444: FakeChat(-100444, "channel", "Absent-Bot Channel", "absent_channel"),
            -100555: FakeChat(-100555, "channel", "Not-Admin-Bot Channel", "notadmin_channel"),
            -100666: FakeChat(-100666, "supergroup", "A Group, Not A Channel", "a_group"),
        }
        self.members = {
            (-100111, BOT_ID): FakeMember("administrator", True, True),
            (-100111, ALICE): FakeMember("creator"),
            (-100222, BOT_ID): FakeMember("administrator", True, True),
            (-100222, BOB): FakeMember("creator"),
            (-100333, BOT_ID): FakeMember("administrator", False, False),
            (-100333, ALICE): FakeMember("creator"),
            (-100444, ALICE): FakeMember("creator"),  # no entry for the bot itself -> "absent"
            (-100555, BOT_ID): FakeMember("member"),
            (-100555, ALICE): FakeMember("creator"),
            (-100666, BOT_ID): FakeMember("administrator", True, True),
            (-100666, ALICE): FakeMember("creator"),
        }

    async def get_chat(self, chat_id):
        ref = chat_id
        if isinstance(ref, str) and ref.startswith("@"):
            for c in self.chats.values():
                if c.username == ref[1:]:
                    return c
            raise BadRequest("chat not found")
        if ref in self.chats:
            return self.chats[ref]
        raise BadRequest("chat not found")

    async def get_chat_member(self, chat_id, user_id):
        key = (chat_id, user_id)
        if key in self.members:
            return self.members[key]
        raise Forbidden("member not found / bot not in chat")

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        await asyncio.sleep(0)
        class Msg:
            pass
        m = Msg()
        m.message_id = 1
        return m


@pytest.fixture
def channel_bot():
    return FakeChannelBot()


@pytest.fixture
def channel_service(channel_bot, records, audit):
    return ChannelService(channel_bot, records, audit)


@pytest.mark.asyncio
async def test_add_channel_happy_path(channel_service):
    rec = await channel_service.add_channel(ALICE, "@alice_channel")
    assert rec.data["owner_id"] == ALICE
    assert rec.data["chat_id"] == -100111
    assert rec.data["verified"] is True


@pytest.mark.asyncio
async def test_add_channel_duplicate_by_same_owner_rejected(channel_service):
    await channel_service.add_channel(ALICE, "@alice_channel")
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(ALICE, "@alice_channel")
    assert exc.value.code == "already_connected_self"


@pytest.mark.asyncio
async def test_add_channel_requires_requester_to_be_channel_admin(channel_service):
    """Bob is not an admin of Alice's channel — connecting it must fail
    regardless of whether it's already connected to someone else."""
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(BOB, "@alice_channel")
    assert exc.value.code == "requester_not_admin"


@pytest.mark.asyncio
async def test_add_channel_rejects_missing_bot_permissions(channel_service):
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(ALICE, "@noperm_channel")
    assert exc.value.code == "missing_permissions"


@pytest.mark.asyncio
async def test_add_channel_rejects_when_bot_absent(channel_service):
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(ALICE, "@absent_channel")
    assert exc.value.code == "bot_absent"


@pytest.mark.asyncio
async def test_add_channel_rejects_when_bot_not_admin(channel_service):
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(ALICE, "@notadmin_channel")
    assert exc.value.code == "bot_not_admin"


@pytest.mark.asyncio
async def test_add_channel_rejects_non_channel_chats(channel_service):
    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(ALICE, "-100666")
    assert exc.value.code == "not_a_channel"


@pytest.mark.asyncio
async def test_add_channel_accepts_numeric_id_and_username_forms(channel_service):
    rec_a = await channel_service.add_channel(ALICE, "-100111")
    channels = await channel_service.list_for_owner(ALICE)
    assert len(channels) == 1 and channels[0].id == rec_a.id


@pytest.mark.asyncio
async def test_per_owner_isolation_in_my_channels(channel_service):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")
    b_rec = await channel_service.add_channel(BOB, "@bob_channel")

    alice_channels = await channel_service.list_for_owner(ALICE)
    bob_channels = await channel_service.list_for_owner(BOB)
    assert [c.id for c in alice_channels] == [a_rec.id]
    assert [c.id for c in bob_channels] == [b_rec.id]


@pytest.mark.asyncio
async def test_get_owned_refuses_cross_owner_access(channel_service):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")
    b_rec = await channel_service.add_channel(BOB, "@bob_channel")

    assert await channel_service.get_owned(b_rec.id, ALICE) is None
    assert await channel_service.get_owned(a_rec.id, BOB) is None
    assert await channel_service.get_owned(a_rec.id, ALICE) is not None


@pytest.mark.asyncio
async def test_is_channel_owner_permission_check(channel_service, records, channel_bot):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")
    perms = Permissions(channel_bot, records)
    assert await perms.is_channel_owner(a_rec.id, ALICE) is True
    assert await perms.is_channel_owner(a_rec.id, BOB) is False
    assert await perms.is_channel_owner("channel_doesnotexist", ALICE) is False


@pytest.mark.asyncio
async def test_set_active_channel_cannot_target_another_hosts_channel(channel_service):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")
    b_rec = await channel_service.add_channel(BOB, "@bob_channel")

    with pytest.raises(ChannelError) as exc:
        await channel_service.set_active_channel(ALICE, b_rec.id)
    assert exc.value.code == "not_found"  # never leaks that Bob's channel exists


@pytest.mark.asyncio
async def test_set_active_channel_happy_path(channel_service):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")
    activated = await channel_service.set_active_channel(ALICE, a_rec.id)
    assert activated.id == a_rec.id

    active_now = await channel_service.get_active_channel(ALICE)
    assert active_now is not None and active_now.id == a_rec.id


@pytest.mark.asyncio
async def test_set_active_channel_blocks_if_bot_lost_admin_since_connect(channel_service, channel_bot):
    a_rec = await channel_service.add_channel(ALICE, "@alice_channel")

    # Simulate the bot being demoted on Alice's channel after connecting.
    channel_bot.members[(-100111, BOT_ID)] = FakeMember("member")

    with pytest.raises(ChannelError) as exc:
        await channel_service.set_active_channel(ALICE, a_rec.id)
    assert exc.value.code == "bot_not_admin"


@pytest.mark.asyncio
async def test_switching_active_channel_between_two_owned_channels(channel_service):
    a1 = await channel_service.add_channel(ALICE, "@alice_channel")
    # Give Alice a second channel she also administers.
    channel_service.bot.chats[-100777] = FakeChat(-100777, "channel", "Alice's Second Channel", "alice_second")
    channel_service.bot.members[(-100777, BOT_ID)] = FakeMember("administrator", True, True)
    channel_service.bot.members[(-100777, ALICE)] = FakeMember("creator")
    a2 = await channel_service.add_channel(ALICE, "@alice_second")

    await channel_service.set_active_channel(ALICE, a1.id)
    assert (await channel_service.get_active_channel(ALICE)).id == a1.id

    await channel_service.set_active_channel(ALICE, a2.id)
    assert (await channel_service.get_active_channel(ALICE)).id == a2.id
