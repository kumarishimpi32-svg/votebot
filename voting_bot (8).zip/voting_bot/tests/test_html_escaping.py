"""
tests/test_html_escaping.py
Regression coverage for a real HTML-injection bug: participant names,
giveaway titles/descriptions/prizes, and payment references are all
free text a user controls, and every one of them used to be interpolated
raw into parse_mode='HTML' messages — including public channel posts
(winner announcements, giveaway listings) anyone could trigger just by
registering or creating a giveaway. A crafted name like
'<a href="...">Admin</a>' would render as a spoofed link for everyone
who saw it. These tests lock in that the escaping fix stays in place.
"""
from __future__ import annotations
from utils.formatting import esc, participant_card, giveaway_announcement, heading
from services.leaderboard import LeaderboardService


PAYLOAD = '<a href="http://evil.example">Admin</a><b>bold</b>'
ESCAPED = "&lt;a href=&quot;http://evil.example&quot;&gt;Admin&lt;/a&gt;&lt;b&gt;bold&lt;/b&gt;"


def test_esc_escapes_html_metacharacters():
    assert esc(PAYLOAD) == ESCAPED


def test_esc_handles_none():
    assert esc(None) == ""


def test_participant_card_escapes_name():
    text = participant_card(PAYLOAD, 12345, 3)
    assert "<a href=" not in text
    assert ESCAPED in text


def test_giveaway_announcement_escapes_title_description_prize():
    text = giveaway_announcement(PAYLOAD, PAYLOAD, PAYLOAD, 5, 1, "gw_1")
    # The payload's own tags must never appear live — only our trusted
    # tags (<b>, <i>, the divider, etc.) should render as real markup.
    assert "<a href=" not in text
    assert "<b>bold</b>" not in text
    # Description isn't run through the stylized-font transform, so it's
    # the one field we can assert byte-for-byte escaped.
    assert ESCAPED in text


def test_heading_escapes_text_and_sub():
    text = heading("🎁", PAYLOAD, sub=PAYLOAD)
    # heading() applies a stylized-font transform on top of escaping, so
    # the exact entity string won't survive intact — what matters is that
    # the payload's tags never appear live.
    assert "<a href=" not in text
    assert "<b>bold</b>" not in text


def test_leaderboard_free_escapes_participant_names(records_no_fixture=None):
    class FakeRecord:
        def __init__(self, name, votes, status="approved"):
            self.status = status
            self.data = {"name": name, "votes": votes}

    ranked = [FakeRecord(PAYLOAD, 10)]
    lb = LeaderboardService(records=None)
    text = lb.format_free(ranked)
    assert "<a href=" not in text
    assert ESCAPED in text
