"""
tests/test_participant_state.py
BUG 4 from the audit: a REJECTED participant used to be told "You have
already joined the giveaway." because already_registered() matched ANY
existing record for that user regardless of status. Confirms:
  - REJECTED never counts as already-joined
  - PENDING and APPROVED correctly DO block re-entry
  - resubmission after rejection actually works and goes through
    moderation again
"""
from __future__ import annotations
import pytest
from services.participant_service import ParticipantService
from services.moderation_pipeline import ModerationOutcome


class FixedModeration:
    def __init__(self, outcome, reason="test"):
        self.outcome = outcome
        self.reason = reason

    async def evaluate(self, name):
        return self.outcome, self.reason


GIVEAWAY_ID = "g1"
USER_ID = 42


@pytest.mark.asyncio
async def test_rejected_participant_is_not_already_registered(records, audit):
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT, "bad name"))
    rec, status = await ps.register(GIVEAWAY_ID, USER_ID, "BadName")
    assert status == "rejected"

    # This is the exact bug: REJECTED must not be treated as "joined".
    assert await ps.already_registered(GIVEAWAY_ID, USER_ID) is False
    assert await ps.get_active_entry(GIVEAWAY_ID, USER_ID) is None


@pytest.mark.asyncio
async def test_rejected_participant_can_resubmit_and_get_approved(records, audit):
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT, "bad name"))
    rec1, status1 = await ps.register(GIVEAWAY_ID, USER_ID, "BadName")
    assert status1 == "rejected"

    ps.moderation = FixedModeration(ModerationOutcome.APPROVE)  # user tries again with a clean name
    rec2, status2 = await ps.register(GIVEAWAY_ID, USER_ID, "CleanName")
    assert status2 == "approved"
    assert rec2.id != rec1.id  # a new entry, the old rejected one is untouched
    assert (await records.get(rec1.id)).status == "rejected"


@pytest.mark.asyncio
async def test_pending_participant_is_blocked_from_reentry(records, audit):
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.MANUAL_REVIEW, "needs human review"))
    rec, status = await ps.register(GIVEAWAY_ID, USER_ID, "MaybeName")
    assert status == "pending_review"

    assert await ps.already_registered(GIVEAWAY_ID, USER_ID) is True
    active = await ps.get_active_entry(GIVEAWAY_ID, USER_ID)
    assert active is not None and active.id == rec.id


@pytest.mark.asyncio
async def test_approved_participant_is_blocked_from_reentry(records, audit):
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.APPROVE))
    rec, status = await ps.register(GIVEAWAY_ID, USER_ID, "GoodName")
    assert status == "approved"

    assert await ps.already_registered(GIVEAWAY_ID, USER_ID) is True
    rec2, status2 = await ps.register(GIVEAWAY_ID, USER_ID, "GoodName")
    assert rec2 is None and status2 == "already_registered"


@pytest.mark.asyncio
async def test_latest_entry_reflects_most_recent_rejection_reason(records, audit):
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT, "first reason"))
    await ps.register(GIVEAWAY_ID, USER_ID, "Name1")

    latest = await ps.latest_entry(GIVEAWAY_ID, USER_ID)
    assert latest.status == "rejected"
    assert latest.data.get("moderation_reason") == "first reason"
