"""
tests/test_moderation_override.py
Proves the actual fix: every registration decision (approve/reject/pending)
now posts a review card with live buttons, and admins can override ANY
prior decision — not just ones that were originally "pending_review".
"""
from __future__ import annotations
import pytest
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.contestant_service import ContestantService
from services.notification_service import NotificationService
from services.moderation_pipeline import ModerationOutcome
from security.permissions import Permissions
from handlers import participant as participant_handlers
from handlers import moderation as moderation_handlers


class FixedModeration:
    """Lets tests force a specific moderation outcome deterministically."""
    def __init__(self, outcome, reason="test"):
        self.outcome = outcome
        self.reason = reason

    async def evaluate(self, name):
        return self.outcome, self.reason


class FakeUser:
    def __init__(self, id_):
        self.id = id_


class FakeMessage:
    def __init__(self, text, user_id, message_id=0):
        self.text = text
        self.from_user = FakeUser(user_id)
        self.replies = []
        self.text_html = "🛡 <b>MODERATION DECISION</b>\n\nsome content"
        self.reply_markup = None
        self.message_id = message_id

    async def reply_text(self, text, parse_mode=None, reply_markup=None):
        self.replies.append(text)


class FakeUpdateMsg:
    def __init__(self, message, user_id):
        self.message = message
        self.effective_user = FakeUser(user_id)


class FakeQuery:
    def __init__(self, data, user_id, message):
        self.data = data
        self.from_user = FakeUser(user_id)
        self.message = message
        self.edited_text = None
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, text, parse_mode=None, reply_markup=None):
        self.edited_text = text
        self.message.text_html = text  # so a second override sees the updated text


class FakeUpdateCb:
    def __init__(self, query, user_id):
        self.callback_query = query
        self.effective_user = FakeUser(user_id)


class FakeBot:
    def __init__(self):
        self.sent = []

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        self.sent.append((chat_id, text))
        return FakeMessage(text, 0)


class FakeContext:
    def __init__(self, bot_data, bot, user_data):
        self.bot_data = bot_data
        self.bot = bot
        self.user_data = user_data


REVIEW_CHAT_ID = -100999
HOST_ID = 1
PARTICIPANT_TG_ID = 42


def _permissive_anti_abuse():
    class _AA:
        def allow_registration(self, user_id):
            return True
    return _AA()


async def _make_giveaway(records, audit, review_chat_id=REVIEW_CHAT_ID):
    gs = GiveawayService(records, audit)
    return await gs.create_giveaway(HOST_ID, -100111, {"title": "Test GW", "review_chat_id": review_chat_id})


@pytest.mark.asyncio
async def test_auto_approved_still_gets_review_card(records, audit):
    giveaway = await _make_giveaway(records, audit)
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.APPROVE))
    gs = GiveawayService(records, audit)
    fake_bot = FakeBot()
    bot_data = {
        "giveaway_service": gs,
        "participant_service": ps,
        "anti_abuse": _permissive_anti_abuse(),
        "contestant_service": ContestantService(records, gs, ps),
    }
    message = FakeMessage("Rahul", PARTICIPANT_TG_ID)
    update = FakeUpdateMsg(message, PARTICIPANT_TG_ID)
    context = FakeContext(bot_data, fake_bot, {"awaiting_name_for": giveaway.id})

    await participant_handlers.handle_free_text(update, context)

    # Approval now ALSO publishes the contestant to the voting channel —
    # that's the auto-publish-on-approval fix — in addition to the review
    # card, which must still be sent regardless of the automated outcome.
    assert len(fake_bot.sent) == 2
    assert fake_bot.sent[0][0] == giveaway.data["channel_id"]  # contestant profile posted first
    assert fake_bot.sent[1][0] == REVIEW_CHAT_ID
    assert "Auto-approved" in fake_bot.sent[1][1]


@pytest.mark.asyncio
async def test_auto_rejected_still_gets_review_card_with_buttons(records, audit):
    """This is the exact bug reported: a maliciously-flagged name previously
    had NO approve/reject option surfaced anywhere."""
    giveaway = await _make_giveaway(records, audit)
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT, reason="hate speech"))
    fake_bot = FakeBot()
    bot_data = {
        "giveaway_service": GiveawayService(records, audit),
        "participant_service": ps,
        "anti_abuse": _permissive_anti_abuse(),
    }
    message = FakeMessage("BadWordName", PARTICIPANT_TG_ID)
    update = FakeUpdateMsg(message, PARTICIPANT_TG_ID)
    context = FakeContext(bot_data, fake_bot, {"awaiting_name_for": giveaway.id})

    await participant_handlers.handle_free_text(update, context)

    assert len(fake_bot.sent) == 1
    sent_text = fake_bot.sent[0][1]
    assert "Auto-rejected" in sent_text
    # The reason (and, since this entry was flagged, the submitted name
    # itself) must never appear in plain text — Telegram spoiler-masked
    # only, first/last letter visible, so a host can still recognize it
    # without the bot plainly reposting content that broke the rules.
    assert "<tg-spoiler>" in sent_text
    assert "hate speech" not in sent_text
    assert "BadWordName" not in sent_text
    assert "h**e s****h" in sent_text  # masked "hate speech"
    assert "B*********e" in sent_text  # masked "BadWordName"


@pytest.mark.asyncio
async def test_admin_can_override_an_auto_rejected_decision(records, audit):
    """Previously: pressing Approve/Reject on anything not 'pending_review'
    was blocked with 'Already actioned'. Now overriding is always allowed."""
    giveaway = await _make_giveaway(records, audit)
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT, reason="flagged"))
    rec, status = await ps.register(giveaway.id, PARTICIPANT_TG_ID, "SomeName")
    assert status == "rejected"

    class DummyBot:
        pass
    permissions = Permissions(DummyBot(), records)

    async def fake_is_review_admin(giveaway_id, user_id):
        return user_id == HOST_ID
    permissions.is_review_admin = fake_is_review_admin

    notifications = NotificationService(bot=FakeBot())
    gs = GiveawayService(records, audit)
    bot_data = {
        "participant_service": ps,
        "giveaway_service": gs,
        "permissions": permissions,
        "notifications": notifications,
        "contestant_service": ContestantService(records, gs, ps),
    }

    message = FakeMessage("card text", HOST_ID)
    query = FakeQuery("review_ok:" + rec.id, HOST_ID, message)
    update = FakeUpdateCb(query, HOST_ID)
    context = FakeContext(bot_data, FakeBot(), {})

    await moderation_handlers.review_callback(update, context)

    updated = await records.get(rec.id)
    assert updated.status == "approved"  # successfully overridden
    assert any("APPROVED" in (a[0] or "") for a in query.answers)
