"""
tests/test_giveaway_wizard.py

REWRITTEN: creation is no longer a multi-step wizard (channel picker ->
title -> description -> prize -> min-votes -> max-winners -> premium-only
image-protection question). Pressing Create now creates the giveaway
immediately, using the single pre-configured voting channel and sensible
defaults — no typed or tapped input at all.
"""
from __future__ import annotations
import pytest
from services.giveaway_service import GiveawayService
from handlers import giveaway_wizard as wizard
from config import CONFIG


class FakeUser:
    def __init__(self, id_, first_name="Host"):
        self.id = id_
        self.first_name = first_name
        self.username = None


class FakeMessage:
    def __init__(self, user_id):
        self.from_user = FakeUser(user_id)
        self.replies = []

    async def reply_text(self, text, parse_mode=None, reply_markup=None):
        self.replies.append(text)


class FakeUpdateMsg:
    def __init__(self, message, user_id):
        self.message = message
        self.effective_user = FakeUser(user_id)
        self.callback_query = None


class FakeBot:
    def __init__(self):
        self.username = "TestVoteBot"


class FakeContext:
    def __init__(self, bot_data, user_data):
        self.bot_data = bot_data
        self.user_data = user_data
        self.bot = FakeBot()


HOST_ID = 777


@pytest.mark.asyncio
async def test_create_giveaway_is_instant_with_no_questions(records, audit):
    """The actual product requirement: pressing Create asks NOTHING and
    the giveaway exists immediately, using the pre-configured channel."""
    giveaway_service = GiveawayService(records, audit)
    bot_data = {"giveaway_service": giveaway_service}
    user_data = {}
    context = FakeContext(bot_data, user_data)

    msg = FakeMessage(HOST_ID)
    update = FakeUpdateMsg(msg, HOST_ID)

    await wizard.start_wizard(update, context)

    # No wizard state of any kind is left behind — there is nothing to
    # continue, because there was never a multi-step flow.
    assert "gw_wizard" not in user_data

    giveaways = await giveaway_service.list_by_host(HOST_ID)
    assert len(giveaways) == 1
    rec = giveaways[0]
    assert rec.data["state"] == "ACTIVE"
    assert rec.data["min_votes"] == 0
    assert rec.data["max_winners"] == 1
    # The channel comes from configuration, never from a typed/tapped step.
    assert rec.data["channel_id"] == wizard._resolve_channel_id(giveaway_service)

    # The host is shown exactly one thing: the link.
    assert len(msg.replies) == 1
    assert rec.id in msg.replies[0]
    assert "IMAGE PROTECTION" not in msg.replies[0].upper()


@pytest.mark.asyncio
async def test_double_tap_create_makes_two_independent_giveaways_not_a_crash(records, audit):
    """Pressing Create twice is a deliberate 'make another giveaway'
    action (there's no shared draft state to collide on), so it must not
    error or silently merge state — each call is an independent,
    well-formed creation."""
    giveaway_service = GiveawayService(records, audit)
    bot_data = {"giveaway_service": giveaway_service}
    context = FakeContext(bot_data, {})

    for _ in range(2):
        msg = FakeMessage(HOST_ID)
        update = FakeUpdateMsg(msg, HOST_ID)
        await wizard.start_wizard(update, context)

    giveaways = await giveaway_service.list_by_host(HOST_ID)
    assert len(giveaways) == 2
    assert giveaways[0].id != giveaways[1].id


def test_no_channel_selection_needed_because_it_is_configured():
    """There is deliberately no chat-picker step anymore: the voting
    channel is fixed by CONFIG.voting_channel."""
    assert CONFIG.voting_channel  # configured, non-empty
    assert not hasattr(wizard, "handle_chat_shared")
    assert not hasattr(wizard, "image_protection_picked")
