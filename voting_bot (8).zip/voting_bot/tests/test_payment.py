import asyncio
import pytest
from services.premium_service import PremiumService
from services.payment_service import PaymentService, PaymentError


@pytest.mark.asyncio
async def test_payment_does_not_auto_activate(records, audit):
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)

    payment = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="TXN123")
    assert payment.status == "pending"
    assert not await premium.is_active(42)  # must NOT be active yet


@pytest.mark.asyncio
async def test_approval_activates_premium(records, audit):
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)
    payment = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="TXN999")

    await payments.approve(payment.id, verifier_id=1)
    assert await premium.is_active(42)


@pytest.mark.asyncio
async def test_rejection_does_not_activate(records, audit):
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)
    payment = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="TXN000")

    await payments.reject(payment.id, verifier_id=1, reason="fake proof")
    assert not await premium.is_active(42)


@pytest.mark.asyncio
async def test_duplicate_approval_blocked(records, audit):
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)
    payment = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="TXN777")

    await payments.approve(payment.id, verifier_id=1)
    with pytest.raises(PaymentError):
        await payments.approve(payment.id, verifier_id=1)


@pytest.mark.asyncio
async def test_sequential_duplicate_reference_across_payments_blocked(records, audit):
    """Two different payment records (possibly different users) sharing the
    same reference: once one is approved, approving the other must fail
    and must not grant Premium."""
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)
    p1 = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="SHARED_REF")
    p2 = await payments.submit_payment(user_id=99, plan_record_id=plan.id, reference="SHARED_REF")

    await payments.approve(p1.id, verifier_id=1)
    assert await premium.is_active(42)

    with pytest.raises(PaymentError):
        await payments.approve(p2.id, verifier_id=1)
    assert not await premium.is_active(99)
    p2_after = await records.get(p2.id)
    assert p2_after.status == "rejected"  # reverted, not left dangling as "approved"


@pytest.mark.asyncio
async def test_concurrent_duplicate_reference_approvals_never_both_succeed(records, audit):
    """Regression test for a real TOCTOU race: the duplicate-reference
    check used to run as an unlocked read BEFORE the atomic pending->
    approved transition, so two different payment records sharing a
    reference could both pass the check before either had transitioned,
    then both independently win their own compare-and-swap — silently
    activating Premium twice off a single real payment. Firing both
    approvals concurrently must never let both users end up active."""
    premium = PremiumService(records, audit)
    payments = PaymentService(records, audit, premium)
    plan = await premium.create_plan(1, "p1", "30 Days", 30, 499)
    p1 = await payments.submit_payment(user_id=42, plan_record_id=plan.id, reference="RACE_REF")
    p2 = await payments.submit_payment(user_id=99, plan_record_id=plan.id, reference="RACE_REF")

    results = await asyncio.gather(
        payments.approve(p1.id, verifier_id=1),
        payments.approve(p2.id, verifier_id=1),
        return_exceptions=True,
    )
    successes = [r for r in results if not isinstance(r, Exception)]
    assert len(successes) <= 1  # never both — the whole point of this test

    active_count = sum([await premium.is_active(42), await premium.is_active(99)])
    assert active_count <= 1  # never both users activated off one reference
