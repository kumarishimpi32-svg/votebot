"""
Regression test for the "There is no text in the message to edit" BadRequest.

Root cause: /start sends the welcome banner as a photo (caption=...) when
one is configured. Every callback handler reachable from that message was
calling `query.edit_message_text(...)`, which Telegram rejects on photo
messages (they have a caption, not text). `safe_edit` must detect that and
use `edit_message_caption` instead.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock
from utils.telegram_helpers import safe_edit


@pytest.mark.asyncio
async def test_safe_edit_uses_caption_for_photo_message():
    query = MagicMock()
    query.message.photo = [MagicMock()]  # non-empty -> this is a photo message
    query.edit_message_text = AsyncMock(
        side_effect=AssertionError("edit_message_text must not be called on a photo message")
    )
    query.edit_message_caption = AsyncMock(return_value="ok")

    await safe_edit(query, "🏠 HOME", parse_mode="HTML", reply_markup=None)

    query.edit_message_caption.assert_awaited_once_with(
        caption="🏠 HOME", parse_mode="HTML", reply_markup=None
    )
    query.edit_message_text.assert_not_awaited()


@pytest.mark.asyncio
async def test_safe_edit_uses_text_for_plain_message():
    query = MagicMock()
    query.message.photo = []  # not a photo message
    query.edit_message_text = AsyncMock(return_value="ok")
    query.edit_message_caption = AsyncMock(
        side_effect=AssertionError("edit_message_caption must not be called on a text message")
    )

    await safe_edit(query, "🏠 HOME", parse_mode="HTML", reply_markup=None)

    query.edit_message_text.assert_awaited_once_with(
        "🏠 HOME", parse_mode="HTML", reply_markup=None
    )
    query.edit_message_caption.assert_not_awaited()
