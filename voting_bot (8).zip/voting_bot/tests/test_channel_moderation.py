"""
tests/test_channel_moderation.py
This is the actual moderation requirement from the audit (distinct from
the removed participant "Image Protection" feature): watch the managed
channel for prohibited content and alert an admin, without ever spamming
the channel itself or re-alerting on the same message twice.
"""
from __future__ import annotations
import pytest
from services.channel_moderation_service import ChannelModerationService
from services.name_filter import NameFilter
from services.ai_moderation import Classification

CHAT_ID = -100777
ALERT_CHAT_ID = -100999


class FixedAi:
    def __init__(self, classification, reason="test"):
        self.classification = classification
        self.reason = reason
        self.calls = 0

    async def classify_text(self, text):
        self.calls += 1
        return self.classification, self.reason

    async def double_check(self, text):
        return await self.classify_text(text)


class FakeChat:
    def __init__(self, id_, username=None):
        self.id = id_
        self.username = username


class FakeBot:
    def __init__(self):
        self.sent = []

    async def get_chat(self, chat_id):
        return FakeChat(chat_id)

    async def send_message(self, chat_id, text, parse_mode=None):
        self.sent.append((chat_id, text))


@pytest.mark.asyncio
async def test_normal_content_never_produces_an_alert(records, audit):
    ai = FixedAi(Classification.SAFE)
    svc = ChannelModerationService(records, NameFilter(), ai, ALERT_CHAT_ID)

    alert = await svc.evaluate_channel_post(CHAT_ID, 1, "Congrats to the winner!", sender_id=10)

    assert alert is None
    bot = FakeBot()
    if alert:
        await svc.send_alert(bot, alert)
    assert bot.sent == []  # nothing sent to the channel or anywhere else


@pytest.mark.asyncio
async def test_prohibited_content_raises_exactly_one_alert(records, audit):
    ai = FixedAi(Classification.REJECT, reason="hate speech")
    svc = ChannelModerationService(records, NameFilter(), ai, ALERT_CHAT_ID)

    alert = await svc.evaluate_channel_post(CHAT_ID, 2, "some abusive text", sender_id=11)
    assert alert is not None

    bot = FakeBot()
    delivered = await svc.send_alert(bot, alert)

    assert delivered is True
    assert len(bot.sent) == 1
    assert bot.sent[0][0] == ALERT_CHAT_ID
    assert "MODERATION ALERT" in bot.sent[0][1]
    # The alert never goes to the channel itself — that would be spam in
    # the very channel it's supposed to protect.
    assert all(chat != CHAT_ID for chat, _ in bot.sent)


@pytest.mark.asyncio
async def test_same_message_is_never_evaluated_or_alerted_twice(records, audit):
    """Event-driven + idempotent: a duplicate delivery of the same
    channel_post update (Telegram retry, bot restart, a repeated
    background scan) must be a complete no-op the second time."""
    ai = FixedAi(Classification.REJECT, reason="spam link")
    svc = ChannelModerationService(records, NameFilter(), ai, ALERT_CHAT_ID)

    first = await svc.evaluate_channel_post(CHAT_ID, 3, "spammy content", sender_id=12)
    second = await svc.evaluate_channel_post(CHAT_ID, 3, "spammy content", sender_id=12)

    assert first is not None
    assert second is None  # already processed -> no re-alert
    assert ai.calls == 1  # not even re-classified the second time


@pytest.mark.asyncio
async def test_uncertain_ai_result_does_not_alert(records, audit):
    """When the AI is unavailable/uncertain, the service must not guess —
    silence, not a false alarm."""
    ai = FixedAi(Classification.UNCERTAIN, reason="AI moderation not configured")
    svc = ChannelModerationService(records, NameFilter(), ai, ALERT_CHAT_ID)

    alert = await svc.evaluate_channel_post(CHAT_ID, 4, "some text", sender_id=13)

    assert alert is None


@pytest.mark.asyncio
async def test_local_blocklist_short_circuits_without_calling_ai(records, audit):
    class ExplodingAi:
        async def classify_text(self, text):
            raise AssertionError("AI should not be called when the local filter already rejects")

    nf = NameFilter()
    nf._blocked.add("forbiddenword")
    svc = ChannelModerationService(records, nf, ExplodingAi(), ALERT_CHAT_ID)

    alert = await svc.evaluate_channel_post(CHAT_ID, 5, "this has forbiddenword in it", sender_id=14)

    assert alert is not None
    assert alert["classification"] == "REJECT"
