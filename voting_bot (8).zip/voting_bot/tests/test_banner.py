"""
tests/test_banner.py
Confirms the /admin banner flow actually stores a file_id and that
/start picks it up — this is exactly the kind of stateful multi-step
flow (command -> photo -> stored config -> read back later) that's easy
to wire wrong without a real end-to-end check.
"""
from __future__ import annotations
import pytest
from handlers import owner as owner_handlers
from handlers import start as start_handlers
from config import CONFIG


class FakeUser:
    def __init__(self, id_):
        self.id = id_
        self.first_name = "Test"
        self.username = "testuser"


class FakePhotoSize:
    def __init__(self, file_id):
        self.file_id = file_id


class FakeMessage:
    def __init__(self, user_id, photo=None):
        self.from_user = FakeUser(user_id)
        self.photo = photo
        self.replies = []
        self.photos_sent = []

    async def reply_text(self, text, parse_mode=None, reply_markup=None):
        self.replies.append(text)

    async def reply_photo(self, photo, caption=None, parse_mode=None, reply_markup=None):
        self.photos_sent.append((photo, caption))


class FakeUpdate:
    def __init__(self, message, user_id):
        self.message = message
        self.effective_user = message.from_user


class FakeContext:
    def __init__(self, bot_data, user_data):
        self.bot_data = bot_data
        self.user_data = user_data
        self.args = []


@pytest.mark.asyncio
async def test_banner_start_sets_waiting_state(records, audit):
    message = FakeMessage(CONFIG.owner_id)
    update = FakeUpdate(message, CONFIG.owner_id)
    context = FakeContext({"records": records}, {})

    await owner_handlers._banner_start(update, context)

    assert context.user_data.get("awaiting_banner_photo") is True
    assert any("banner photo" in r for r in message.replies)


@pytest.mark.asyncio
async def test_banner_photo_stores_file_id(records, audit):
    message = FakeMessage(CONFIG.owner_id, photo=[FakePhotoSize("small_id"), FakePhotoSize("large_id")])
    update = FakeUpdate(message, CONFIG.owner_id)
    context = FakeContext({"records": records}, {"awaiting_banner_photo": True})

    consumed = await owner_handlers.handle_banner_photo(update, context)

    assert consumed is True
    assert "awaiting_banner_photo" not in context.user_data
    stored = await records.find_one("CONFIG", key="welcome_banner")
    assert stored is not None
    assert stored.data["file_id"] == "large_id"  # highest-resolution size picked


@pytest.mark.asyncio
async def test_non_owner_cannot_set_banner(records, audit):
    intruder_id = CONFIG.owner_id + 12345
    message = FakeMessage(intruder_id, photo=[FakePhotoSize("evil_id")])
    update = FakeUpdate(message, intruder_id)
    context = FakeContext({"records": records}, {"awaiting_banner_photo": True})

    consumed = await owner_handlers.handle_banner_photo(update, context)

    assert consumed is False
    stored = await records.find_one("CONFIG", key="welcome_banner")
    assert stored is None


class FakeMembershipService:
    """Always reports the user as a member — these tests are about the
    banner flow, not the membership gate itself (see test_start_gate.py)."""
    async def is_member(self, user_id, channel):
        return True


@pytest.mark.asyncio
async def test_start_uses_stored_banner(records, audit):
    await records.save("CONFIG", {"key": "welcome_banner", "file_id": "banner_file_123"})

    message = FakeMessage(999)
    update = FakeUpdate(message, 999)
    context = FakeContext({"records": records, "membership_service": FakeMembershipService()}, {})

    await start_handlers.start_cmd(update, context)

    assert len(message.photos_sent) == 1
    assert message.photos_sent[0][0] == "banner_file_123"


@pytest.mark.asyncio
async def test_start_falls_back_to_text_when_no_banner(records, audit):
    message = FakeMessage(999)
    update = FakeUpdate(message, 999)
    context = FakeContext({"records": records, "membership_service": FakeMembershipService()}, {})

    await start_handlers.start_cmd(update, context)

    assert len(message.photos_sent) == 0
    assert len(message.replies) == 1
