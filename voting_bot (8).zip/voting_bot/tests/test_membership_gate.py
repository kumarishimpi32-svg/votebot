"""
tests/test_membership_gate.py
BUG 5 from the audit: /start never checked the mandatory required-channel
subscription at all. Confirms it now does, for both members and non-members,
and that repeated /start calls behave consistently.
"""
from __future__ import annotations
import pytest
from handlers import start as start_handlers
from config import CONFIG


class FakeUser:
    def __init__(self, id_):
        self.id = id_
        self.first_name = "Test"
        self.username = "testuser"


class FakeMessage:
    def __init__(self, user_id):
        self.from_user = FakeUser(user_id)
        self.replies = []
        self.photos_sent = []

    async def reply_text(self, text, parse_mode=None, reply_markup=None):
        self.replies.append((text, reply_markup))

    async def reply_photo(self, photo, caption=None, parse_mode=None, reply_markup=None):
        self.photos_sent.append((photo, caption))


class FakeUpdate:
    def __init__(self, message, user_id):
        self.message = message
        self.effective_user = message.from_user


class FakeMembershipService:
    def __init__(self, is_member: bool):
        self._is_member = is_member
        self.calls = []

    async def is_member(self, user_id, channel):
        self.calls.append((user_id, channel))
        return self._is_member


class FakeContext:
    def __init__(self, bot_data, user_data=None, args=None):
        self.bot_data = bot_data
        self.user_data = user_data or {}
        self.args = args or []


@pytest.mark.asyncio
async def test_start_blocks_non_member_with_join_gate(records):
    membership = FakeMembershipService(is_member=False)
    context = FakeContext({"records": records, "membership_service": membership})
    message = FakeMessage(555)
    update = FakeUpdate(message, 555)

    await start_handlers.start_cmd(update, context)

    assert membership.calls == [(555, CONFIG.required_channel)]  # actually verified via Telegram, not assumed
    assert len(message.replies) == 1
    text, markup = message.replies[0]
    assert "🔒" in text
    assert markup is not None  # Join + Check buttons


@pytest.mark.asyncio
async def test_start_allows_member_straight_to_home_menu(records):
    membership = FakeMembershipService(is_member=True)
    context = FakeContext({"records": records, "membership_service": membership})
    message = FakeMessage(556)
    update = FakeUpdate(message, 556)

    await start_handlers.start_cmd(update, context)

    assert len(message.replies) == 1
    text, markup = message.replies[0]
    assert "🔒" not in text


@pytest.mark.asyncio
async def test_repeated_start_rechecks_membership_every_time(records):
    """A user who joined between two /start calls must be let in on the
    second call — the gate is re-verified live, never cached as 'already
    passed once'."""
    membership = FakeMembershipService(is_member=False)
    context = FakeContext({"records": records, "membership_service": membership})

    msg1 = FakeMessage(557)
    await start_handlers.start_cmd(FakeUpdate(msg1, 557), context)
    assert "🔒" in msg1.replies[0][0]

    membership._is_member = True  # user joins the channel in between
    msg2 = FakeMessage(557)
    await start_handlers.start_cmd(FakeUpdate(msg2, 557), context)
    assert "🔒" not in msg2.replies[0][0]


@pytest.mark.asyncio
async def test_check_membership_button_reverifies_live_not_just_trusts_click(records):
    """Clicking 'Check Membership' without having actually joined must
    still be refused — the bot performs a real check, not a rubber stamp."""
    membership = FakeMembershipService(is_member=False)

    class FakeQuery:
        def __init__(self, user):
            self.from_user = user
            self.message = FakeMessage(user.id)
            self.answers = []
            self.edited = None

        async def answer(self, text=None, show_alert=False):
            self.answers.append((text, show_alert))

        async def edit_message_text(self, text, parse_mode=None, reply_markup=None):
            self.edited = text

    class FakeUpdateCb:
        def __init__(self, query):
            self.callback_query = query
            self.effective_user = query.from_user

    user = FakeUser(558)
    query = FakeQuery(user)
    context = FakeContext({"records": records, "membership_service": membership})

    await start_handlers.check_membership_callback(FakeUpdateCb(query), context)

    assert any("Still not a member" in (a[0] or "") for a in query.answers)
    assert "🔒" in (query.edited or "")
