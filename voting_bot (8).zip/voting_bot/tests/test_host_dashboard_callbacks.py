"""
tests/test_host_dashboard_callbacks.py
Runtime smoke tests for the host dashboard button dispatcher — this is
exactly the kind of wiring (context.bot_data lookups, query.edit_message_text
calls, correct awaits) that static analysis and unit tests on services alone
won't catch. Uses fake Update/CallbackQuery objects, no real Telegram API.
"""
from __future__ import annotations
import pytest
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.vote_service import VoteService
from services.leaderboard import LeaderboardService
from services.analytics import AnalyticsService
from services.export_service import ExportService
from services.winner_service import WinnerService
from services.anti_abuse import AntiAbuseService
from services.moderation_pipeline import ModerationPipeline, ModerationOutcome
from handlers import host as host_handlers


class FakeUser:
    def __init__(self, id_):
        self.id = id_


class FakeQuery:
    def __init__(self, data, user_id):
        self.data = data
        self.from_user = FakeUser(user_id)
        self.edited_text = None
        self.edited_markup = None
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, text, parse_mode=None, reply_markup=None):
        self.edited_text = text
        self.edited_markup = reply_markup


class FakeUpdate:
    def __init__(self, query, user_id):
        self.callback_query = query
        self.effective_user = FakeUser(user_id)


class FakeBot:
    def __init__(self):
        self.sent_messages = []
        self.sent_documents = []

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        self.sent_messages.append((chat_id, text))

    async def send_document(self, chat_id, document):
        self.sent_documents.append(chat_id)


class FakeContext:
    def __init__(self, bot_data, bot):
        self.bot_data = bot_data
        self.bot = bot


class AlwaysApproveModeration:
    async def evaluate(self, name):
        return ModerationOutcome.APPROVE, "test"


@pytest.fixture
def bot_data(records, audit):
    giveaway_service = GiveawayService(records, audit)
    participant_service = ParticipantService(records, audit, AlwaysApproveModeration())
    vote_service = VoteService(records, audit)
    leaderboard = LeaderboardService(records)
    analytics = AnalyticsService(records)
    export_service = ExportService(records)
    winner_service = WinnerService(records, audit)
    anti_abuse = AntiAbuseService()
    return {
        "giveaway_service": giveaway_service,
        "participant_service": participant_service,
        "vote_service": vote_service,
        "leaderboard": leaderboard,
        "analytics": analytics,
        "export_service": export_service,
        "winner_service": winner_service,
        "anti_abuse": anti_abuse,
        "audit_service": audit,
    }


@pytest.mark.asyncio
async def test_dashboard_participants_button(bot_data):
    HOST_ID = 555
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, -100111, {"title": "Test GW"})
    await bot_data["participant_service"].register(giveaway.id, 999, "Alice")

    query = FakeQuery(f"h_participants:{giveaway.id}", HOST_ID)
    update = FakeUpdate(query, HOST_ID)
    context = FakeContext(bot_data, FakeBot())

    await host_handlers.dashboard_action_callback(update, context)

    assert "Alice" in query.edited_text
    assert query.edited_markup is not None


@pytest.mark.asyncio
async def test_dashboard_non_host_rejected(bot_data):
    HOST_ID, INTRUDER_ID = 555, 666
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, -100111, {"title": "Test GW"})

    query = FakeQuery(f"h_participants:{giveaway.id}", INTRUDER_ID)
    update = FakeUpdate(query, INTRUDER_ID)
    context = FakeContext(bot_data, FakeBot())

    await host_handlers.dashboard_action_callback(update, context)

    assert query.edited_text is None  # never got to render dashboard content
    assert any("Only the host" in (msg or "") for msg, _ in query.answers)


@pytest.mark.asyncio
async def test_dashboard_votes_button(bot_data):
    HOST_ID = 555
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, -100111, {"title": "Test GW"})
    rec, _ = await bot_data["participant_service"].register(giveaway.id, 999, "Alice")
    await bot_data["vote_service"].cast_vote(giveaway.id, rec.id, voter_id=111)

    query = FakeQuery(f"h_votes:{giveaway.id}", HOST_ID)
    update = FakeUpdate(query, HOST_ID)
    context = FakeContext(bot_data, FakeBot())

    await host_handlers.dashboard_action_callback(update, context)
    assert "Valid votes: 1" in query.edited_text


@pytest.mark.asyncio
async def test_dashboard_undo_button_with_nothing_to_undo(bot_data):
    HOST_ID = 555
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, -100111, {"title": "Test GW"})

    query = FakeQuery(f"h_undo:{giveaway.id}", HOST_ID)
    update = FakeUpdate(query, HOST_ID)
    context = FakeContext(bot_data, FakeBot())

    await host_handlers.dashboard_action_callback(update, context)
    assert any("Nothing to undo" in (msg or "") for msg, _ in query.answers)


@pytest.mark.asyncio
async def test_dashboard_export_button_sends_document(bot_data):
    HOST_ID = 555
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, -100111, {"title": "Test GW"})
    await bot_data["participant_service"].register(giveaway.id, 999, "Alice")

    fake_bot = FakeBot()
    query = FakeQuery(f"h_export:{giveaway.id}", HOST_ID)
    update = FakeUpdate(query, HOST_ID)
    context = FakeContext(bot_data, fake_bot)

    await host_handlers.dashboard_action_callback(update, context)
    assert len(fake_bot.sent_documents) == 1
    assert fake_bot.sent_documents[0] == HOST_ID


@pytest.mark.asyncio
async def test_dashboard_end_button_announces_winner(bot_data):
    HOST_ID = 555
    CHANNEL_ID = -100111
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, CHANNEL_ID, {"title": "Test GW", "min_votes": 0})
    rec, _ = await bot_data["participant_service"].register(giveaway.id, 999, "Alice")
    await bot_data["vote_service"].cast_vote(giveaway.id, rec.id, voter_id=111)

    fake_bot = FakeBot()
    query = FakeQuery(f"h_end:{giveaway.id}", HOST_ID)
    update = FakeUpdate(query, HOST_ID)
    context = FakeContext(bot_data, fake_bot)

    await host_handlers.dashboard_action_callback(update, context)

    assert len(fake_bot.sent_messages) == 1
    assert fake_bot.sent_messages[0][0] == CHANNEL_ID
    assert "Alice" in fake_bot.sent_messages[0][1]


@pytest.mark.asyncio
async def test_double_tap_end_does_not_double_announce(bot_data):
    """Spec section 33: ending must be idempotent — pressing End twice
    (e.g. a double-tap, or the auto-end job racing a manual end) must not
    re-run winner selection or send a second channel announcement."""
    HOST_ID = 555
    CHANNEL_ID = -100111
    giveaway = await bot_data["giveaway_service"].create_giveaway(HOST_ID, CHANNEL_ID, {"title": "Test GW", "min_votes": 0})
    rec, _ = await bot_data["participant_service"].register(giveaway.id, 999, "Alice")
    await bot_data["vote_service"].cast_vote(giveaway.id, rec.id, voter_id=111)

    fake_bot = FakeBot()
    context = FakeContext(bot_data, fake_bot)

    first = FakeUpdate(FakeQuery(f"h_end:{giveaway.id}", HOST_ID), HOST_ID)
    await host_handlers.dashboard_action_callback(first, context)

    second = FakeUpdate(FakeQuery(f"h_end:{giveaway.id}", HOST_ID), HOST_ID)
    await host_handlers.dashboard_action_callback(second, context)

    assert len(fake_bot.sent_messages) == 1  # not 2
    assert any("already been ended" in (a[0] or "") for a in second.callback_query.answers)
