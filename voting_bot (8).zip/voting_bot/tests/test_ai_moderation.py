"""
tests/test_ai_moderation.py
Exercises the ACTUAL AiModerationService (JSON parsing, key-pool failover,
error handling) using a fake Gemini client — no real network calls, no
live API key needed, but this is real code under test, not a hand-rolled
substitute like FakeAi in test_moderation.py.
"""
import pytest
from services.api_pool import ApiKeyPool
from services.ai_moderation import AiModerationService, Classification


class FakeResponse:
    def __init__(self, text: str):
        self.text = text


class FakeModels:
    def __init__(self, script):
        self.script = script  # list of responses/exceptions to return in order
        self.calls = 0

    async def generate_content(self, model, contents):
        item = self.script[min(self.calls, len(self.script) - 1)]
        self.calls += 1
        if isinstance(item, Exception):
            raise item
        return FakeResponse(item)


class FakeAio:
    def __init__(self, models):
        self.models = models


class FakeClient:
    def __init__(self, api_key, script):
        self.api_key = api_key
        self.aio = FakeAio(FakeModels(script))


def make_factory(script):
    def factory(api_key):
        return FakeClient(api_key, script)
    return factory


@pytest.mark.asyncio
async def test_no_keys_configured_returns_uncertain():
    pool = ApiKeyPool([])
    svc = AiModerationService(pool)
    classification, reason = await svc.classify_name("Anyone")
    assert classification == Classification.UNCERTAIN
    assert "not configured" in reason


@pytest.mark.asyncio
async def test_safe_json_response_parsed_correctly():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory(['{"classification": "SAFE", "reason": "normal name"}'])
    svc = AiModerationService(pool, client_factory=factory)
    classification, reason = await svc.classify_name("Rahul Kumar")
    assert classification == Classification.SAFE
    assert reason == "normal name"


@pytest.mark.asyncio
async def test_response_wrapped_in_markdown_fences_still_parses():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory(['```json\n{"classification": "REJECT", "reason": "slur"}\n```'])
    svc = AiModerationService(pool, client_factory=factory)
    classification, reason = await svc.classify_name("BadName")
    assert classification == Classification.REJECT
    assert reason == "slur"


@pytest.mark.asyncio
async def test_malformed_json_returns_uncertain_not_a_crash():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory(["not valid json at all"])
    svc = AiModerationService(pool, client_factory=factory)
    classification, reason = await svc.classify_name("Something")
    assert classification == Classification.UNCERTAIN


@pytest.mark.asyncio
async def test_api_exception_reports_failure_and_returns_uncertain():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory([RuntimeError("503 Service Unavailable")])
    svc = AiModerationService(pool, client_factory=factory)
    classification, reason = await svc.classify_name("Something")
    assert classification == Classification.UNCERTAIN
    # the key should now be in cooldown, not permanently dead, for a transient error
    health = pool.health_report()
    assert health["cooldown"] == 1
    assert health["unhealthy"] == 0


@pytest.mark.asyncio
async def test_invalid_key_error_marks_key_permanently_unhealthy():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory([RuntimeError("400 API_KEY_INVALID")])
    svc = AiModerationService(pool, client_factory=factory)
    await svc.classify_name("Something")
    health = pool.health_report()
    assert health["unhealthy"] == 1


@pytest.mark.asyncio
async def test_double_check_suspicious_again_routes_to_uncertain():
    pool = ApiKeyPool(["fake-key-1"])
    factory = make_factory(['{"classification": "SUSPICIOUS", "reason": "borderline"}'])
    svc = AiModerationService(pool, client_factory=factory)
    classification, reason = await svc.double_check("Borderline Name")
    assert classification == Classification.UNCERTAIN


@pytest.mark.asyncio
async def test_key_pool_failover_when_one_key_in_cooldown():
    pool = ApiKeyPool(["key-a", "key-b"])
    # exhaust key-a first
    bad_status = pool.get_available_key()
    pool.report_failure(bad_status, "500 transient", cooldown_seconds=999)

    # only key-b should be selectable now
    available = pool.get_available_key()
    assert available is not None
    assert available.key != bad_status.key
