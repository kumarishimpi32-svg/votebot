"""
tests/test_error_handler.py
Confirms unhandled exceptions now alert the owner directly in Telegram
(not just server logs), stay sanitized, and never crash the error handler
itself even if the alert message fails to send. Uses REAL telegram.Update
objects routed through a real Bot subclass with only the network-calling
methods overridden — PTB's objects are frozen and reject attribute
monkeypatching, so interception has to happen at the Bot boundary.
"""
from __future__ import annotations
import datetime
import pytest
from telegram import Update, Message, Chat, User, CallbackQuery, Bot
from config import CONFIG
import main as main_module


class RecordingBot(Bot):
    """Real Bot subclass; only overrides the two network calls we care about."""
    def __init__(self, *a, fail_send_message=False, **kw):
        super().__init__(*a, **kw)
        object.__setattr__(self, "_sent", [])
        object.__setattr__(self, "_answered", [])
        object.__setattr__(self, "_fail_send_message", fail_send_message)

    async def send_message(self, chat_id, text, parse_mode=None, **kwargs):
        if self._fail_send_message:
            raise RuntimeError("network down")
        self._sent.append((chat_id, text))
        return Message(message_id=99, date=datetime.datetime.now(), chat=Chat(id=chat_id, type="private"))

    async def answer_callback_query(self, callback_query_id, text=None, show_alert=False, **kwargs):
        self._answered.append((text, show_alert))
        return True


def make_message_update(bot, text="/start"):
    user = User(id=42, first_name="Test", is_bot=False)
    chat = Chat(id=42, type="private")
    message = Message(message_id=1, date=datetime.datetime.now(), chat=chat, from_user=user, text=text)
    message.set_bot(bot)
    return Update(update_id=1, message=message)


class FakeContext:
    def __init__(self, error, bot):
        self.error = error
        self.bot = bot


@pytest.mark.asyncio
async def test_owner_gets_error_alert_with_type_and_message():
    bot = RecordingBot(token="123456:TEST-TOKEN-not-real")
    update = make_message_update(bot, "/start")
    context = FakeContext(ValueError("something specific broke"), bot)

    await main_module.error_handler(update, context)

    owner_msgs = [s for s in bot._sent if s[0] == CONFIG.owner_id]
    assert len(owner_msgs) == 1
    _, text = owner_msgs[0]
    assert "ValueError" in text
    assert "something specific broke" in text
    assert "/start" in text


@pytest.mark.asyncio
async def test_user_still_gets_generic_message_not_technical_detail():
    bot = RecordingBot(token="123456:TEST-TOKEN-not-real")
    update = make_message_update(bot, "/start")
    context = FakeContext(ValueError("internal secret path /etc/whatever"), bot)

    await main_module.error_handler(update, context)

    user_msgs = [s for s in bot._sent if s[0] == 42]  # the user's chat, not the owner's
    assert len(user_msgs) == 1
    assert "secret path" not in user_msgs[0][1]
    assert "Something went wrong" in user_msgs[0][1]


@pytest.mark.asyncio
async def test_error_handler_never_crashes_if_owner_alert_fails():
    bot = RecordingBot(token="123456:TEST-TOKEN-not-real", fail_send_message=True)
    update = make_message_update(bot, "/start")
    context = FakeContext(ValueError("boom"), bot)

    # Must not raise, even though every send_message call fails
    await main_module.error_handler(update, context)


@pytest.mark.asyncio
async def test_callback_query_errors_are_answered_and_alerted():
    bot = RecordingBot(token="123456:TEST-TOKEN-not-real")
    user = User(id=42, first_name="Test", is_bot=False)
    chat = Chat(id=42, type="private")
    message = Message(message_id=1, date=datetime.datetime.now(), chat=chat, from_user=user, text="menu")
    message.set_bot(bot)
    query = CallbackQuery(id="cbq1", from_user=user, chat_instance="x", message=message, data="home")
    query.set_bot(bot)

    update = Update(update_id=1, callback_query=query)
    context = FakeContext(RuntimeError("callback broke"), bot)

    await main_module.error_handler(update, context)

    assert len(bot._answered) == 1
    owner_msgs = [s for s in bot._sent if s[0] == CONFIG.owner_id]
    assert len(owner_msgs) == 1
    assert "callback broke" in owner_msgs[0][1]
