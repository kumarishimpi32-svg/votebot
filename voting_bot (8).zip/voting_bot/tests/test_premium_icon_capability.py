"""
tests/test_premium_icon_capability.py

Covers the self-healing capability flag added to utils/premium_emoji.py:
icon_custom_emoji_id is an all-or-nothing, account-level gate on
Telegram's side (bot owner must have Premium, or the bot purchased a
Fragment username) — not something retryable per-button. Once main.py's
startup probe (or the error_handler safety net) determines icons don't
work, icon_id_for() must stop handing out ids everywhere, immediately,
without every one of the ~60 call sites needing its own try/except
around the live Telegram API call.
"""
from __future__ import annotations
import datetime
import pytest
from telegram import Update, Message, Chat, User, Bot
from telegram.error import BadRequest

from utils import premium_emoji
from utils import keyboards
import main as main_module
from config import CONFIG


@pytest.fixture(autouse=True)
def _restore_icon_flag():
    """Every test starts and ends with icons enabled (the real default),
    regardless of what an earlier test flipped — this flag is global
    module state, so tests must not leak into each other."""
    premium_emoji.set_icons_supported(True)
    yield
    premium_emoji.set_icons_supported(True)


def test_icons_enabled_by_default():
    assert premium_emoji.icons_supported() is True
    assert premium_emoji.icon_id_for("🎁 Create") is not None


def test_disabling_icons_stops_icon_id_for_everywhere():
    premium_emoji.set_icons_supported(False)
    assert premium_emoji.icon_id_for("🎁 Create") is None
    assert premium_emoji.icon_id_for("🏆 Leaderboard") is None


def test_disabled_flag_propagates_into_built_buttons():
    premium_emoji.set_icons_supported(False)
    btn = keyboards._btn("🎁 Create", "gw_create")
    as_dict = btn.to_dict()
    assert "icon_custom_emoji_id" not in as_dict
    # Falls back to keeping the plain emoji in the label text instead of
    # losing it, since no icon is being attached.
    assert as_dict["text"].startswith("🎁")


def test_re_enabling_icons_restores_behavior():
    premium_emoji.set_icons_supported(False)
    assert premium_emoji.icon_id_for("🎁 Create") is None
    premium_emoji.set_icons_supported(True)
    assert premium_emoji.icon_id_for("🎁 Create") is not None


class _ProbeBot(Bot):
    """Real Bot subclass; only overrides the two calls the probe makes."""
    def __init__(self, *a, send_error=None, **kw):
        super().__init__(*a, **kw)
        object.__setattr__(self, "_send_error", send_error)
        object.__setattr__(self, "_sent", [])
        object.__setattr__(self, "_deleted", [])

    async def send_message(self, chat_id, text, parse_mode=None, **kwargs):
        if self._send_error is not None:
            raise self._send_error
        self._sent.append((chat_id, text))
        return Message(message_id=7, date=datetime.datetime.now(), chat=Chat(id=chat_id, type="private"))

    async def delete_message(self, chat_id, message_id, **kwargs):
        self._deleted.append((chat_id, message_id))
        return True


@pytest.mark.asyncio
async def test_startup_probe_disables_icons_on_bad_request():
    bot = _ProbeBot(token="123456:TEST-TOKEN-not-real", send_error=BadRequest("BUTTON_ICON_INVALID"))
    await main_module._probe_premium_icon_support(bot)
    assert premium_emoji.icons_supported() is False
    # The follow-up plain-text explanation to the owner must itself not
    # attempt any icon and must not crash even though the probe send failed.
    assert bot._sent and bot._sent[0][0] == CONFIG.owner_id


@pytest.mark.asyncio
async def test_startup_probe_leaves_icons_enabled_on_success():
    bot = _ProbeBot(token="123456:TEST-TOKEN-not-real", send_error=None)
    await main_module._probe_premium_icon_support(bot)
    assert premium_emoji.icons_supported() is True
    assert bot._deleted == [(CONFIG.owner_id, 7)]


@pytest.mark.asyncio
async def test_startup_probe_ignores_unrelated_errors():
    """A transient/unrelated failure (network blip, owner blocked the bot)
    must never be treated as proof icons don't work."""
    bot = _ProbeBot(token="123456:TEST-TOKEN-not-real", send_error=RuntimeError("network down"))
    await main_module._probe_premium_icon_support(bot)
    assert premium_emoji.icons_supported() is True


class _ErrHandlerBot(Bot):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        object.__setattr__(self, "_sent", [])

    async def send_message(self, chat_id, text, parse_mode=None, **kwargs):
        self._sent.append((chat_id, text))
        return Message(message_id=1, date=datetime.datetime.now(), chat=Chat(id=chat_id, type="private"))

    async def answer_callback_query(self, callback_query_id, text=None, show_alert=False, **kwargs):
        return True


class _FakeContext:
    def __init__(self, error, bot):
        self.error = error
        self.bot = bot
        self.bot_data = {}


def _make_update(bot):
    user = User(id=42, first_name="Test", is_bot=False)
    chat = Chat(id=42, type="private")
    message = Message(message_id=1, date=datetime.datetime.now(), chat=chat, from_user=user, text="/start")
    message.set_bot(bot)
    return Update(update_id=1, message=message)


@pytest.mark.asyncio
async def test_error_handler_trips_flag_on_icon_bad_request_mid_run():
    bot = _ErrHandlerBot(token="123456:TEST-TOKEN-not-real")
    update = _make_update(bot)
    context = _FakeContext(BadRequest("Bad Request: ICON_CUSTOM_EMOJI_ID_INVALID"), bot)

    await main_module.error_handler(update, context)

    assert premium_emoji.icons_supported() is False


@pytest.mark.asyncio
async def test_error_handler_does_not_trip_flag_on_unrelated_bad_request():
    bot = _ErrHandlerBot(token="123456:TEST-TOKEN-not-real")
    update = _make_update(bot)
    context = _FakeContext(BadRequest("Bad Request: message is not modified"), bot)

    await main_module.error_handler(update, context)

    assert premium_emoji.icons_supported() is True
