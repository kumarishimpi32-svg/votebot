import pytest
from services.vote_service import VoteService, VoteError


@pytest.mark.asyncio
async def test_self_voting_disabled(records, audit):
    """Spec requirement: self-vote disabled — a participant cannot vote
    for their own entry."""
    vs = VoteService(records, audit)
    participant = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 999, "votes": 0, "name": "Self"}, status="approved"
    )
    with pytest.raises(VoteError, match="self_vote"):
        await vs.cast_vote("g1", participant.id, voter_id=999)
    p = await records.get(participant.id)
    assert p.data["votes"] == 0


@pytest.mark.asyncio
async def test_duplicate_vote_rejected(records, audit):
    vs = VoteService(records, audit)
    participant = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 999, "votes": 0, "name": "P"}, status="approved"
    )
    await vs.cast_vote("g1", participant.id, voter_id=111)
    with pytest.raises(VoteError):
        await vs.cast_vote("g1", participant.id, voter_id=111)


@pytest.mark.asyncio
async def test_one_vote_per_giveaway_not_per_participant(records, audit):
    """Spec requirement: '1 vote/user/giveaway' — a voter who already
    voted for one contestant must not also be able to vote for a
    *different* contestant in the same giveaway."""
    vs = VoteService(records, audit)
    p1 = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 1, "votes": 0, "name": "P1"}, status="approved"
    )
    p2 = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 2, "votes": 0, "name": "P2"}, status="approved"
    )
    await vs.cast_vote("g1", p1.id, voter_id=111)
    with pytest.raises(VoteError, match="already_voted"):
        await vs.cast_vote("g1", p2.id, voter_id=111)
    assert (await records.get(p2.id)).data["votes"] == 0


@pytest.mark.asyncio
async def test_host_add_and_undo(records, audit):
    vs = VoteService(records, audit)
    participant = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 999, "votes": 0, "name": "P"}, status="approved"
    )
    await vs.add_manual_vote("g1", participant.id, host_id=1, amount=10)
    p = await records.get(participant.id)
    assert p.data["votes"] == 10

    await vs.undo_last_manual_action("g1", host_id=1)
    p = await records.get(participant.id)
    assert p.data["votes"] == 0


@pytest.mark.asyncio
async def test_vote_deduction_and_restoration_idempotent(records, audit):
    vs = VoteService(records, audit)
    participant = await records.save(
        "PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 999, "votes": 0, "name": "P"}, status="approved"
    )
    await vs.cast_vote("g1", participant.id, voter_id=555)

    await vs.deduct_for_membership_leave("g1", 555, participant.id)
    p = await records.get(participant.id)
    assert p.data["votes"] == 0

    # Calling deduct again should be a no-op (idempotent)
    await vs.deduct_for_membership_leave("g1", 555, participant.id)
    p = await records.get(participant.id)
    assert p.data["votes"] == 0

    await vs.restore_after_membership_rejoin("g1", 555, participant.id)
    p = await records.get(participant.id)
    assert p.data["votes"] == 1

    # Restoring again should not double-count
    await vs.restore_after_membership_rejoin("g1", 555, participant.id)
    p = await records.get(participant.id)
    assert p.data["votes"] == 1
