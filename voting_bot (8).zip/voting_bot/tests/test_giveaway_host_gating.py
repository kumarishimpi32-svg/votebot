"""
tests/test_giveaway_host_gating.py

Only a host who has connected a channel they themselves administer can
create a giveaway there (mega-prompt follow-up: "the person who has added
the bot in channel can only host giveaway... the person who is not admin
in the channel cannot host... the bot can host in any channel, for that
it will ask the user to send the channel details").
"""
from __future__ import annotations
import asyncio
import pytest
from telegram.error import Forbidden, BadRequest
from services.giveaway_service import GiveawayService
from services.channel_service import ChannelService, ChannelError
from handlers import giveaway_wizard as wizard
from utils.keyboards import add_channel_keyboard

ALICE = 1001
BOT_ID = 999


class FakeChat:
    def __init__(self, id, type, title=None, username=None):
        self.id, self.type, self.title, self.username = id, type, title, username


class FakeMember:
    def __init__(self, status, can_post_messages=False, can_edit_messages=False):
        self.status = status
        self.can_post_messages = can_post_messages
        self.can_edit_messages = can_edit_messages


class FakeChannelBot:
    def __init__(self):
        self.id = BOT_ID
        self.username = "TestVoteBot"
        self.chats = {}
        self.members = {}

    def register_channel(self, chat_id, username, owner_id):
        self.chats[chat_id] = FakeChat(chat_id, "channel", f"Channel {chat_id}", username)
        self.members[(chat_id, BOT_ID)] = FakeMember("administrator", True, True)
        self.members[(chat_id, owner_id)] = FakeMember("creator")

    async def get_chat(self, chat_id):
        if isinstance(chat_id, str) and chat_id.startswith("@"):
            for c in self.chats.values():
                if c.username == chat_id[1:]:
                    return c
            raise BadRequest("not found")
        if chat_id in self.chats:
            return self.chats[chat_id]
        raise BadRequest("not found")

    async def get_chat_member(self, chat_id, user_id):
        key = (chat_id, user_id)
        if key in self.members:
            return self.members[key]
        raise Forbidden("absent")

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        await asyncio.sleep(0)
        class Msg:
            pass
        m = Msg()
        m.message_id = 1
        return m


class FakeUser:
    def __init__(self, id_):
        self.id, self.first_name, self.username = id_, "Alice", None


class FakeMessage:
    def __init__(self):
        self.replies = []

    async def reply_text(self, text, parse_mode=None, reply_markup=None):
        self.replies.append((text, reply_markup))


class FakeUpdate:
    def __init__(self, user_id):
        self.message = FakeMessage()
        self.effective_user = FakeUser(user_id)
        self.callback_query = None


class FakeContext:
    def __init__(self, bot_data, user_data, bot):
        self.bot_data, self.user_data, self.bot = bot_data, user_data, bot


class FakePremium:
    """Connecting/using your own channel(s) is now Premium-only — these
    tests exercise that path, so they run as a Premium host. See
    tests/test_giveaway_wizard.py for the free-host (default channel)
    path, which has no premium_service in bot_data at all."""
    async def is_active(self, user_id):
        return True


@pytest.fixture
def channel_bot():
    return FakeChannelBot()


@pytest.fixture
def giveaway_service(records, audit):
    return GiveawayService(records, audit)


@pytest.fixture
def channel_service(channel_bot, records, audit):
    return ChannelService(channel_bot, records, audit)


@pytest.mark.asyncio
async def test_host_with_no_connected_channel_is_asked_for_channel_details(giveaway_service, channel_service, channel_bot):
    bot_data = {"giveaway_service": giveaway_service, "channel_service": channel_service, "premium_service": FakePremium()}
    context = FakeContext(bot_data, {}, channel_bot)
    update = FakeUpdate(ALICE)

    await wizard.start_wizard(update, context)

    assert len(await giveaway_service.list_by_host(ALICE)) == 0
    assert context.user_data.get("awaiting_channel_input") is True
    text, markup = update.message.replies[0]
    assert "Send the channel's" in text


@pytest.mark.asyncio
async def test_host_with_exactly_one_connected_channel_is_auto_activated(giveaway_service, channel_service, channel_bot):
    channel_bot.register_channel(-100111, "alice_channel", ALICE)
    await channel_service.add_channel(ALICE, "@alice_channel")

    bot_data = {"giveaway_service": giveaway_service, "channel_service": channel_service, "premium_service": FakePremium()}
    context = FakeContext(bot_data, {}, channel_bot)
    update = FakeUpdate(ALICE)

    await wizard.start_wizard(update, context)

    giveaways = await giveaway_service.list_by_host(ALICE)
    assert len(giveaways) == 1
    assert giveaways[0].data["channel_id"] == -100111
    active = await channel_service.get_active_channel(ALICE)
    assert active is not None and active.data["chat_id"] == -100111


@pytest.mark.asyncio
async def test_host_with_multiple_channels_must_pick_before_creating(giveaway_service, channel_service, channel_bot):
    channel_bot.register_channel(-100111, "alice_channel", ALICE)
    channel_bot.register_channel(-100222, "alice_second", ALICE)
    await channel_service.add_channel(ALICE, "@alice_channel")
    await channel_service.add_channel(ALICE, "@alice_second")

    bot_data = {"giveaway_service": giveaway_service, "channel_service": channel_service, "premium_service": FakePremium()}
    context = FakeContext(bot_data, {}, channel_bot)
    update = FakeUpdate(ALICE)

    await wizard.start_wizard(update, context)

    assert len(await giveaway_service.list_by_host(ALICE)) == 0
    text, markup = update.message.replies[0]
    assert "Select which one this giveaway should run in" in text


@pytest.mark.asyncio
async def test_non_premium_host_is_still_required_to_connect_a_channel_no_default_used(giveaway_service, channel_service, channel_bot):
    """There is no default/fallback channel for real hosts at all — a
    host with zero connected channels is asked to connect one whether or
    not they're Premium, and no giveaway is created against
    CONFIG.voting_channel/required_channel on their behalf."""
    class NotPremium:
        async def is_active(self, user_id):
            return False

    bot_data = {"giveaway_service": giveaway_service, "channel_service": channel_service, "premium_service": NotPremium()}
    context = FakeContext(bot_data, {}, channel_bot)
    update = FakeUpdate(ALICE)

    await wizard.start_wizard(update, context)

    assert len(await giveaway_service.list_by_host(ALICE)) == 0
    assert context.user_data.get("awaiting_channel_input") is True
    text, markup = update.message.replies[0]
    assert "Send the channel's" in text


@pytest.mark.asyncio
async def test_non_admin_cannot_connect_someone_elses_channel_and_therefore_cannot_host(channel_service, channel_bot):
    NOT_ADMIN = 5555
    channel_bot.register_channel(-100111, "alice_channel", ALICE)  # only Alice is admin

    with pytest.raises(ChannelError) as exc:
        await channel_service.add_channel(NOT_ADMIN, "@alice_channel")
    assert exc.value.code == "requester_not_admin"
