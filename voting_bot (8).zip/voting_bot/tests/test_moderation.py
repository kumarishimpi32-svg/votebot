import pytest
from services.name_filter import NameFilter
from services.moderation_pipeline import ModerationPipeline, ModerationOutcome
from services.ai_moderation import Classification


class FakeAi:
    """Lets tests control AI responses without calling Google."""
    def __init__(self, first, second=None):
        self.first = first
        self.second = second or first

    async def classify_name(self, name):
        return self.first, "fake"

    async def double_check(self, name):
        return self.second, "fake"


@pytest.mark.asyncio
async def test_local_filter_rejects_before_ai_call(tmp_path):
    path = tmp_path / "blocked.txt"
    path.write_text("badname\n")
    nf = NameFilter(str(path))
    pipeline = ModerationPipeline(nf, FakeAi(Classification.SAFE))
    outcome, _ = await pipeline.evaluate("BadName")
    assert outcome == ModerationOutcome.REJECT


@pytest.mark.asyncio
async def test_ai_safe_approves(tmp_path):
    nf = NameFilter(str(tmp_path / "blocked.txt"))
    pipeline = ModerationPipeline(nf, FakeAi(Classification.SAFE))
    outcome, _ = await pipeline.evaluate("Rahul")
    assert outcome == ModerationOutcome.APPROVE


@pytest.mark.asyncio
async def test_ai_uncertain_goes_to_manual_review(tmp_path):
    nf = NameFilter(str(tmp_path / "blocked.txt"))
    pipeline = ModerationPipeline(nf, FakeAi(Classification.UNCERTAIN))
    outcome, _ = await pipeline.evaluate("SomeName")
    assert outcome == ModerationOutcome.MANUAL_REVIEW


@pytest.mark.asyncio
async def test_suspicious_then_safe_second_check_approves(tmp_path):
    nf = NameFilter(str(tmp_path / "blocked.txt"))
    pipeline = ModerationPipeline(nf, FakeAi(Classification.SUSPICIOUS, Classification.SAFE))
    outcome, _ = await pipeline.evaluate("Borderline")
    assert outcome == ModerationOutcome.APPROVE


@pytest.mark.asyncio
async def test_suspicious_twice_goes_to_manual_review(tmp_path):
    nf = NameFilter(str(tmp_path / "blocked.txt"))
    pipeline = ModerationPipeline(nf, FakeAi(Classification.SUSPICIOUS, Classification.SUSPICIOUS))
    outcome, _ = await pipeline.evaluate("Borderline")
    assert outcome == ModerationOutcome.MANUAL_REVIEW
