import pytest


@pytest.mark.asyncio
async def test_save_and_get_record(records):
    rec = await records.save("PARTICIPANT", {"name": "Rahul", "votes": 0})
    fetched = await records.get(rec.id)
    assert fetched is not None
    assert fetched.data["name"] == "Rahul"


@pytest.mark.asyncio
async def test_update_bumps_version_and_preserves_history(records):
    rec = await records.save("PARTICIPANT", {"name": "Rahul", "votes": 0})
    updated = await records.update(rec.id, data={"votes": 5})
    assert updated.version == 2
    assert updated.data["votes"] == 5
    assert updated.data["name"] == "Rahul"  # merged, not overwritten


@pytest.mark.asyncio
async def test_find_by_field(records):
    await records.save("PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 111})
    await records.save("PARTICIPANT", {"giveaway_id": "g1", "telegram_id": 222})
    await records.save("PARTICIPANT", {"giveaway_id": "g2", "telegram_id": 333})
    results = await records.find("PARTICIPANT", giveaway_id="g1")
    assert len(results) == 2


@pytest.mark.asyncio
async def test_stop_cleanly_finishes_writer_task_no_pending_task_left(storage):
    """Reproduces the reported shutdown bug: previously stop() called
    self._writer_task.cancel() without awaiting the task afterwards, so
    the task was still technically 'pending' the moment the process's
    event loop closed, producing 'Task was destroyed but it is pending!'
    followed by a RuntimeError('Event loop is closed') in the logs on
    every shutdown. After stop() returns, the task must be fully done
    (cancelled), not merely scheduled for cancellation."""
    storage.start()
    assert storage._writer_task is not None
    assert not storage._writer_task.done()

    await storage.stop()

    assert storage._writer_task.done()
    assert storage._writer_task.cancelled()


@pytest.mark.asyncio
async def test_snapshot_survives_reindex(storage):
    await storage.save_record("PARTICIPANT", {"name": "Test"})
    storage._by_id.clear()
    storage._by_type.clear()
    result = await storage.rebuild_indexes()
    assert result["loaded"] == 1
