import pytest
from config import CONFIG
from security.permissions import Permissions


def test_owner_check():
    class DummyBot:
        pass
    perms = Permissions(DummyBot(), records=None)
    assert perms.is_owner(CONFIG.owner_id)
    assert not perms.is_owner(CONFIG.owner_id + 1)


def test_payment_admin_default_is_owner_only():
    class DummyBot:
        pass
    perms = Permissions(DummyBot(), records=None)
    assert perms.is_payment_admin(CONFIG.owner_id)
    assert not perms.is_payment_admin(999999999)


def test_payment_admin_grant_revoke():
    class DummyBot:
        pass
    perms = Permissions(DummyBot(), records=None)
    perms.grant_payment_admin(42)
    assert perms.is_payment_admin(42)
    perms.revoke_payment_admin(42)
    assert not perms.is_payment_admin(42)
