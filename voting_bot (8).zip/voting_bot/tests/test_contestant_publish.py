"""
tests/test_contestant_publish.py
BUG 7 from the audit: an approved participant never got published to the
voting channel at all — approval only updated the database and DMed them.
Confirms:
  - approval now publishes a contestant profile
  - a second publish attempt (double-tap Approve, a restart, a repeated
    background scan) never creates a duplicate channel post
  - concurrent publish attempts for the same participant still only ever
    produce ONE channel message
"""
from __future__ import annotations
import asyncio
import pytest
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.contestant_service import ContestantService
from services.moderation_pipeline import ModerationOutcome


class FixedModeration:
    def __init__(self, outcome):
        self.outcome = outcome

    async def evaluate(self, name):
        return self.outcome, "test"


class FakeSentMessage:
    def __init__(self, message_id):
        self.message_id = message_id


class FakeBot:
    def __init__(self):
        self.sent = []
        self._next_id = 1

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        self.sent.append((chat_id, text))
        msg = FakeSentMessage(self._next_id)
        self._next_id += 1
        return msg


HOST_ID = 1
CHANNEL_ID = -100555


async def _setup(records, audit):
    gs = GiveawayService(records, audit)
    giveaway = await gs.create_giveaway(HOST_ID, CHANNEL_ID, {"title": "GW"})
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.APPROVE))
    cs = ContestantService(records, gs, ps)
    rec, status = await ps.register(giveaway.id, 42, "Alice")
    assert status == "approved"
    return giveaway, ps, cs, rec


@pytest.mark.asyncio
async def test_approval_publishes_contestant_to_channel(records, audit):
    giveaway, ps, cs, rec = await _setup(records, audit)
    bot = FakeBot()

    published = await cs.publish_if_needed(bot, giveaway.id, rec.id)

    assert published is True
    assert len(bot.sent) == 1
    assert bot.sent[0][0] == CHANNEL_ID
    updated = await records.get(rec.id)
    assert updated.data["published"] is True
    assert updated.data["message_id"] == 1


@pytest.mark.asyncio
async def test_double_click_approve_never_duplicates_the_post(records, audit):
    giveaway, ps, cs, rec = await _setup(records, audit)
    bot = FakeBot()

    first = await cs.publish_if_needed(bot, giveaway.id, rec.id)
    second = await cs.publish_if_needed(bot, giveaway.id, rec.id)  # e.g. double-tapped Approve

    assert first is True
    assert second is False
    assert len(bot.sent) == 1  # only ever one channel post


@pytest.mark.asyncio
async def test_restart_safe_republish_does_not_duplicate(records, audit):
    """Simulates a bot restart: a fresh ContestantService instance (as if
    the process restarted) still sees the persisted CONTESTANT_PUBLISH
    record and refuses to post again."""
    giveaway, ps, cs, rec = await _setup(records, audit)
    bot = FakeBot()
    await cs.publish_if_needed(bot, giveaway.id, rec.id)

    gs2 = GiveawayService(records, audit)
    cs2 = ContestantService(records, gs2, ps)  # fresh instance, same persisted records
    again = await cs2.publish_if_needed(bot, giveaway.id, rec.id)

    assert again is False
    assert len(bot.sent) == 1


@pytest.mark.asyncio
async def test_concurrent_publish_attempts_produce_exactly_one_post(records, audit):
    giveaway, ps, cs, rec = await _setup(records, audit)
    bot = FakeBot()

    results = await asyncio.gather(*[
        cs.publish_if_needed(bot, giveaway.id, rec.id) for _ in range(5)
    ])

    assert sum(1 for r in results if r) == 1
    assert len(bot.sent) == 1


@pytest.mark.asyncio
async def test_pending_or_rejected_participant_is_never_published(records, audit):
    gs = GiveawayService(records, audit)
    giveaway = await gs.create_giveaway(HOST_ID, CHANNEL_ID, {"title": "GW"})
    ps = ParticipantService(records, audit, FixedModeration(ModerationOutcome.REJECT))
    cs = ContestantService(records, gs, ps)
    rec, status = await ps.register(giveaway.id, 43, "Bob")
    assert status == "rejected"

    bot = FakeBot()
    published = await cs.publish_if_needed(bot, giveaway.id, rec.id)

    assert published is False
    assert len(bot.sent) == 0
