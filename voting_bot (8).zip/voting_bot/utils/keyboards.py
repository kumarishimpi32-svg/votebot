"""
utils/keyboards.py
Reusable inline keyboards with REAL per-button colors.

Telegram Bot API 9.4 (Feb 2026) added a genuine `style` field to
InlineKeyboardButton: 'primary' (blue), 'success' (green), 'danger' (red).
This is not a theme trick or a workaround — it's bot-controlled color,
confirmed working with python-telegram-bot >= 22.7 (see requirements.txt).
Older Telegram clients that don't yet support this field simply ignore it
and fall back to the standard button look, so this degrades safely.

Convention used throughout this file:
  Every button renders blue ('primary') by request — SUCCESS/DANGER are
  kept as names so call sites still read semantically (Vote vs Reject,
  etc.) and nothing elsewhere has to change, but both constants resolve
  to the same 'primary' style string, so there is only one button color
  in the whole app.

Button LABEL TEXT also gets the premium Unicode bold-font treatment
(utils/premium_style.py) — real different code points, renders correctly
inside button labels on every client, with or without style support.
"""
from __future__ import annotations
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from security.callbacks import encode
from utils.small_caps import sc
from utils.premium_emoji import icon_id_for

PRIMARY = "primary"
SUCCESS = "primary"   # all buttons render blue — see module docstring
DANGER = "primary"    # all buttons render blue — see module docstring


def _btn(label: str, callback_data: str, style: str | None = None) -> InlineKeyboardButton:
    """
    Builds a button with the premium Unicode font, real button `style`
    color (Bot API 9.4+ / python-telegram-bot >= 22.7), and — when a
    matching custom emoji is configured (see utils/premium_emoji.py) — a
    premium animated emoji icon in front of the label via
    `icon_custom_emoji_id` (same Bot API version).

    When an icon_custom_emoji_id IS applied, the plain Unicode emoji is
    stripped off the front of the label text first. Telegram renders the
    icon in the same spot a leading emoji would occupy, so leaving the
    plain emoji in the text as well showed it TWICE — once as the custom
    icon, once as ordinary text right after it. Only one now shows.

    Both `style` and `icon_custom_emoji_id` are optional kwargs on an
    older library version raises TypeError — rather than crashing every
    single keyboard in the app (which would break literally everything,
    including /start), each falls back automatically. Colors and icons
    are a visual enhancement; the bot must keep working without them.
    """
    icon_id = icon_id_for(label)
    label_text = label.split(" ", 1)[1] if icon_id and " " in label else label
    text = sc(label_text)
    kwargs = {"callback_data": callback_data}
    if style:
        kwargs["style"] = style
    if icon_id:
        kwargs["icon_custom_emoji_id"] = icon_id
    try:
        return InlineKeyboardButton(text, **kwargs)
    except TypeError:
        # Retry dropping icon_custom_emoji_id first, then style, so we
        # degrade gracefully instead of losing the button entirely. If
        # the icon gets dropped here, put the plain emoji back so the
        # button isn't left with no emoji at all.
        kwargs.pop("icon_custom_emoji_id", None)
        text = sc(label)
        try:
            return InlineKeyboardButton(text, **kwargs)
        except TypeError:
            return InlineKeyboardButton(text, callback_data=callback_data)


def _url_btn(label: str, url: str, style: str | None = None) -> InlineKeyboardButton:
    icon_id = icon_id_for(label)
    label_text = label.split(" ", 1)[1] if icon_id and " " in label else label
    text = sc(label_text)
    kwargs = {"url": url}
    if style:
        kwargs["style"] = style
    if icon_id:
        kwargs["icon_custom_emoji_id"] = icon_id
    try:
        return InlineKeyboardButton(text, **kwargs)
    except TypeError:
        kwargs.pop("icon_custom_emoji_id", None)
        text = sc(label)
        try:
            return InlineKeyboardButton(text, **kwargs)
        except TypeError:
            return InlineKeyboardButton(text, url=url)


def home_menu() -> InlineKeyboardMarkup:
    """Deliberately minimal (spec: 'few buttons + clear purpose'). No
    Leaderboard here — leaderboards are event-level, reached from inside a
    giveaway. No Settings here — there is no implemented personal-settings
    feature, so no button pretends there is one."""
    rows = [
        [_btn("🎁 Giveaways", encode("giveaways"), PRIMARY),
         _btn("👤 Profile", encode("profile"), PRIMARY)],
        [_btn("🔗 Channels", encode("channels"), PRIMARY),
         _btn("💎 Premium", encode("premium"), SUCCESS)],
    ]
    return InlineKeyboardMarkup(rows)


def membership_gate_keyboard(join_url: str) -> InlineKeyboardMarkup:
    """Shown at /start until the user is verified as a member of the
    mandatory required channel. Re-verification is a real
    get_chat_member call server-side — this button never just trusts
    that the user clicked it after actually joining."""
    return InlineKeyboardMarkup([
        [_url_btn("📢 Join Channel", join_url, SUCCESS)],
        [_btn("✅ Check Membership", encode("check_membership"), PRIMARY)],
    ])


def giveaway_announcement_keyboard(join_url: str) -> InlineKeyboardMarkup:
    """Sits under the channel announcement card — the one and only way a
    participant needs to join: no ID typing, no /join command."""
    return InlineKeyboardMarkup([[_url_btn("🗳 Join & Vote", join_url, SUCCESS)]])


def welcome_banner_menu() -> InlineKeyboardMarkup:
    """
    Matches the reference screenshot layout: one full-width primary action
    on top, two secondary actions below.
    """
    rows = [
        [_btn("🚀 Get Started", encode("home"), SUCCESS)],
        [_btn("🎁 Create", encode("gw_create"), PRIMARY),
         _btn("🗂 Manage", encode("gw_manage"), PRIMARY)],
    ]
    return InlineKeyboardMarkup(rows)


def giveaways_submenu() -> InlineKeyboardMarkup:
    """No 'Join' browsing button here on purpose (spec: participants enter
    through the giveaway's own link/deep-link, never by browsing a list
    from the home dashboard — that was a redundant second way in)."""
    rows = [
        [_btn("🎁 Create", encode("gw_create"), SUCCESS)],
        [_btn("🗂 Manage", encode("gw_manage"), PRIMARY)],
        [_btn("🏠 Home", encode("home"))],
    ]
    return InlineKeyboardMarkup(rows)


def back_home() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn("🏠 Home", encode("home"), PRIMARY)]])


def vote_button(giveaway_id: str, participant_id: str, votes: int = 0) -> InlineKeyboardMarkup:
    """Label carries the live vote count (reference screenshot: 'Vote -
    13'), so the count is visible without opening the card body — and it
    updates in place every time this keyboard is re-sent after a vote."""
    return InlineKeyboardMarkup([[
        _btn(f"🗳 Vote - {votes}", encode("vote", giveaway_id, participant_id), SUCCESS)
    ]])


def review_buttons(participant_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        _btn("✅ Approve", encode("review_ok", participant_id), SUCCESS),
        _btn("❌ Reject", encode("review_no", participant_id), DANGER),
    ]])


def payment_review_buttons(payment_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("✅ Approve", encode("pay_ok", payment_id), SUCCESS),
         _btn("❌ Reject", encode("pay_no", payment_id), DANGER)],
        [_btn("🔎 View Details", encode("pay_view", payment_id), PRIMARY)],
    ])


def host_dashboard(giveaway_id: str) -> InlineKeyboardMarkup:
    rows = [
        [_btn("👥 Participants", encode("h_participants", giveaway_id), PRIMARY),
         _btn("🗳 Votes", encode("h_votes", giveaway_id), PRIMARY)],
        [_btn("🏆 Leaderboard", encode("h_leaderboard", giveaway_id), PRIMARY),
         _btn("⚠️ Reviews", encode("h_reviews", giveaway_id), PRIMARY)],
        [_btn("➕ Add Vote", encode("pg_addv", giveaway_id), SUCCESS),
         _btn("➖ Remove Vote", encode("pg_remv", giveaway_id), DANGER)],
        [_btn("↩️ Undo", encode("h_undo", giveaway_id), DANGER),
         _btn("📈 Analytics", encode("h_analytics", giveaway_id), PRIMARY)],
        [_btn("📤 Export", encode("h_export", giveaway_id), PRIMARY),
         _btn("⏹ End", encode("h_end", giveaway_id), DANGER)],
        [_btn("🏠 Home", encode("home"))],
    ]
    return InlineKeyboardMarkup(rows)


def plan_list(plans) -> InlineKeyboardMarkup:
    rows = [
        [_btn(f"💎 {p.data['name']} — ₹{p.data['price_inr']}", encode("plan", p.id), SUCCESS)]
        for p in plans
    ]
    rows.append([_btn("🏠 Home", encode("home"), PRIMARY)])
    return InlineKeyboardMarkup(rows)


def tie_break_picker(giveaway_id: str, candidate_ids: list[str], names_by_id: dict, selected: set | None = None) -> InlineKeyboardMarkup:
    selected = selected or set()
    rows = []
    for pid in candidate_ids:
        check = "✅ " if pid in selected else "▫️ "
        style = SUCCESS if pid in selected else PRIMARY
        rows.append([_btn(f"{check}{names_by_id.get(pid, pid)}", encode("tiepick", giveaway_id, pid), style)])
    rows.append([_btn("🏁 Confirm & Announce", encode("tieconfirm", giveaway_id), SUCCESS)])
    return InlineKeyboardMarkup(rows)


def confirm_cancel(action: str, *args) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        _btn("💳 Payment Done", encode(f"{action}_done", *args), SUCCESS),
        _btn("❌ Cancel", encode("home"), DANGER),
    ]])


def giveaway_picker(giveaways, action_prefix: str) -> InlineKeyboardMarkup:
    """Pick a giveaway by tapping instead of typing/copy-pasting its ID."""
    rows = []
    for g in giveaways:
        state_icon = "🟢" if g.data.get("state") == "ACTIVE" else "🔴"
        label = f"{state_icon} {g.data.get('title', 'Untitled')}"
        rows.append([_btn(label, encode(action_prefix, g.id), PRIMARY)])
    rows.append([_btn("🏠 Home", encode("home"))])
    return InlineKeyboardMarkup(rows)


def participant_picker(participants, giveaway_id: str, action_prefix: str) -> InlineKeyboardMarkup:
    """Pick a participant by tapping instead of typing/copy-pasting their ID."""
    rows = []
    for p in participants:
        label = f"{p.data.get('name')} — {p.data.get('votes', 0)} votes"
        rows.append([_btn(label, encode(action_prefix, giveaway_id, p.id), PRIMARY)])
    rows.append([_btn("🏠 Home", encode("home"))])
    return InlineKeyboardMarkup(rows)


def winner_count_picker(action_prefix: str) -> InlineKeyboardMarkup:
    rows = [[
        _btn(str(n), encode(action_prefix, str(n)), PRIMARY) for n in (1, 2, 3, 5, 10)
    ]]
    return InlineKeyboardMarkup(rows)


def min_votes_picker(action_prefix: str) -> InlineKeyboardMarkup:
    rows = [[
        _btn(str(n), encode(action_prefix, str(n)), PRIMARY) for n in (0, 1, 5, 10, 25)
    ]]
    return InlineKeyboardMarkup(rows)


def share_giveaway_keyboard(join_url: str) -> InlineKeyboardMarkup:
    """Shown to the host right after instant creation — the link itself is
    the only thing that needs to leave the bot; there is no separate
    channel announcement step to configure."""
    return InlineKeyboardMarkup([
        [_url_btn("📤 Share Giveaway", f"https://t.me/share/url?url={join_url}", SUCCESS)],
        [_btn("🏠 Home", encode("home"))],
    ])


def channels_menu_keyboard(channels, active_id: str | None) -> InlineKeyboardMarkup:
    """My Channels screen. Each row's callback carries only the internal
    CHANNEL record id — never the raw Telegram chat_id — so the handler
    can (and must) re-verify ownership from the stored record itself."""
    rows = []
    for c in channels:
        marker = "🟢 " if c.id == active_id else "⚪️ "
        label = f"{marker}{c.data.get('title', 'Untitled')}"
        rows.append([
            _btn(label, encode("ch_select", c.id), PRIMARY),
            _btn("🗑", encode("ch_remove", c.id), DANGER),
        ])
    rows.append([_btn("➕ Add Channel", encode("ch_add"), SUCCESS)])
    rows.append([_btn("🏠 Home", encode("home"))])
    return InlineKeyboardMarkup(rows)


def remove_channel_confirm_keyboard(channel_record_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("🗑 Yes, remove it", encode("ch_remove_confirm", channel_record_id), DANGER),
         _btn("❌ Cancel", encode("channels"), PRIMARY)],
    ])


def premium_required_keyboard() -> InlineKeyboardMarkup:
    """Shown wherever a Premium-only feature is gated (spec: '/premium
    will show a message that you don't have premium and below that a
    Premium and Home option')."""
    return InlineKeyboardMarkup([
        [_btn("💎 Premium", encode("premium"), SUCCESS),
         _btn("🏠 Home", encode("home"), PRIMARY)],
    ])


def add_channel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn("❌ Cancel", encode("channels"), DANGER)]])


def channel_error_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("🔁 Try Again", encode("ch_add"), PRIMARY)],
        [_btn("🔗 My Channels", encode("channels"))],
    ])


def channel_connected_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn("🔗 My Channels", encode("channels"), SUCCESS)]])


def access_denied_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn("🏠 Home", encode("home"), PRIMARY)]])


def giveaway_membership_gate_keyboard(giveaway_id: str, targets: list[tuple[str, str | None]]) -> InlineKeyboardMarkup:
    """targets: (display_label, join_url_or_None) for each channel the
    user hasn't joined yet. A missing url (e.g. a private channel the bot
    couldn't build an invite link for) just skips that button — Check
    Membership still re-verifies everything live."""
    rows = [[_url_btn(f"📢 Join {label}", url, SUCCESS)] for label, url in targets if url]
    rows.append([_btn("✅ Check Membership", encode("check_giveaway_membership", giveaway_id), PRIMARY)])
    return InlineKeyboardMarkup(rows)


def resubmit_keyboard(giveaway_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn("🔄 Submit Again", encode("resubmit", giveaway_id), SUCCESS)]])
