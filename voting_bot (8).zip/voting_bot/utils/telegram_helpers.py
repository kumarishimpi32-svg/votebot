"""
utils/telegram_helpers.py

Fixes the "There is no text in the message to edit" BadRequest.

That error happens whenever code calls `query.edit_message_text(...)` on a
callback whose underlying message is a PHOTO message (e.g. the welcome
banner sent with `reply_photo(caption=...)`). Photo messages don't have a
`.text` — only a `.caption` — so Telegram's `editMessageText` endpoint
rejects the edit outright. It's not a fluke or a rare race condition: once
a user starts from the banner, *every* "edit_message_text" call on that
message will fail this way, forever, until the message is replaced.

`safe_edit` is a drop-in replacement for `query.edit_message_text(...)`
with the exact same call signature. It looks at whether the message being
edited is a photo message and routes to `edit_message_caption` instead
when it is, so navigation keeps working (and keeps the banner image
visible) no matter which screen the user is on.
"""
from __future__ import annotations
from telegram import CallbackQuery, InlineKeyboardMarkup
from telegram.error import BadRequest


def current_html(message) -> str:
    """Return the HTML of whatever's already on a message — `.text_html`
    for a normal text message, `.caption_html` for a photo message — so
    callers can safely append a status line to either kind.

    Bug this fixes: code used to do `query.message.text_html + "..."`
    unconditionally. `.text_html` is None on a photo message (e.g. the
    payment-verification card, which is sent with `send_photo(caption=...)`
    so the admin can see the screenshot). None + str raised
    `TypeError: unsupported operand type(s) for +: 'NoneType' and 'str'`
    every time an admin tapped Approve/Reject on a payment.
    """
    if message is None:
        return ""
    html = getattr(message, "text_html", None)
    if html is not None:
        return html
    return getattr(message, "caption_html", None) or ""


async def safe_edit(
    query: CallbackQuery,
    text: str,
    parse_mode: str | None = None,
    reply_markup: InlineKeyboardMarkup | None = None,
):
    """Edit a callback's message regardless of whether it's text or a photo.

    Also swallows Telegram's "Message is not modified" BadRequest. That
    error fires whenever the new text/caption + markup are byte-identical
    to what's already on the message (e.g. two rapid taps on a vote
    button that both resolve to the same vote count before the first
    edit lands) — it's not a real failure, there's simply nothing to
    change, so it should never crash the handler.
    """
    message = getattr(query, "message", None)
    try:
        if message is not None and getattr(message, "photo", None):
            return await query.edit_message_caption(
                caption=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
            )
        return await query.edit_message_text(
            text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
        )
    except BadRequest as e:
        if "message is not modified" in str(e).lower():
            return None
        raise
