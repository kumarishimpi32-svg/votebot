"""
utils/formatting.py

Premium visual layer (spec section 13). Telegram genuinely does not allow
a bot to change the client's native font or a button's background color —
that's a real platform limitation, not something this file works around
by lying about it. What it DOES do for a premium look, all fully
supported everywhere:

  - Headings rendered in real bold Unicode glyphs (utils/premium_style.py)
    — a different technique from HTML <b> (which Telegram already applies
    on top), giving section titles a distinct "wordmark" feel.
  - Consistent premium badges, dividers, and iconography.
  - Clean, consistent spacing and section structure on every screen.

If you paste any of these strings outside Telegram (e.g. into a plain
text file) the bold glyphs still show correctly — they're real characters,
not a rendering trick tied to Telegram's HTML parser.
"""
from __future__ import annotations
import html
from datetime import datetime, timezone
from utils.premium_style import premium_mono, badge, DIVIDER, DIVIDER_DOTTED
from utils.premium_emoji import tg_emoji
from utils.small_caps import sc

CROWN = "👑"
DIAMOND = "💎"
TROPHY = "🏆"
FIRE = "🔥"
SPARKLE = "✨"
MEDALS = ["🥇", "🥈", "🥉"]


def esc(text) -> str:
    """Escape untrusted free text (participant names, giveaway titles/
    descriptions/prizes, payment references, plan names, etc.) before it's
    interpolated into a parse_mode='HTML' message. Without this, a user
    could put '<a href=...>' or '<b>' in something as simple as their
    display name and have it render as a spoofed link or broken markup
    in messages shown to other users — including public channel posts
    (winner announcements, giveaway listings) that anyone can trigger
    just by registering or creating a giveaway."""
    if text is None:
        return ""
    return html.escape(str(text))


def fmt_time(ts: float | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%d %b %Y, %H:%M UTC")


def heading(icon: str, text: str, sub: str | None = None) -> str:
    """Standard premium section heading used at the top of every screen.
    Rendered in the small-caps style requested (Title Case, lowercase
    letters mapped to small-capital glyphs — see utils/small_caps.py).
    esc() runs AFTER the small-caps transform, never before: sc() would
    otherwise mangle an already-escaped '&amp;' into '&ᴀᴍᴘ;'."""
    lines = [f"{tg_emoji(icon)} <b>{esc(sc(text.title()))}</b>"]
    if sub:
        lines.append(f"<i>{esc(sc(sub))}</i>")
    lines.append(DIVIDER)
    return "\n".join(lines)


def home_menu_text(username: str) -> str:
    name = esc(username) if username else "there"
    return (
        f"👋 {sc('Welcome')}, {name}!\n\n"
        f"{DIVIDER}\n"
        f"💎 {sc('Prime Vote Giveaway Bot')}\n"
        f"{DIVIDER}\n\n"
        f"⚡ {sc('Create Powerful Vote Giveaways')}\n"
        f"🛡 {sc('Real-Time Vote System')}\n"
        f"⚙️ {sc('Advanced Management Tools')}\n"
        f"🏆 {esc(sc('Leaderboard & Analytics'))}\n\n"
        f"{sc('Use the menu below to get started')} 👇"
    )


def participant_card(name: str, telegram_id: int, votes: int) -> str:
    """Matches the reference voting-card screenshot: Name/ID fields, no
    vote-count line in the body — the live vote count is shown on the
    Vote button itself (see utils/keyboards.vote_button) so it updates
    in place after every vote instead of needing this text re-parsed."""
    return (
        f"😎 {sc('Name')}: <b>{esc(name)}</b>\n"
        f"❤️ {sc('ID')}: <code>{telegram_id}</code>"
    )


def giveaway_announcement(title: str, description: str, prize: str, min_votes: int,
                           max_winners: int, giveaway_id: str) -> str:
    """The card posted INTO the channel the moment a giveaway is created —
    this is what participants actually see and tap to join. Previously
    nothing was ever posted here at all (creation only replied to the
    host in DM), which is why a giveaway would sit invisible in its own
    channel with no way for anyone to find or join it."""
    lines = [heading(SPARKLE, "Giveaway Live", title), ""]
    if description:
        lines.append(esc(description))
        lines.append("")
    lines.append(f"🎁 {sc('Prize')}: <b>{esc(prize) or '—'}</b>")
    lines.append(f"🗳 {sc('Min. votes to qualify')}: <b>{min_votes}</b>")
    lines.append(f"🏆 {sc('Winners')}: <b>{max_winners}</b>")
    lines.append(DIVIDER_DOTTED)
    lines.append("")
    lines.append(f"👇 {sc('Tap below to join and start voting')}!")
    return "\n".join(lines)


def dashboard_text(title: str, stats: dict) -> str:
    return (
        f"{heading('🎁', 'Giveaway Dashboard', title)}\n\n"
        f"📊 {sc('Participants')} ⟶ <b>{stats.get('participants', 0)}</b>\n"
        f"🗳 {sc('Valid votes')} ⟶ <b>{stats.get('valid_votes', 0)}</b>\n"
        f"⚠️ {sc('Pending reviews')} ⟶ <b>{stats.get('pending_review', 0)}</b>\n"
        f"{DIVIDER_DOTTED}\n"
        f"✅ {sc('Approved')}: {stats.get('approved', 0)}   ❌ {sc('Rejected')}: {stats.get('rejected', 0)}\n"
        f"➕ {sc('Manual votes')}: {stats.get('manual_votes', 0)}   ⚠️ {sc('Deducted')}: {stats.get('deducted_votes', 0)}"
    )


def premium_plan_card(name: str, price_inr: int, duration_days: int) -> str:
    # sc() runs before esc(), never after — see heading()'s docstring for why.
    return f"{DIAMOND} <b>{esc(sc(name))}</b> — ₹{price_inr}\n📅 {duration_days} {sc('days')}"


def premium_status_text(active: bool, plan_id: str | None, started_at: float | None,
                         expires_at: float | None) -> str:
    status_badge = badge(f"🟢 {sc('Active')}") if active else badge(f"🔴 {sc('Not Active')}")
    return (
        f"{heading(DIAMOND, 'My Premium')}\n\n"
        f"{sc('Status')}: {status_badge}\n"
        f"{sc('Plan')}: {premium_mono(esc(plan_id)) if plan_id else '—'}\n"
        f"{sc('Started')}: {fmt_time(started_at)}\n"
        f"{sc('Expires')}: {fmt_time(expires_at)}\n"
    )


def premium_checkout_text(plan_name: str, price_inr: int, duration_days: int,
                           payment_provider: str, instructions: str) -> str:
    """The Premium checkout/confirm screen — redesigned as a clean,
    divider-boxed card instead of a plain wall of text."""
    return (
        f"{heading(DIAMOND, 'Confirm Premium')}\n\n"
        f"🏷 {sc('Plan')}: <b>{esc(sc(plan_name))}</b>\n"
        f"💰 {sc('Price')}: <b>₹{price_inr}</b>\n"
        f"📅 {sc('Duration')}: <b>{duration_days} {sc('days')}</b>\n"
        f"{DIVIDER_DOTTED}\n"
        f"💳 {sc('Payment method')}: <b>{esc(sc(payment_provider))}</b>\n\n"
        f"{esc(instructions)}\n\n"
        f"👉 {sc('After paying, tap Payment Done below and send your transaction ID')}."
    )


def premium_payment_done_prompt() -> str:
    return (
        f"{heading('📸', 'Payment Screenshot')}\n\n"
        f"{sc('Please send a screenshot of your payment as a photo now')}.\n\n"
        f"{sc('You can add the transaction ID / UTR as the photo caption (optional)')}.\n\n"
        f"{sc('Your Premium will activate once an admin manually verifies the payment')}."
    )


def premium_plans_header() -> str:
    return heading("📦", "Premium Plans")


PREMIUM_FEATURES = [
    ("🔗", "Custom channels", "/channels", "Remove the default channel and connect your own — add multiple channels for hosting and for the join gate."),
    ("🖼", "Channel photo monitoring", "(automatic)", "Every photo posted in your connected channel(s) is scanned; if something looks like a Telegram ToS violation you're DMed privately — nothing is ever posted about it in the channel."),
    ("🏆", "Premium leaderboard", "/leaderboard <id>", "Richer stats — first/last vote timestamps for every contestant, not just the free top-10 list."),
    ("📸", "Photo-verified entries", "/submitphoto <id>", "Require participants to submit a photo with their entry, AI-checked before it's accepted."),
]


def premium_command_list_text(active: bool) -> str:
    """/premium — spec: show ALL premium commands/features. Usable
    (described as available) when active; when not, the caller instead
    shows premium_required_text() with the Premium/Home buttons, so this
    text is only ever rendered for an active Premium account."""
    lines = [heading(DIAMOND, "Premium Features"), ""]
    for icon, name, cmd, desc in PREMIUM_FEATURES:
        lines.append(f"{icon} <b>{esc(sc(name))}</b> — <code>{esc(cmd)}</code>\n    {esc(desc)}")
        lines.append("")
    lines.append(sc("Note: AI name-verification for entering a giveaway is free for everyone — it never requires Premium."))
    return "\n".join(lines).rstrip()


def owner_overview_text(stats: dict) -> str:
    return (
        f"{heading(CROWN, 'Dashboard')}\n\n"
        f"🎁 {sc('Giveaways')}: <b>{stats['total_giveaways']}</b> ({stats['active_giveaways']} {sc('active')})\n"
        f"💰 {sc('Pending payments')}: <b>{stats['pending_payments']}</b>\n"
        f"✅ {sc('Approved payments')}: <b>{stats['approved_payments']}</b>\n"
        f"{DIAMOND} {sc('Premium accounts')}: <b>{stats['premium_accounts']}</b>\n"
    )


def payment_verification_card_text(user_id: int, plan_name: str, amount_inr: int,
                                    reference: str, submitted_at: float) -> str:
    """Shared by handlers/payment.py and handlers/admin.py — one card
    format instead of two near-duplicate f-strings (consolidated)."""
    return (
        f"{heading('💰', 'Payment Verification')}\n\n"
        f"👤 {sc('User')}: <code>{user_id}</code>\n"
        f"🏷 {sc('Plan')}: {esc(sc(plan_name or '—'))}\n"
        f"💵 {sc('Amount')}: ₹{amount_inr}\n"
        f"🧾 {sc('Reference')}: <code>{esc(reference)}</code>\n"
        f"🕒 {sc('Submitted')}: {fmt_time(submitted_at)}"
    )


CHANNEL_ERROR_MESSAGES = {
    "invalid_input": "Please send a valid channel username (e.g. <code>@mychannel</code>) or its numeric ID.",
    "not_found": "That channel couldn't be found. Make sure the username/ID is correct.",
    "not_a_channel": "That's not a Telegram channel — this only works with channels, not groups or users.",
    "requester_not_admin": "You must be an admin of that channel yourself to connect it here.",
    "bot_absent": "The bot isn't in that channel yet. Add it as a member first, then try again.",
    "bot_not_admin": "The bot is in the channel but isn't an admin. Promote it to admin, then try again.",
    "missing_permissions": "The bot is admin but is missing required permissions (post &amp; edit messages). Grant them, then try again.",
    "already_connected_self": "That channel is already connected to your account.",
    "already_connected_other": "That channel is already connected to a different account.",
}


def channels_menu_text(channels: list, active_id: str | None) -> str:
    lines = [heading("🔗", "My Channels"), ""]
    if not channels:
        lines.append(sc("You haven't connected any channels yet."))
        lines.append("")
        lines.append(f"👇 {sc('Tap')} <b>{sc('Add Channel')}</b> {sc('to connect one')}.")
        return "\n".join(lines)
    for c in channels:
        is_active = c.id == active_id
        marker = f"🟢 <b>{sc('Active')}</b>" if is_active else "⚪️"
        verified = f"✅ {sc('Verified')}" if c.data.get("verified") else f"⚠️ {sc('Needs re-verification')}"
        title = esc(c.data.get("title", "Untitled"))
        lines.append(f"{marker} {title}\n    {verified}")
        lines.append("")
    return "\n".join(lines).rstrip()


def add_channel_prompt_text() -> str:
    return (
        f"{heading('➕', 'ADD CHANNEL')}\n\n"
        f"Send the channel's <b>username</b> (e.g. <code>@mychannel</code>) or its numeric <b>ID</b>.\n\n"
        f"Before you send it, make sure:\n"
        f"1️⃣ The bot has been added to the channel\n"
        f"2️⃣ The bot has been made an <b>admin</b>\n"
        f"3️⃣ The bot's admin rights include <b>Post Messages</b> and <b>Edit Messages</b>\n\n"
        f"You must also be an admin of that channel yourself."
    )


def host_requires_channel_text() -> str:
    """Shown when a host tries to create a giveaway but hasn't connected
    any channel yet (multi-channel CONNECT system): only the person who
    added the bot to a channel, and who is themselves an admin of it, can
    host a giveaway there — so hosting always starts from Add Channel."""
    return (
        f"{heading('🔗', 'CONNECT A CHANNEL TO HOST')}\n\n"
        f"Only someone who has added this bot to a channel — and is "
        f"themselves an admin of it — can host a giveaway there.\n\n"
        f"{add_channel_prompt_text().split(chr(10) + chr(10), 1)[1]}"
    )


def host_pick_channel_text() -> str:
    return (
        f"{heading('🔗', 'PICK A CHANNEL TO HOST IN')}\n\n"
        f"You've connected more than one channel. Select which one this "
        f"giveaway should run in, then tap 🎁 Create again."
    )


def channel_error_text(code: str, detail: str = "") -> str:
    body = CHANNEL_ERROR_MESSAGES.get(code, "Something went wrong verifying that channel.")
    return f"{heading('❌', 'CHANNEL NOT CONNECTED')}\n\n{body}"


def channel_connected_text(title: str) -> str:
    return (
        f"{heading('✅', 'CHANNEL CONNECTED')}\n\n"
        f"<b>{esc(title)}</b> is now connected and verified.\n\n"
        f"Select it from My Channels to make it your active channel."
    )


def remove_channel_confirm_text(title: str) -> str:
    return (
        f"{heading('🗑', 'REMOVE CHANNEL')}\n\n"
        f"Disconnect <b>{esc(title)}</b>?\n\n"
        f"Giveaways already running there keep working, but new giveaways "
        f"won't be able to use it until you reconnect it."
    )


def channel_removed_text(title: str) -> str:
    return f"{heading('✅', 'CHANNEL REMOVED')}\n\n<b>{esc(title)}</b> has been disconnected."


def premium_required_text(feature: str) -> str:
    """Spec: non-Premium users see 'you don't have premium' plus a way to
    open 💎 Premium or go 🏠 Home — used for every Premium-gated action."""
    return (
        f"{heading('🔒', 'Premium Required')}\n\n"
        f"❌ {sc('You don')}'t have Premium.\n\n"
        f"<b>{esc(feature)}</b> {sc('is a Premium feature')}.\n\n"
        f"{sc('Upgrade to unlock it')}."
    )


def giveaway_membership_gate_text() -> str:
    """Per-giveaway join gate (spec: required_channels) — distinct from
    the bot-wide /start gate, since a Premium host's giveaway can require
    joining their OWN channel(s) instead of (or in addition to) the
    bot's default one."""
    return (
        f"{heading('🔒', 'JOIN REQUIRED')}\n\n"
        f"You need to join the channel(s) below before entering this giveaway.\n\n"
        f"Once you've joined all of them, tap ✅ Check Membership again."
    )


def access_denied_text() -> str:
    """Spec §8. Deliberately generic — never confirms or denies whether
    the resource the user tried to reach even exists, so a manipulated
    callback can't be used to enumerate other users' channel/giveaway ids."""
    return (
        f"{heading('🚫', 'ACCESS DENIED')}\n\n"
        f"You don't have permission to do that.\n\n"
        f"If you think this is a mistake, make sure you're using your own "
        f"account and that the item you're trying to reach still exists."
    )


def leaderboard_header(premium: bool = False) -> str:
    label = "PREMIUM LEADERBOARD" if premium else "LEADERBOARD"
    icon = FIRE if premium else TROPHY
    return heading(icon, label)


def section_divider() -> str:
    return DIVIDER


def _mask_word(word: str) -> str:
    if not word:
        return word
    if len(word) <= 2:
        return word[0] + "*" * (len(word) - 1)
    return word[0] + "*" * (len(word) - 2) + word[-1]


def spoiler_mask(text: str) -> str:
    """The bot must never plainly state, quote, or repost content that
    violates Telegram's rules — not even while explaining WHY something
    was flagged as a violation. Whenever it needs to reference such
    content, this partially masks every word (first/last letter only,
    the rest replaced by '***'-style asterisks — enough to stay
    understandable) and wraps the whole thing in a real Telegram spoiler
    (<tg-spoiler>), so it's hidden behind a tap-to-reveal blur rather than
    sitting in plain, publicly-screenshottable text. Used for every
    moderation 'reason' shown to a human anywhere in the bot."""
    if not text or not text.strip():
        return ""
    masked = " ".join(_mask_word(w) for w in text.split(" "))
    return f"<tg-spoiler>{esc(masked)}</tg-spoiler>"
