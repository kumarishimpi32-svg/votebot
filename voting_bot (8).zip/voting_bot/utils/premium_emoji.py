"""
utils/premium_emoji.py

Premium (animated, Telegram-Premium-only) emoji icons on inline buttons.

WHAT THIS ACTUALLY IS
----------------------
Bot API 9.4 added `icon_custom_emoji_id` on InlineKeyboardButton: a custom
emoji shown before the button's label. This is real and already wired up
in utils/keyboards.py — this file just supplies the IDs.

THE CATCH (read before filling PREMIUM_EMOJI_IDS in)
------------------------------------------------------
Per Telegram's own docs, `icon_custom_emoji_id` can only be used:
  - by bots that have purchased an additional username on Fragment, OR
  - in messages the bot sends directly to a private/group/supergroup chat
    if the BOT OWNER'S account has an active Telegram Premium subscription.
If neither is true for your bot/account, Telegram will reject the field —
that's exactly the kind of crash the try/except fallback in keyboards.py
exists to absorb, so the bot keeps working with plain emoji either way.

Custom emoji are also NOT arbitrary Unicode emoji you can invent an ID
for — each one is a specific Telegram asset with a numeric ID. Real IDs
have to come from Telegram itself, e.g.:
  1. In Telegram, open any message that already contains the custom emoji
     you want (Premium emoji packs, or one you've used before).
  2. Forward that message to a small IDs-lookup bot such as @userinfobot
     or @RawDataBot — one of the fields in the raw JSON it returns is
     `custom_emoji_id`.
  3. Paste that numeric string in as the value below.

HOW TO USE
----------
Map the leading emoji already used in a button's label (see
utils/keyboards.py — e.g. "🎁 Giveaways") to the custom emoji you want
Telegram to render in front of it. Left empty (the default), buttons
render with their plain Unicode emoji exactly as they do today — nothing
breaks, nothing looks different, until real IDs are filled in.

WHAT WAS ACTUALLY WRONG (fixed now, IDs restored)
----------------------------------------------------
This dict was temporarily emptied while tracking down the "two emojis /
one not animated" bug. The real cause wasn't these IDs — it was that
utils/keyboards.py set `icon_custom_emoji_id` (the animated icon) AND
kept the original plain Unicode emoji at the front of the button's label
text (e.g. "🎁 Create"), so Telegram rendered BOTH: the custom icon in
front, plus the plain emoji still sitting in the text right after it.
keyboards.py now strips that leading plain emoji from the label whenever
an icon_custom_emoji_id is being set, so exactly one emoji shows per
button. IDs are restored below.

One Telegram-side note worth knowing, not a bug in this code: Telegram
does not guarantee `icon_custom_emoji_id` on BUTTONS animates the same
way a `<tg-emoji>` tag in message TEXT does — button icons can render as
a static frame of the emoji even when the emoji itself is animated
elsewhere. If some of these still look static after this fix, that's
Telegram's rendering of button icons specifically, not a broken ID.
"""
from __future__ import annotations

# key: the plain emoji currently used as a button's leading character
# value: a real numeric custom_emoji_id obtained as described above
PREMIUM_EMOJI_IDS: dict[str, str] = {
    "🎁": "6172485113843029049",
    "🏆": "5359829906475744831",
    "👋": "6271396634416909377",
    "🏠": "5395831812704452001",
    "✅": "6046607276028991903",
    "👤": "5316727448644103237",
    "🆔": "6046120853802850259",
    "🗳": "5258200019495821936",
    "⚠️": "5462935376714802451",
    "✨": "6334867575217850170",
    "🔴": "6084588784224047783",
    "💳": "5447453226498552490",
    "📷": "6086969355747200950",
    "🎉": "6098125829651307984",
    "💎": "5229173741451230931",
    "📅": "5364233403300330811",
    "⏰": "5413704112220949842",
    "🔗": "4916086774649848789",
    "1️⃣": "6244317784738632020",
    "2️⃣": "6242147417504879292",
    "3️⃣": "6320869894548101759",
    "❌": "6084554527564894617",
    "➕": "5359529383319084413",
    "😎": "6334525760245597578",
    "❤️": "6172358459552438008",
    "⚡️": "5330293807223158971",
    "🛡": "6084620889104585357",
    "⚙️": "4904936030232117798",
    "👇": "5249454864785764508",
    "📤": "5433614747381538714",
    "🔄": "5258420634785947640",
    "🟢": "6240263082208140202",
    "🏁": "5408906741125490282",
    "🚀": "5372917041193828849",
    "🔁": "6093639774965338848",
    "🗂": "5431736674147114227",
    "ℹ️": "5247029067256987229",
    "🚨": "5120722716260828125",
    "📊": "6093382540784046658",
    "📈": "5258391025281408576",
    "🔍": "5444989577422993015",
    "🔎": "5445023138297447592",
    "⏹️": "5134537521518085000",
    "➖": "6154527821218716700",
    "↩️": "5445362436418859744",
    "👥": "5258513401784573443",
}


# ---------------------------------------------------------------------
# Self-healing capability flag
# ---------------------------------------------------------------------
# icon_custom_emoji_id is not a "works or doesn't per-ID" thing — per
# Telegram's own docs it's an all-or-nothing account-level gate: EITHER
# the bot purchased an extra username on Fragment, OR the bot OWNER'S
# personal Telegram account currently has an active Premium subscription.
# If neither is true, Telegram's servers reject the field on every single
# button that carries it — not just "show it without the icon", the whole
# send/edit call raises a BadRequest. Because every keyboard in this app
# goes through _btn()/_url_btn() in utils/keyboards.py, which both call
# icon_id_for() below, this one flag is the single choke point: main.py
# probes capability once at startup (and the global error handler trips
# it defensively too, in case Premium lapses mid-run), and every button
# built anywhere in the app after that instantly stops attempting icons —
# instead of each of the ~60 call sites that send a keyboard needing its
# own try/except around the live Telegram API call.
_icons_supported: bool = True


def icons_supported() -> bool:
    return _icons_supported


def set_icons_supported(value: bool) -> None:
    global _icons_supported
    _icons_supported = value


def icon_id_for(label: str) -> str | None:
    """Return the configured custom emoji id for a button label, if any —
    or None immediately if capability probing (see main.py) has already
    determined this bot/account combo can't use icon_custom_emoji_id at
    all, so callers never build a button doomed to fail at send time."""
    if not label or not _icons_supported:
        return None
    leading = label.split(" ", 1)[0]
    return PREMIUM_EMOJI_IDS.get(leading)


def tg_emoji(char: str) -> str:
    """Render `char` as a Telegram premium custom emoji INSIDE message
    TEXT (not a button) when an id is configured for it in
    PREMIUM_EMOJI_IDS, falling back to the plain Unicode emoji otherwise.

    This is for HTML-parsed message text — every screen in this bot is
    sent with parse_mode="HTML", so this is safe to use anywhere a plain
    emoji currently appears in a string, e.g. inside heading() below.

    Telegram's <tg-emoji emoji-id="..."> tag has the exact same
    restriction as icon_custom_emoji_id on buttons (see the module
    docstring above): it only renders for bots with a purchased Fragment
    username, or when the bot account itself has Telegram Premium. If
    that's not the case, Telegram silently ignores the tag and just
    shows the plain emoji inside it — so this never needs a try/except,
    unlike the button version. Nothing breaks if you leave the ids
    empty; nothing breaks if a bot account doesn't have Premium either.
    """
    emoji_id = PREMIUM_EMOJI_IDS.get(char)
    if not emoji_id:
        return char
    return f'<tg-emoji emoji-id="{emoji_id}">{char}</tg-emoji>'
