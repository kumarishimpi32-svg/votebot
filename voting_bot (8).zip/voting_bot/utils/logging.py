"""
utils/logging.py
Central logging setup. Filters out anything that looks like a secret
before it ever hits stdout/log files (spec section 77).
"""
from __future__ import annotations
import logging
import re

from security.secrets import SECRET_ENV_VARS

_SECRET_PATTERN = re.compile(
    r"(" + "|".join(re.escape(v) for v in SECRET_ENV_VARS) + r")\s*[:=]\s*\S+",
    re.IGNORECASE,
)


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        if _SECRET_PATTERN.search(msg):
            record.msg = "[redacted log line — potential secret]"
            record.args = ()
        return True


def setup_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.addFilter(RedactingFilter())
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[handler],
    )
    # Keep noisy libraries quieter
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
