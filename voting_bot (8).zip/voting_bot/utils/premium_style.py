"""
utils/premium_style.py

Telegram bots cannot change the client's native font or button background
color — that's a real platform limitation and this codebase doesn't pretend
otherwise (see spec section 13). What professional Telegram bots actually
do for a "custom font" look is render text using Unicode's Mathematical
Alphanumeric Symbols block: these are genuinely different Unicode code
points (not a font trick, not HTML, not an image) that render as bold/
italic sans-serif glyphs in EVERY Telegram client, on every OS, with zero
special support needed. That's what this module provides.

Use sparingly — for section headers and emphasis, not entire paragraphs
(long runs of these glyphs are harder to read and some screen readers
handle them poorly). Digits and basic Latin letters are covered; anything
outside that range (emoji, non-Latin scripts, punctuation) passes through
unchanged automatically.
"""
from __future__ import annotations

# Mathematical Sans-Serif Bold: A-Z, a-z, 0-9
_BOLD_SANS_UPPER_START = 0x1D5D4
_BOLD_SANS_LOWER_START = 0x1D5EE
_BOLD_SANS_DIGIT_START = 0x1D7EC

# Mathematical Sans-Serif Bold Italic: A-Z, a-z (no distinct digit set; falls
# back to bold digits, which is what every "fancy text" tool does too)
_BOLD_ITALIC_UPPER_START = 0x1D63C
_BOLD_ITALIC_LOWER_START = 0x1D656

# Mathematical Monospace: A-Z, a-z, 0-9 — useful for stat blocks/IDs
_MONO_UPPER_START = 0x1D670
_MONO_LOWER_START = 0x1D68A
_MONO_DIGIT_START = 0x1D7F6


def _map_text(text: str, upper_start: int, lower_start: int, digit_start: int | None) -> str:
    out = []
    for ch in text:
        if "A" <= ch <= "Z":
            out.append(chr(upper_start + (ord(ch) - ord("A"))))
        elif "a" <= ch <= "z":
            out.append(chr(lower_start + (ord(ch) - ord("a"))))
        elif digit_start is not None and "0" <= ch <= "9":
            out.append(chr(digit_start + (ord(ch) - ord("0"))))
        else:
            out.append(ch)  # spaces, emoji, punctuation, non-Latin scripts untouched
    return "".join(out)


def premium_font(text: str) -> str:
    """Bold sans-serif Unicode — the main 'premium heading' style."""
    return _map_text(text, _BOLD_SANS_UPPER_START, _BOLD_SANS_LOWER_START, _BOLD_SANS_DIGIT_START)


def premium_font_italic(text: str) -> str:
    """Bold italic sans-serif Unicode — for taglines/subheadings."""
    return _map_text(text, _BOLD_ITALIC_UPPER_START, _BOLD_ITALIC_LOWER_START, _BOLD_SANS_DIGIT_START)


def premium_mono(text: str) -> str:
    """Monospace Unicode — good for IDs, codes, and aligned stat labels."""
    return _map_text(text, _MONO_UPPER_START, _MONO_LOWER_START, _MONO_DIGIT_START)


# ---------------------------------------------------------------------
# Reusable premium chrome (dividers, badges) — plain-Unicode, renders
# identically everywhere, no HTML needed.
# ---------------------------------------------------------------------

DIVIDER = "─" * 18
DIVIDER_HEAVY = "━" * 18
DIVIDER_DOTTED = "┄" * 18


def badge(label: str) -> str:
    """A small bracketed badge, e.g. badge('PREMIUM') -> '⟦ PREMIUM ⟧'."""
    return f"⟦ {label} ⟧"


def title_block(icon: str, text: str) -> str:
    """Icon + premium-font heading + divider underneath, HTML-safe."""
    return f"{icon} <b>{premium_font(text)}</b>\n{DIVIDER}"
