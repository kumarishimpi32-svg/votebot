"""utils/helpers.py — small shared utilities."""
from __future__ import annotations


def safe_int(raw: str, default: int = 0) -> int:
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def chunk(seq: list, size: int):
    for i in range(0, len(seq), size):
        yield seq[i : i + size]


USER_FACING_ERROR = "⚠️ Something went wrong. Please try again."
