"""
utils/small_caps.py

The "premium" font style requested: real distinct Unicode code points (not
a client-side font, not an image, not HTML) that render identically on
every Telegram client. Mapping was derived directly from the user's own
example text (character-by-character, see the derivation script used
while building this), not guessed:

  - Uppercase A-Z: left completely unchanged.
  - Lowercase a-z: mapped to the Unicode "small capital" letters used by
    the IPA/phonetic extensions blocks (ᴀ ʙ ᴄ ᴅ ...) — a handful of
    letters (b, g, j, k, p, q, x, z) don't appear in the user's sample,
    so those use the same glyphs every other "small caps" generator for
    this exact style uses.
  - Digits, spaces, emoji, punctuation: unchanged.

Use `sc(text)` for a single static label/word/phrase. Never pass a
dynamic value through it — usernames, channel links, numeric ids/counts,
and anything inside an HTML tag or a URL must stay byte-for-byte exact,
or they will break (a clickable @username, a t.me link, a numeric ID all
contain lowercase letters that must NOT be re-encoded).
"""
from __future__ import annotations

_MAP = {
    "a": "ᴀ", "b": "ʙ", "c": "ᴄ", "d": "ᴅ", "e": "ᴇ", "f": "ꜰ",
    "g": "ɢ", "h": "ʜ", "i": "ɪ", "j": "ᴊ", "k": "ᴋ", "l": "ʟ",
    "m": "ᴍ", "n": "ɴ", "o": "ᴏ", "p": "ᴘ", "q": "ǫ", "r": "ʀ",
    "s": "ꜱ", "t": "ᴛ", "u": "ᴜ", "v": "ᴠ", "w": "ᴡ", "x": "x",
    "y": "ʏ", "z": "ᴢ",
}


def sc(text: str) -> str:
    """Apply the small-caps style to a static piece of text. Safe to use
    on section headers, labels, and button text — anything the bot wrote
    itself. See module docstring for what NOT to pass through this."""
    return "".join(_MAP.get(ch, ch) for ch in text)
