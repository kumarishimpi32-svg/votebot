"""
handlers/admin.py
Commands for the Payment Admin role specifically (distinct from Bot Owner,
spec section 71/73). Owner-wide controls live in handlers/owner.py.
"""
from __future__ import annotations
from telegram import Update
from telegram.ext import ContextTypes
from security.permissions import Permissions
from services.payment_service import PaymentService
from utils.formatting import fmt_time, esc, payment_verification_card_text
from utils.keyboards import payment_review_buttons


async def payments_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    permissions: Permissions = context.bot_data["permissions"]
    if not permissions.is_payment_admin(update.effective_user.id):
        await update.message.reply_text("❌ You're not an authorized payment admin.")
        return

    payment_service: PaymentService = context.bot_data["payment_service"]
    pending = await payment_service.list_pending()
    if not pending:
        await update.message.reply_text("💰 No pending payments.")
        return

    for p in pending[:10]:
        await update.message.reply_text(
            payment_verification_card_text(
                p.data["user_id"], p.data.get("plan_id"), p.data["amount_inr"],
                p.data["reference"], p.created_at,
            ),
            parse_mode="HTML",
            reply_markup=payment_review_buttons(p.id),
        )
