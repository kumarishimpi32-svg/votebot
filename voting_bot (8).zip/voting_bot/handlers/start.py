"""
handlers/start.py — /start, mandatory membership gate, and home menu.

REWRITTEN:
  - /start now actually enforces the mandatory required-channel
    subscription (spec: "MANDATORY CHANNEL SUBSCRIPTION BEFORE BOT
    ACCESS") before showing anything else. Previously there was no
    membership check here at all — every user, member or not, went
    straight to the home menu.
  - The unfinished Settings screen ("aren't configurable yet... a good
    next feature to add") is gone, along with its home-menu button.
  - Leaderboard is no longer offered as a home-menu button (it's
    event-level only, reached from inside a giveaway).
"""
from __future__ import annotations
import time
from utils.telegram_helpers import safe_edit
from telegram import Update
from telegram.ext import ContextTypes
from config import CONFIG
from services.membership_service import MembershipService
from utils.formatting import home_menu_text, premium_status_text, heading, esc
from utils.small_caps import sc
from utils.keyboards import home_menu, back_home, welcome_banner_menu, membership_gate_keyboard


def _join_url() -> str:
    channel = CONFIG.required_channel
    return f"https://t.me/{channel.lstrip('@')}"


async def _track_bot_user(context: ContextTypes.DEFAULT_TYPE, user) -> None:
    """Records that this Telegram user has started the bot at least once
    (spec: /admin broadcast targets exactly this list — every DM the bot
    can legally message, and nothing else). Deliberately recorded here,
    at the very top of /start, BEFORE the mandatory-channel membership
    gate below — someone who hasn't joined the required channel yet has
    still started the bot and should still be broadcastable to; gating
    the tracking on membership would silently exclude them.

    Idempotent: a returning user just gets last_seen_at refreshed, never
    a duplicate record (save_if_unique is keyed on user_id)."""
    records = context.bot_data.get("records")
    if records is None:
        return
    now = time.time()
    rec, created = await records.save_if_unique(
        "BOT_USER",
        unique_fields={"user_id": user.id},
        data={
            "user_id": user.id,
            "username": user.username,
            "first_seen_at": now,
            "last_seen_at": now,
        },
    )
    if not created:
        await records.update(rec.id, data={"last_seen_at": now, "username": user.username})


def _gate_text(failed: bool = False) -> str:
    if failed:
        return (
            f"{heading('🔒', 'ACCESS REQUIRED')}\n\n"
            f"❌ You haven't joined the channel yet.\n\n"
            f"Please join the channel first, then tap Check Membership again."
        )
    return (
        f"{heading('🔒', 'ACCESS REQUIRED')}\n\n"
        f"Please join our official channel to use the bot."
    )


async def _is_member(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> bool:
    membership_service: MembershipService = context.bot_data["membership_service"]
    return await membership_service.is_member(user_id, CONFIG.required_channel)


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await _track_bot_user(context, user)

    # Real, live Telegram verification — never assume a click means the
    # user actually joined.
    if not await _is_member(context, user.id):
        # Preserve a deep-link giveaway id (if any) so that once membership
        # is verified, the user lands in the giveaway they actually opened
        # the link for, instead of the generic home menu.
        if context.args:
            context.user_data["pending_deep_link"] = context.args[0]
        await update.message.reply_text(
            _gate_text(), parse_mode="HTML", reply_markup=membership_gate_keyboard(_join_url())
        )
        return

    if context.args:
        from handlers.participant import join_cmd
        await join_cmd(update, context)
        return

    records = context.bot_data.get("records")
    banner = await records.find_one("CONFIG", key="welcome_banner") if records else None

    if banner and banner.data.get("file_id"):
        await update.message.reply_photo(
            photo=banner.data["file_id"],
            caption=home_menu_text(user.first_name or user.username or "there"),
            parse_mode="HTML",
            reply_markup=welcome_banner_menu(),
        )
    else:
        await update.message.reply_text(
            home_menu_text(user.first_name or user.username or "there"),
            parse_mode="HTML",
            reply_markup=home_menu(),
        )


async def check_membership_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = update.effective_user

    if not await _is_member(context, user.id):
        await query.answer("❌ Still not a member.", show_alert=True)
        await safe_edit(
            query, _gate_text(failed=True), parse_mode="HTML",
            reply_markup=membership_gate_keyboard(_join_url()),
        )
        return

    await query.answer("✅ Membership verified.")
    pending = context.user_data.pop("pending_deep_link", None)
    if pending:
        from handlers.participant import join_cmd
        context.args = [pending]
        await join_cmd(update, context, message=query.message)
        return

    await safe_edit(
        query,
        "✅ Membership verified.\n\n" + home_menu_text(user.first_name or user.username or "there"),
        parse_mode="HTML",
        reply_markup=home_menu(),
    )


async def home_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    await safe_edit(query, 
        home_menu_text(user.first_name or user.username or "there"),
        parse_mode="HTML",
        reply_markup=home_menu(),
    )


async def giveaways_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    from utils.keyboards import giveaways_submenu
    await safe_edit(query, 
        heading("🎁", "GIVEAWAYS") + "\n\nWhat would you like to do?",
        parse_mode="HTML",
        reply_markup=giveaways_submenu(),
    )


async def profile_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    premium = context.bot_data["premium_service"]
    acc = await premium.get_account(update.effective_user.id)
    active = await premium.is_active(update.effective_user.id)
    user = update.effective_user

    full_name = f"{user.first_name or ''} {user.last_name or ''}".strip()
    lines = [heading("👤", "Profile"), "", f"{sc('Name')}: {esc(full_name) or '—'}"]
    if user.username:
        lines.append(f"{sc('Username')}: @{esc(user.username)}")
    lines.append(f"🆔 {sc('User ID')}: <code>{user.id}</code>")
    lines.append("")
    lines.append(premium_status_text(
        active, acc.data.get("plan_id") if acc else None,
        acc.data.get("started_at") if acc else None,
        acc.data.get("expires_at") if acc else None,
    ))
    await safe_edit(query, "\n".join(lines), parse_mode="HTML", reply_markup=back_home())
