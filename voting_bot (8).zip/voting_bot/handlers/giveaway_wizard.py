"""
handlers/giveaway_wizard.py

REWRITTEN: this used to be a multi-step wizard (pick a channel -> type a
title -> type a description -> type a prize -> pick min-votes -> pick
max-winners -> premium-only "enable Image Protection?" question) before a
giveaway was actually created. That is exactly the kind of creation
questionnaire the product spec explicitly forbids: no title, no
description, no prize, no winner count, no minimum votes, no image
protection question, no wizard.

Creation is now instant: press Create -> the giveaway exists -> a link is
shown. Every value that used to be a typed/tapped wizard step now comes
from a sensible default:
  - channel: the single pre-configured voting channel (CONFIG.voting_channel)
    — the host never has to pick a channel, because there is only ever one
  - title/description/prize: sensible placeholders the host can ignore
  - min_votes / max_winners: 0 / 1
  - image_protection: removed entirely as a concept (see the deleted
    handlers/image_protection.py)

No channel announcement is posted automatically on creation either — the
old "Join & Vote" channel post was a second, redundant way to enter a
giveaway. The single supported way in is the generated link itself, which
the host shares however they like (a Share button is provided).
"""
from __future__ import annotations
import logging
from telegram import Update
from telegram.ext import ContextTypes
from config import CONFIG
from services.giveaway_service import GiveawayService
from services.channel_service import ChannelError
from utils.formatting import heading, host_requires_channel_text, host_pick_channel_text, channel_error_text
from utils.keyboards import share_giveaway_keyboard, add_channel_keyboard, channels_menu_keyboard, channel_error_keyboard

logger = logging.getLogger("giveaway_wizard")


def _resolve_channel_id(giveaway_service: GiveawayService):
    """Legacy single-channel fallback — only used when no channel_service
    is wired at all (context.bot_data has no 'channel_service' key). In
    the real running bot, channel_service is always present (see
    main.py), so this path only exists to keep this module usable in
    isolation (e.g. tests that construct a bare bot_data)."""
    target = CONFIG.voting_channel
    if target.lstrip("-").isdigit():
        return int(target)
    return target


async def _reply(update: Update, text: str, reply_markup) -> None:
    """Sends the given text as a reply, regardless of whether this call
    came from the /creategiveaway command or the Create button."""
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


async def start_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entry point for the Create button and /creategiveaway — creates the
    giveaway immediately, with no questions asked, once a hosting channel
    is resolved.

    Channel resolution (multi-channel CONNECT system, spec §5/§6):

    There is no default/fallback channel for real hosts, ever — every host,
    Premium or not, must connect a channel they themselves administer (and
    that the bot itself is an admin of) before a giveaway can be created
    there:
      - Host has an active connected channel -> host there
        immediately, no questions asked, regardless of how many
        other channels they've also connected. The active pointer
        (set via My Channels, or auto-set the first time a host with
        exactly one channel creates a giveaway) is the durable
        answer to "which channel" — a host who already answered this
        once should never be asked again.
      - Host has exactly one connected channel but hasn't marked it
        active -> auto-activate it (re-verified live) and host there.
      - Host has multiple connected channels and none is active yet
        -> ask them to pick one from My Channels first; nothing is
        created yet. This only happens once — picking sets the
        active pointer, so every giveaway after that skips straight
        to creation.
      - Host has zero connected channels -> ask them to connect one
        (the bot asks for the channel's details) before anything is
        created. Connecting requires BOTH: the requesting user is
        themselves an admin of that channel, AND the bot is an admin of
        it with posting/editing rights — checked live against Telegram,
        never assumed (see ChannelService). Either check failing means
        the channel is rejected and nothing is created.
    ALL of a host's connected channels become this giveaway's
    required_channels (spec: "n number of GC/channel can be added" as the
    join gate) — not just the one they post in.

    If no channel_service is wired at all (bare bot_data, e.g. isolated
    unit tests), this falls back to the single legacy CONFIG.voting_channel
    — purely so this module stays testable standalone. This path is never
    reachable in the real running bot, where channel_service is always
    wired (see main.py).
    """
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    user = update.effective_user
    channel_service = context.bot_data.get("channel_service")

    if channel_service is None:
        # Bare-bot_data test environments only — see docstring above.
        # Never reachable in the real running bot.
        channel_id = _resolve_channel_id(giveaway_service)
        required_channels = [CONFIG.required_channel]
    else:
        owned = await channel_service.list_for_owner(user.id)

        if not owned:
            context.user_data["awaiting_channel_input"] = True
            await _reply(update, host_requires_channel_text(), add_channel_keyboard())
            return

        active = await channel_service.get_active_channel(user.id)

        if active is not None:
            # Already has a standing answer to "which channel" — never
            # ask again just because they've connected more than one.
            # Still re-verify live in case rights were revoked since it
            # was last set active.
            try:
                activated = await channel_service.set_active_channel(user.id, active.id)
            except ChannelError as e:
                await _reply(update, channel_error_text(e.code, e.detail), channel_error_keyboard())
                return
            channel_id = activated.data["chat_id"]
            required_channels = [c.data["chat_id"] for c in owned]
        elif len(owned) > 1:
            # Multiple connected channels, none active yet — genuinely
            # ambiguous, so ask once. Answering (via My Channels) sets
            # the active pointer, so this won't be asked again.
            await _reply(update, host_pick_channel_text(), channels_menu_keyboard(owned, None))
            return
        else:
            # Exactly one connected channel — no ambiguity, so use it
            # directly. Re-verify it live in case rights were revoked
            # since it was connected, and (re)mark it active either way.
            try:
                activated = await channel_service.set_active_channel(user.id, owned[0].id)
            except ChannelError as e:
                await _reply(update, channel_error_text(e.code, e.detail), channel_error_keyboard())
                return
            channel_id = activated.data["chat_id"]
            required_channels = [c.data["chat_id"] for c in owned]

    rec = await giveaway_service.create_giveaway(
        host_id=user.id,
        channel_id=channel_id,
        config={
            "title": f"Giveaway by {user.first_name or user.username or user.id}",
            "description": "",
            "prize": "",
            "min_votes": 0,
            "max_winners": 1,
            "required_channels": required_channels,
            # Manual-review notifications (entries the AI moderator is
            # unsure about) go straight to the host's own DM with the
            # bot by default — there's no separate "review team chat"
            # concept in this product, so the host IS the review chat.
            # Previously this was never set at all, so pending_review
            # entries silently notified no one.
            "review_chat_id": user.id,
        },
    )

    bot_username = context.bot.username
    join_url = f"https://t.me/{bot_username}?start={rec.id}"

    text = (
        f"{heading('🎉', 'GIVEAWAY CREATED')}\n\n"
        f"Your giveaway has been created successfully.\n\n"
        f"🔗 Giveaway Link:\n{join_url}\n\n"
        f"Share this link — anyone who opens it can enter. Manage entries "
        f"anytime from Giveaways → Manage."
    )
    await _reply(update, text, share_giveaway_keyboard(join_url))
