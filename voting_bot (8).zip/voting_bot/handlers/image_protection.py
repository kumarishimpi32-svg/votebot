"""
handlers/image_protection.py
Wires ImageModerationService (previously built but never called by any
handler — a real gap against spec section 63-64) to an actual command:
Premium hosts can enable image_protection on a giveaway, and participants
use /submitphoto to attach a photo to their entry, which is classified
before being accepted. Conservative by design: only a clear REJECT blocks
it automatically; SUSPICIOUS always goes to manual review; the bot never
deletes/restricts anything it doesn't have confirmed permission for.
"""
from __future__ import annotations
from telegram import Update
from telegram.ext import ContextTypes
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.image_moderation import ImageModerationService
from services.ai_moderation import Classification
from utils.formatting import esc, spoiler_mask
from utils.keyboards import review_buttons


async def submitphoto_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: reply isn't needed — send /submitphoto <giveaway_id> as the caption of a photo, or send the command then the photo next.")
        return
    giveaway_id = context.args[0]
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None or giveaway.data.get("state") != "ACTIVE":
        await update.message.reply_text("❌ That giveaway doesn't exist or has ended.")
        return
    if not giveaway.data.get("image_protection"):
        await update.message.reply_text("This giveaway doesn't use image content protection — no photo needed.")
        return

    context.user_data["awaiting_photo_for"] = giveaway_id
    await update.message.reply_text("📸 Send the photo now for review.")


async def handle_photo_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Returns True if this photo was consumed by an active image-submission flow."""
    giveaway_id = context.user_data.get("awaiting_photo_for")
    if not giveaway_id or not update.message.photo:
        return False

    participant_service: ParticipantService = context.bot_data["participant_service"]
    image_moderation: ImageModerationService = context.bot_data["image_moderation"]
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]

    participant = await participant_service.records.find_one(
        "PARTICIPANT", giveaway_id=giveaway_id, telegram_id=update.effective_user.id
    )
    if participant is None:
        await update.message.reply_text("❌ You need to /join this giveaway before submitting a photo.")
        context.user_data.pop("awaiting_photo_for", None)
        return True

    file_id = update.message.photo[-1].file_id  # highest resolution
    classification, reason = await image_moderation.classify_photo(file_id)
    context.user_data.pop("awaiting_photo_for", None)

    await participant_service.records.update(participant.id, data={"photo_file_id": file_id})

    giveaway = await giveaway_service.get(giveaway_id)

    if classification == Classification.SAFE:
        await update.message.reply_text("✅ Photo accepted.")
    elif classification == Classification.REJECT:
        await participant_service.records.update(participant.id, data={"photo_status": "rejected"})
        await update.message.reply_text(
            f"❌ Photo not accepted.\nReason: {spoiler_mask(reason)}", parse_mode="HTML",
        )
        await participant_service.audit.log(
            "image_content_rejected", update.effective_user.id, giveaway_id=giveaway_id,
            details={"participant_id": participant.id, "reason": reason},
        )
    else:  # SUSPICIOUS or UNCERTAIN -> never auto-remove, always manual review
        await participant_service.records.update(participant.id, data={"photo_status": "pending_review"})
        await update.message.reply_text("🛡 Your photo needs a quick manual review.")
        review_chat_id = giveaway.data.get("review_chat_id") if giveaway else None
        if review_chat_id:
            await context.bot.send_photo(
                chat_id=review_chat_id,
                photo=file_id,
                caption=(
                    f"🛡 <b>PHOTO REVIEW</b>\n\n"
                    f"🎁 Giveaway: {esc(giveaway.data.get('title'))}\n"
                    f"👤 Participant: {esc(participant.data.get('name'))}\n"
                    f"🆔 Telegram ID: <code>{update.effective_user.id}</code>\n"
                    f"🤖 Status: {classification.value}\n"
                    f"Reason: {spoiler_mask(reason)}"
                ),
                parse_mode="HTML",
                reply_markup=review_buttons(participant.id),
            )
    return True
