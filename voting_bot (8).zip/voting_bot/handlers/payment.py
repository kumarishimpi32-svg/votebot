"""
handlers/payment.py
Payment reference submission (text state) + Payment Admin approve/reject
buttons (spec 42-47, 71).
"""
from __future__ import annotations
import time
from utils.telegram_helpers import safe_edit, current_html
from telegram import Update
from telegram.ext import ContextTypes
from security.callbacks import decode
from security.validation import validate_payment_reference
from security.permissions import Permissions
from services.payment_service import PaymentService, PaymentError
from services.notification_service import NotificationService
from utils.formatting import fmt_time, esc, heading, payment_verification_card_text
from utils.small_caps import sc
from utils.keyboards import payment_review_buttons
from config import CONFIG


async def handle_payment_reference_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """We now require a payment *screenshot* (photo), not typed text — see
    handle_payment_screenshot_photo below. If the user types text while
    we're waiting on a screenshot, nudge them toward sending the photo
    instead of silently accepting a bare, unverifiable claim.
    Returns True if this message was consumed (i.e. we were waiting on a
    screenshot for this user)."""
    plan_record_id = context.user_data.get("awaiting_payment_reference_for")
    if not plan_record_id:
        return False

    await update.message.reply_text(
        f"📸 {sc('Please send a screenshot of your payment as a photo, not text')}."
    )
    return True


async def handle_payment_screenshot_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Returns True if this photo was consumed as payment proof. Hooked
    into main.photo_router the same way banner/QR photos are."""
    plan_record_id = context.user_data.get("awaiting_payment_reference_for")
    if not plan_record_id:
        return False

    anti_abuse = context.bot_data["anti_abuse"]
    if not anti_abuse.allow_payment_submission(update.effective_user.id):
        await update.message.reply_text(f"⏳ {sc('Too many payment submissions, please wait a bit')}.")
        return True

    # Caption is optional now — it's no longer the proof itself, just a
    # convenience note (e.g. UTR/txn id) alongside the screenshot. Never
    # reject the submission for missing/short caption text.
    #
    # BUG FIX: this used to set `reference = "(screenshot only, no
    # caption)"` — a fixed literal shared by EVERY captionless
    # submission from EVERY user. services/payment_service.py.approve()
    # runs a duplicate-reference guard that rejects a payment as
    # "Duplicate payment reference" the moment another APPROVED payment
    # already has the same reference string. Because caption is
    # optional and captionless screenshot payments are a completely
    # normal, expected path (arguably the most common one for a
    # scan-to-pay QR flow), the very first captionless payment ever
    # approved would permanently poison that shared literal — every
    # other user's captionless payment submitted afterwards would
    # auto-fail approval forever, with no way for a payment admin to
    # override it. A per-submission-unique placeholder (still
    # human-readable for the admin card / /admin transactions search)
    # avoids the collision while keeping the "no caption" info visible.
    caption = (update.message.caption or "").strip()
    if caption:
        ok, ref_or_err = validate_payment_reference(caption)
        reference = ref_or_err if ok else caption[:100]
    else:
        reference = f"(no caption — {update.effective_user.id}-{int(time.time() * 1000)})"

    proof_file_id = update.message.photo[-1].file_id

    payment_service: PaymentService = context.bot_data["payment_service"]
    try:
        payment = await payment_service.submit_payment(
            update.effective_user.id, plan_record_id, reference, proof_file_id=proof_file_id,
        )
    except PaymentError:
        await update.message.reply_text(f"❌ {sc('That plan is no longer available')}.")
        context.user_data.pop("awaiting_payment_reference_for", None)
        return True

    context.user_data.pop("awaiting_payment_reference_for", None)
    await update.message.reply_text(
        f"✅ {sc('Payment screenshot submitted for verification. You will be notified once it is approved')}."
    )

    payment_admins_notified = context.bot_data.get("payment_admin_chat_id") or CONFIG.owner_id
    plan = await payment_service.records.get(plan_record_id)
    caption_text = payment_verification_card_text(
        update.effective_user.id, plan.data["name"], payment.data["amount_inr"],
        payment.data["reference"], payment.created_at,
    )
    # Send the actual screenshot to the payment admin (not just a text
    # card) — that's the whole point of requiring proof: an admin can
    # look at the photo and see whether it's a real, matching payment.
    await context.bot.send_photo(
        chat_id=payment_admins_notified,
        photo=proof_file_id,
        caption=caption_text,
        parse_mode="HTML",
        reply_markup=payment_review_buttons(payment.id),
    )
    return True


async def payment_review_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    action, args = decode(query.data)
    payment_id = args[0]

    permissions: Permissions = context.bot_data["permissions"]
    if not permissions.is_payment_admin(update.effective_user.id):
        await query.answer("❌ You're not authorized to verify payments.", show_alert=True)
        return

    payment_service: PaymentService = context.bot_data["payment_service"]
    notifications: NotificationService = context.bot_data["notifications"]

    if action == "pay_view":
        payment = await payment_service.records.get(payment_id)
        await query.answer(
            f"User {payment.data['user_id']} | Ref: {payment.data['reference']} | "
            f"₹{payment.data['amount_inr']} | {payment.data['duration_days']}d",
            show_alert=True,
        )
        return

    try:
        if action == "pay_ok":
            acc, prev_expiry, new_expiry = await payment_service.approve(payment_id, update.effective_user.id)
            payment = await payment_service.records.get(payment_id)
            plan = await payment_service.records.get(payment.data.get("plan_record_id")) if payment else None
            plan_name = plan.data["name"] if plan else payment.data.get("plan_id", "Premium")
            await safe_edit(query, current_html(query.message) + f"\n\n✅ <b>{sc('Approved')}</b>", parse_mode="HTML")
            if prev_expiry:
                await notifications.premium_renewed(
                    payment.data["user_id"], plan_name, fmt_time(prev_expiry), fmt_time(new_expiry)
                )
            else:
                await notifications.premium_activated(payment.data["user_id"], plan_name, fmt_time(new_expiry))
        else:
            payment = await payment_service.reject(payment_id, update.effective_user.id, reason="Could not verify payment")
            await safe_edit(query, current_html(query.message) + f"\n\n❌ <b>{sc('Rejected')}</b>", parse_mode="HTML")
            await notifications.payment_rejected(payment.data["user_id"], "Could not verify payment")
    except PaymentError as e:
        await query.answer(f"❌ {e}", show_alert=True)
        return

    await query.answer()
