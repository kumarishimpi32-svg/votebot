"""
handlers/leaderboard.py
Public-facing /leaderboard command (spec 35-36): free leaderboard for
everyone, richer premium leaderboard for active Premium users. This was
built as a service earlier but never actually exposed to users — fixed.
"""
from __future__ import annotations
from telegram import Update
from telegram.ext import ContextTypes
from services.leaderboard import LeaderboardService
from services.premium_service import PremiumService
from utils.formatting import leaderboard_header, fmt_time, esc
from utils.premium_style import badge


async def _format_premium_leaderboard(leaderboard: LeaderboardService, giveaway_id: str) -> str:
    stats = await leaderboard.premium_stats(giveaway_id)
    if not stats:
        return leaderboard_header(premium=True) + "\n\nNo participants yet."
    lines = [leaderboard_header(premium=True), ""]
    for i, s in enumerate(stats[:15]):
        rank_icon = ["🥇", "🥈", "🥉"][i] if i < 3 else f"{i + 1}."
        first = fmt_time(s["first_vote_at"]) if s["first_vote_at"] else "—"
        last = fmt_time(s["last_vote_at"]) if s["last_vote_at"] else "—"
        lines.append(
            f"{rank_icon} <b>{esc(s['name'])}</b> — {badge(str(s['votes']))}\n"
            f"    First vote: {first}\n"
            f"    Last vote: {last}"
        )
    return "\n".join(lines)


async def leaderboard_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "Usage: /leaderboard <giveaway_id> — or tap 🏆 Leaderboard from the home menu."
        )
        return
    giveaway_id = context.args[0]

    leaderboard: LeaderboardService = context.bot_data["leaderboard"]
    premium: PremiumService = context.bot_data["premium_service"]

    is_premium = await premium.is_active(update.effective_user.id)

    if not is_premium:
        ranked = await leaderboard.top(giveaway_id, limit=10)
        await update.message.reply_text(leaderboard.format_free(ranked), parse_mode="HTML")
        return

    text = await _format_premium_leaderboard(leaderboard, giveaway_id)
    await update.message.reply_text(text, parse_mode="HTML")
