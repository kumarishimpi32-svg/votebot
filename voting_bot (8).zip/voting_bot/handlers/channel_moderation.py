"""
handlers/channel_moderation.py
Wires ChannelModerationService to live channel posts. See
services/channel_moderation_service.py for the full design rationale
(event-driven, idempotent, never spams the channel).

Covers BOTH: the single bootstrap channel from .env (CONFIG.voting_channel,
back-compat for single-channel setups) AND every channel a host has
actively connected via the CONNECT flow (services/channel_service.py) —
previously only the former was checked, so AI moderation silently did
nothing at all in any channel added through CONNECT.
"""
from __future__ import annotations
import logging
from telegram import Update
from telegram.ext import ContextTypes
from config import CONFIG

logger = logging.getLogger("channel_moderation_handler")


def _matches_voting_channel(chat) -> bool:
    target = CONFIG.voting_channel
    if not target:
        return False
    if target.startswith("@"):
        return bool(chat.username) and f"@{chat.username}".lower() == target.lower()
    try:
        return str(chat.id) == target
    except Exception:
        return False


async def _is_managed_channel(chat, records) -> bool:
    if _matches_voting_channel(chat):
        return True
    if records is None:
        return False
    rec = await records.find_one("CHANNEL", chat_id=chat.id)
    return rec is not None and rec.status == "active"


async def channel_post_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    post = update.channel_post
    if post is None:
        return

    # Never evaluate the bot's own contestant cards / giveaway messages —
    # only content actually posted by someone else in the channel.
    if post.from_user is not None and post.from_user.id == context.bot.id:
        return

    records = context.bot_data.get("records")
    if not await _is_managed_channel(post.chat, records):
        return  # a channel the bot happens to be in, but not one it manages

    moderation = context.bot_data.get("channel_moderation")
    if moderation is None:
        return

    sender_id = post.from_user.id if post.from_user else None

    # Photo monitoring is Premium-only for a host's own connected channel
    # (spec: "IN PREMIUM IT WILL MONITOR ALL PHOTOS ... ON THE CHANNEL") —
    # the bot's own bootstrap channel is always monitored either way.
    # Never blocks/removes anything itself; on a flag it only DMs the
    # channel's owner (see ChannelModerationService.send_alert) —
    # nothing is ever posted publicly about it in the channel.
    if post.photo:
        if not await moderation.channel_owner_has_premium(post.chat.id):
            return
        try:
            alert = await moderation.evaluate_channel_photo(
                chat_id=post.chat.id,
                message_id=post.message_id,
                file_id=post.photo[-1].file_id,
                sender_id=sender_id,
            )
        except Exception:
            logger.exception("Channel photo moderation failed for message %s", post.message_id)
            return
        if alert is not None:
            await moderation.send_alert(context.bot, alert)
        return

    text = post.text or post.caption or ""
    if not text.strip():
        return

    try:
        alert = await moderation.evaluate_channel_post(
            chat_id=post.chat.id,
            message_id=post.message_id,
            text=text,
            sender_id=sender_id,
        )
    except Exception:
        logger.exception("Channel moderation evaluation failed for message %s", post.message_id)
        return

    if alert is not None:
        await moderation.send_alert(context.bot, alert)
