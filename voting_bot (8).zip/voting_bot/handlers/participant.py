"""
handlers/participant.py
Participant entry flow: open a giveaway link (or /join <id>) -> bot asks
for a name -> the next text message from that user is treated as their
name and run through the moderation pipeline.

BUG FIX (participant state): a REJECTED participant used to be told
"You've already entered this giveaway" — the same message shown to an
already-approved/pending participant — because the old
already_registered() matched ANY existing record for that user,
regardless of status. It's now state-aware: PENDING/APPROVED block
re-entry with the correct "already joined" message; REJECTED shows the
actual rejection reason and offers a real "Submit Again" action.

NEW: an auto-approved entry is now published to the voting channel as a
contestant immediately (see services/contestant_service.py) — previously
an approval only updated the database and DMed the participant; the
contestant stayed invisible inside the bot with no way for anyone to vote
for them.
"""
from __future__ import annotations
from telegram.error import TelegramError
from telegram import Update
from telegram.ext import ContextTypes
from config import CONFIG
from security.callbacks import decode
from services.giveaway_service import GiveawayService
from services.participant_service import ParticipantService
from services.contestant_service import ContestantService
from services.membership_service import MembershipService
from services.anti_abuse import AntiAbuseService
from security.validation import validate_display_name
from security.rate_limit import reject_if_limited
from utils.formatting import participant_card, esc, heading, giveaway_membership_gate_text, spoiler_mask
from utils.keyboards import review_buttons, resubmit_keyboard, giveaway_membership_gate_keyboard

_STATUS_LABEL = {
    "approved": "✅ Auto-approved",
    "rejected": "❌ Auto-rejected",
    "pending_review": "🛡 Needs review (AI uncertain)",
}


async def _join_url_for_channel(bot, ref) -> str | None:
    """Best-effort invite link for a required-channel reference — either
    a public '@username' (trivial) or a private numeric chat_id, for
    which we ask Telegram for (or generate) an invite link. The bot is
    guaranteed to be an admin of any channel a host connected themselves
    (verified at connect time in services/channel_service.py), so this
    should virtually always succeed for those; the bot's own default
    channel is expected to be public. Never raises — a failed lookup
    just means no join button is shown for that one channel."""
    ref = str(ref)
    if ref.startswith("@"):
        return f"https://t.me/{ref.lstrip('@')}"
    try:
        chat = await bot.get_chat(ref)
        if chat.username:
            return f"https://t.me/{chat.username}"
        if chat.invite_link:
            return chat.invite_link
        return await bot.export_chat_invite_link(chat_id=ref)
    except TelegramError:
        return None


async def _check_required_channels(update: Update, context: ContextTypes.DEFAULT_TYPE, giveaway, message) -> bool:
    """Per-giveaway join gate (spec: required_channels — a Premium host's
    own connected channel(s), or the bot's default channel for everyone
    else). Real, live Telegram verification every time, exactly like the
    bot-wide /start gate — never assumes a prior pass still holds.
    Returns True if the user may proceed, False if a gate screen was
    shown instead (caller must stop)."""
    required = giveaway.data.get("required_channels") or [CONFIG.required_channel]
    membership_service: MembershipService = context.bot_data["membership_service"]
    ok, missing = await membership_service.is_member_of_all(update.effective_user.id, required)
    if ok:
        return True

    targets = [(str(ref), await _join_url_for_channel(context.bot, ref)) for ref in missing]
    await message.reply_text(
        giveaway_membership_gate_text(),
        parse_mode="HTML",
        reply_markup=giveaway_membership_gate_keyboard(giveaway.id, targets),
    )
    return False


async def check_giveaway_membership_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """✅ Check Membership button on the per-giveaway join gate."""
    query = update.callback_query
    _, args = decode(query.data)
    if not args:
        await query.answer("Invalid selection.", show_alert=True)
        return
    giveaway_id = args[0]
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None or giveaway.data.get("state") != "ACTIVE":
        await query.answer("❌ That giveaway doesn't exist or has ended.", show_alert=True)
        return

    required = giveaway.data.get("required_channels") or [CONFIG.required_channel]
    membership_service: MembershipService = context.bot_data["membership_service"]
    ok, _missing = await membership_service.is_member_of_all(update.effective_user.id, required)
    if not ok:
        await query.answer("❌ Still missing one or more channels.", show_alert=True)
        return

    await query.answer("✅ Membership verified.")
    context.args = [giveaway_id]
    await join_cmd(update, context, message=query.message)


async def join_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE, message=None):
    """message: override for the message to reply on — used when this is
    invoked from a callback (post-membership-check) rather than a real
    /start or /join text command."""
    message = message or update.message
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    participant_service: ParticipantService = context.bot_data["participant_service"]
    args = context.args
    if not args:
        await message.reply_text("Usage: /join <giveaway_id> — or open a giveaway's link directly.")
        return
    giveaway_id = args[0]
    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None or giveaway.data.get("state") != "ACTIVE":
        await message.reply_text("❌ That giveaway doesn't exist or has ended.")
        return

    if not await _check_required_channels(update, context, giveaway, message):
        return

    # State-aware: don't even ask for a name if this user already has a
    # live (pending/approved) entry, and show the CORRECT message if their
    # last entry was rejected instead of a generic "already joined".
    active = await participant_service.get_active_entry(giveaway_id, update.effective_user.id)
    if active is not None:
        status_word = "pending review" if active.status == "pending_review" else "approved"
        await message.reply_text(f"ℹ️ You've already entered this giveaway ({status_word}).")
        return

    latest = await participant_service.latest_entry(giveaway_id, update.effective_user.id)
    if latest is not None and latest.status == "rejected":
        await message.reply_text(
            f"{heading('❌', 'ENTRY REJECTED')}\n\n"
            f"Your entry was not approved.\n\n"
            f"Reason:\n{spoiler_mask(latest.data.get('reject_reason') or latest.data.get('moderation_reason', 'Policy violation'))}",
            parse_mode="HTML",
            reply_markup=resubmit_keyboard(giveaway_id),
        )
        return

    context.user_data["awaiting_name_for"] = giveaway_id
    await message.reply_text(
        f"🎁 <b>{esc(giveaway.data.get('title'))}</b>\n\n"
        f"Please send the display name you want to use for this giveaway.",
        parse_mode="HTML",
    )


async def resubmit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """The 'Submit Again' button on a rejection message."""
    from security.callbacks import decode
    query = update.callback_query
    _, args = decode(query.data)
    giveaway_id = args[0]

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    participant_service: ParticipantService = context.bot_data["participant_service"]
    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None or giveaway.data.get("state") != "ACTIVE":
        await query.answer("❌ That giveaway doesn't exist or has ended.", show_alert=True)
        return

    active = await participant_service.get_active_entry(giveaway_id, update.effective_user.id)
    if active is not None:
        await query.answer("You already have a live entry for this giveaway.", show_alert=True)
        return

    context.user_data["awaiting_name_for"] = giveaway_id
    await query.answer()
    await query.message.reply_text(
        f"🎁 <b>{esc(giveaway.data.get('title'))}</b>\n\n"
        f"Please send the display name you want to use for this giveaway.",
        parse_mode="HTML",
    )


async def handle_free_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Generic text router — currently only handles the 'awaiting name' state."""
    giveaway_id = context.user_data.get("awaiting_name_for")
    if not giveaway_id:
        return  # not something this handler cares about

    anti_abuse: AntiAbuseService = context.bot_data["anti_abuse"]
    if await reject_if_limited(update, anti_abuse.allow_registration(update.effective_user.id)):
        return

    name = update.message.text.strip()
    ok, err = validate_display_name(name)
    if not ok:
        await update.message.reply_text(f"❌ {err} Try again.")
        return

    participant_service: ParticipantService = context.bot_data["participant_service"]
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]

    # Acknowledge immediately. Moderation can take a couple of AI calls
    # (first check + a double-check if the first is SUSPICIOUS) before the
    # real verdict is ready, and that round trip has a real, if now bounded,
    # network latency — so give instant feedback rather than leaving the
    # user staring at silence while it runs.
    ack = await update.message.reply_text("⏳ Checking your entry…")

    rec, status = await participant_service.register(giveaway_id, update.effective_user.id, name)
    context.user_data.pop("awaiting_name_for", None)

    try:
        await ack.delete()
    except Exception:
        pass  # never let a failed cleanup of the ack message block the real result

    if status == "already_registered":
        await update.message.reply_text("ℹ️ You've already entered this giveaway.")
        return

    giveaway = await giveaway_service.get(giveaway_id)

    if status == "approved":
        await update.message.reply_text(
            "✅ You're in! Your entry has been approved.\n\n" + participant_card(name, update.effective_user.id, 0),
            parse_mode="HTML",
        )
        # Approved participant -> contestant profile in the voting channel,
        # immediately and exactly once (see ContestantService docstring).
        contestant_service: ContestantService = context.bot_data["contestant_service"]
        await contestant_service.publish_if_needed(context.bot, giveaway_id, rec.id)
    elif status == "rejected":
        await update.message.reply_text(
            f"{heading('❌', 'ENTRY REJECTED')}\n\n"
            f"Your entry was not approved.\n\n"
            f"Reason:\n{spoiler_mask(rec.data.get('moderation_reason', 'policy violation'))}",
            parse_mode="HTML",
            reply_markup=resubmit_keyboard(giveaway_id),
        )
    else:  # pending_review
        await update.message.reply_text(
            "🛡 Your entry needs a quick manual review. You'll be notified once it's approved."
        )

    # Always give the review chat (if configured) visibility + override
    # control, regardless of which way the automated decision went.
    # The submitted name itself is only spoiler-masked when it was
    # actually flagged (rejected / pending manual review) — an
    # auto-approved name is presumed clean, so showing it plainly here
    # doesn't risk reposting anything Telegram would object to. A
    # flagged name might BE the violating content, so it gets the same
    # tap-to-reveal, first/last-letter masking as the moderation reason
    # — visible enough for the host to recognize and judge it, without
    # the bot itself plainly restating something that broke the rules.
    review_chat_id = giveaway.data.get("review_chat_id") if giveaway else None
    if review_chat_id:
        display_name = spoiler_mask(name) if status in ("rejected", "pending_review") else esc(name)
        await context.bot.send_message(
            chat_id=review_chat_id,
            text=(
                f"🛡 <b>MODERATION DECISION</b>\n\n"
                f"🎁 Giveaway: {esc(giveaway.data.get('title'))}\n"
                f"👤 Participant: {display_name}\n"
                f"🆔 Telegram ID: <code>{update.effective_user.id}</code>\n"
                f"📝 Submitted Name: {display_name}\n"
                f"🤖 Moderation: {_STATUS_LABEL.get(status, status)}\n"
                f"Reason: {spoiler_mask(rec.data.get('moderation_reason', '—'))}"
            ),
            parse_mode="HTML",
            reply_markup=review_buttons(rec.id),
        )
