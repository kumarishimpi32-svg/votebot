"""
handlers/pickers.py

The "no copy-paste" layer: every place the bot previously needed a typed
giveaway_id or participant_id now has a button-driven equivalent here.
Users tap a giveaway from a list; hosts tap a participant from a list;
vote amounts are quick-pick buttons with a "custom amount" fallback for
anything not covered by the presets (title/description/prize text still
has to be typed — there's no way around free-text content — but no ID is
ever typed or pasted anywhere in the app now).
"""
from __future__ import annotations
from utils.telegram_helpers import safe_edit
from telegram import Update
from telegram.ext import ContextTypes
from security.callbacks import decode
from security.validation import validate_vote_amount
from services.vote_service import VoteError
from utils.formatting import dashboard_text
from utils.keyboards import (
    host_dashboard, participant_picker, back_home, giveaway_picker,
)
from handlers import host as host_handlers


async def giveaway_selected_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    action, args = decode(query.data)  # action = "pg_dash" / "pg_publish" / "pg_addv" / etc.
    ctx_code = action.split("_", 1)[1]
    giveaway_id = args[0]

    giveaway_service = context.bot_data["giveaway_service"]
    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None:
        await query.answer("This giveaway no longer exists.", show_alert=True)
        return

    is_host = await giveaway_service.is_host(giveaway_id, update.effective_user.id)

    if ctx_code == "dash":
        if not is_host:
            await query.answer("❌ Only the host can open this dashboard.", show_alert=True)
            return
        analytics = context.bot_data["analytics"]
        stats = await analytics.giveaway_stats(giveaway_id)
        await safe_edit(query, 
            dashboard_text(giveaway.data.get("title", ""), stats),
            parse_mode="HTML", reply_markup=host_dashboard(giveaway_id),
        )
        await query.answer()

    elif ctx_code == "publish":
        if not is_host:
            await query.answer("❌ Only the host can publish.", show_alert=True)
            return
        contestant_service = context.bot_data["contestant_service"]
        posted = await contestant_service.publish_all_pending(context.bot, giveaway_id)
        await safe_edit(query, f"✅ Published {posted} new participant(s) to the channel.", reply_markup=back_home())
        await query.answer()

    elif ctx_code in ("addv", "remv"):
        if not is_host:
            await query.answer("❌ Only the host can do that.", show_alert=True)
            return
        participant_service = context.bot_data["participant_service"]
        participants = await participant_service.list_for_giveaway(giveaway_id, status="approved")
        if not participants:
            await query.answer("No approved participants yet.", show_alert=True)
            return
        verb = "add votes to" if ctx_code == "addv" else "remove votes from"
        await safe_edit(query, 
            f"{'➕' if ctx_code == 'addv' else '➖'} Pick a participant to {verb}:",
            reply_markup=participant_picker(participants, giveaway_id, f"pp_{ctx_code}"),
        )
        await query.answer()

    elif ctx_code == "undo":
        if not is_host:
            await query.answer("❌ Only the host can do that.", show_alert=True)
            return
        vote_service = context.bot_data["vote_service"]
        try:
            _, participant_id = await vote_service.undo_last_manual_action(giveaway_id, update.effective_user.id)
            contestant_service = context.bot_data.get("contestant_service")
            if contestant_service is not None:
                await contestant_service.refresh_card(context.bot, participant_id)
            await query.answer("↩️ Last manual vote action undone.", show_alert=True)
        except VoteError as e:
            await query.answer(f"Nothing to undo ({e}).", show_alert=True)

    elif ctx_code == "end":
        if not is_host:
            await query.answer("❌ Only the host can do that.", show_alert=True)
            return
        await host_handlers._dash_end(update, context, giveaway_id)

    elif ctx_code == "exp":
        if not is_host:
            await query.answer("❌ Only the host can do that.", show_alert=True)
            return
        await host_handlers._dash_export(update, context, giveaway_id)

    elif ctx_code == "lb":
        leaderboard = context.bot_data["leaderboard"]
        premium = context.bot_data["premium_service"]
        is_premium = await premium.is_active(update.effective_user.id)
        if is_premium:
            from handlers.leaderboard import _format_premium_leaderboard
            text = await _format_premium_leaderboard(leaderboard, giveaway_id)
        else:
            ranked = await leaderboard.top(giveaway_id, limit=10)
            text = leaderboard.format_free(ranked)
        await safe_edit(query, text, parse_mode="HTML", reply_markup=back_home())
        await query.answer()

    else:
        await query.answer("Unknown action.", show_alert=True)


async def participant_selected_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pick a participant, then go straight to typing the vote count.

    There used to be an in-between step here: a grid of quick-pick amount
    buttons (-1/-5/-10/-25/-50/-100) built by utils.keyboards.amount_picker.
    That step is removed — the host already knows the number they want to
    add or remove, so a picker of preset numbers doesn't help and only adds
    an extra tap. It was also broken: each preset button encoded
    (giveaway_id, participant_id, amount) into its callback_data, but the
    handler that read it back (the old vote_amount_callback) unpacked FOUR
    values from a THREE-item list — args[3] didn't exist — so tapping any
    preset raised an IndexError, which is why votes never actually got
    added and the user saw "Something went wrong. Please try again."
    Typing the number, as below, sidesteps that broken path entirely.
    """
    query = update.callback_query
    action, args = decode(query.data)  # action = "pp_addv" or "pp_remv"
    giveaway_id, participant_id = args[0], args[1]
    direction = "a" if action == "pp_addv" else "r"

    giveaway_service = context.bot_data["giveaway_service"]
    if not await giveaway_service.is_host(giveaway_id, update.effective_user.id):
        await query.answer("❌ Only the host can do that.", show_alert=True)
        return

    verb = "add" if direction == "a" else "remove"
    context.user_data["awaiting_vote_amount"] = {
        "direction": direction, "giveaway_id": giveaway_id, "participant_id": participant_id,
    }
    await safe_edit(query, 
        f"✏️ Send the number of votes to {verb} as a message.",
        reply_markup=back_home(),
    )
    await query.answer()


async def giveaways_menu_action_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the 🎁 Giveaways submenu's Create / Manage / Join buttons."""
    query = update.callback_query
    action, _ = decode(query.data)

    if action == "gw_create":
        from handlers.giveaway_wizard import start_wizard
        await start_wizard(update, context)
        return

    if action == "gw_manage":
        giveaway_service = context.bot_data["giveaway_service"]
        giveaways = await giveaway_service.list_by_host(update.effective_user.id)
        if not giveaways:
            await query.answer("You don't host any giveaways yet — tap 🎁 Create to start one.", show_alert=True)
            return
        await safe_edit(query, 
            "🗂 <b>Pick a giveaway to manage:</b>", parse_mode="HTML",
            reply_markup=giveaway_picker(giveaways[:20], "pg_dash"),
        )
        await query.answer()
        return

    await query.answer("Unknown action.", show_alert=True)


async def handle_custom_vote_amount_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Returns True if this text message was consumed as a custom vote amount."""
    pending = context.user_data.get("awaiting_vote_amount")
    if pending is None:
        return False

    ok, amount, err = validate_vote_amount(update.message.text)
    if not ok:
        await update.message.reply_text(f"❌ {err} Try again.")
        return True

    vote_service = context.bot_data["vote_service"]
    context.user_data.pop("awaiting_vote_amount", None)
    try:
        if pending["direction"] == "a":
            await vote_service.add_manual_vote(pending["giveaway_id"], pending["participant_id"], update.effective_user.id, amount)
        else:
            await vote_service.remove_manual_vote(pending["giveaway_id"], pending["participant_id"], update.effective_user.id, amount)
        contestant_service = context.bot_data.get("contestant_service")
        if contestant_service is not None:
            await contestant_service.refresh_card(context.bot, pending["participant_id"])
        await update.message.reply_text(
            f"✅ {'Added' if pending['direction'] == 'a' else 'Removed'} {amount} vote(s).",
            reply_markup=host_dashboard(pending["giveaway_id"]),
        )
    except VoteError:
        await update.message.reply_text("❌ Could not update votes.")
    return True
