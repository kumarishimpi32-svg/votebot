"""handlers/moderation.py — manual review APPROVE/REJECT buttons (spec 20-21).

Fix: previously only names the AI/local-filter marked "pending_review" ever
got a review card with buttons — a clean auto-approve or auto-reject (e.g.
a name the local filter or AI flagged as clearly bad, including bad words
in other languages) never surfaced to a human at all, so a host had no way
to catch a false positive/negative. Now EVERY registration decision posts
a review card to the review chat, and admins can approve/reject (i.e.
override) regardless of what the automated decision was.
"""
from __future__ import annotations
from utils.telegram_helpers import safe_edit, current_html
from telegram import Update
from telegram.ext import ContextTypes
from security.callbacks import decode
from security.permissions import Permissions
from services.participant_service import ParticipantService
from services.notification_service import NotificationService
from services.giveaway_service import GiveawayService


async def review_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    action, args = decode(query.data)
    participant_id = args[0]

    participant_service: ParticipantService = context.bot_data["participant_service"]
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    permissions: Permissions = context.bot_data["permissions"]
    notifications: NotificationService = context.bot_data["notifications"]

    participant = await participant_service.records.get(participant_id)
    if participant is None:
        await query.answer("Not found.", show_alert=True)
        return

    giveaway_id = participant.data["giveaway_id"]

    # CRITICAL: verify the clicker is currently an admin of the configured
    # review chat — never trust that this button was only shown to admins.
    is_reviewer = await permissions.is_review_admin(giveaway_id, update.effective_user.id)
    if not is_reviewer:
        await query.answer("❌ Only review-chat administrators can act on this.", show_alert=True)
        return

    giveaway = await giveaway_service.get(giveaway_id)
    title = giveaway.data.get("title") if giveaway else "the giveaway"
    previous_status = participant.status

    # Deliberately NOT restricted to status == "pending_review" — an admin
    # can override ANY prior decision (auto-approve or auto-reject) here.
    if action == "review_ok":
        await participant_service.approve(participant_id, update.effective_user.id)
        new_label = "✅ APPROVED"
        if previous_status != "approved":
            await notifications.participant_approved(participant.data["telegram_id"], title)
        # Manual approval (including a manual override of an auto-rejection)
        # must publish the contestant just like an auto-approval does —
        # this is the single shared, idempotent path (services/contestant_service.py).
        contestant_service = context.bot_data["contestant_service"]
        await contestant_service.publish_if_needed(context.bot, giveaway_id, participant_id)
    else:
        await participant_service.reject(participant_id, update.effective_user.id, reason="Manual review")
        new_label = "❌ REJECTED"
        if previous_status != "rejected":
            await notifications.participant_rejected(participant.data["telegram_id"], title, "Manual review")

    base_text = current_html(query.message).split("\n\n🔘")[0]  # strip any prior status footer before re-adding
    await safe_edit(query, 
        f"{base_text}\n\n🔘 <b>Current decision: {new_label}</b> (admin: <code>{update.effective_user.id}</code>)",
        parse_mode="HTML",
        reply_markup=query.message.reply_markup,  # keep buttons active so admin can flip the decision again
    )
    await query.answer(f"Decision set: {new_label}")
