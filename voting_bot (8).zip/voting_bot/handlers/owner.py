"""
handlers/owner.py
/admin — owner-only global control panel (spec 8-9, 69-71, 83-86).
Verified strictly against CONFIG.owner_id (numeric Telegram user id),
never username/display-name/claims.
"""
from __future__ import annotations
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import Forbidden, BadRequest, RetryAfter, TelegramError
from config import CONFIG
from services.premium_service import PremiumService
from services.analytics import AnalyticsService
from services.audit_service import AuditService
from security.permissions import Permissions
from utils.formatting import fmt_time

HELP = (
    "👑 <b>ADMIN</b>\n\n"
    "<code>/admin overview</code>\n"
    "<code>/admin storage</code>\n"
    "<code>/admin ai</code>\n"
    "<code>/admin filter view|add &lt;term&gt;|remove &lt;term&gt;</code>\n"
    "<code>/admin plan create &lt;plan_id&gt; | &lt;name&gt; | &lt;days&gt; | &lt;price_inr&gt;</code>\n"
    "<code>/admin premium grant &lt;user_id&gt; &lt;days&gt;</code>\n"
    "<code>/admin premium revoke &lt;user_id&gt;</code>\n"
    "<code>/admin payadmin add|remove &lt;user_id&gt;</code>\n"
    "<code>/admin transactions [user &lt;id&gt;|ref &lt;reference&gt;]</code>\n"
    "<code>/admin banner</code> — set the /start welcome photo\n"
    "<code>/admin paymentqr</code> — set the QR code shown at checkout\n"
    "<code>/admin audit</code>\n"
    "<code>/broadcast</code> — reply to any message with this to DM-copy "
    "it to everyone who has ever started the bot\n"
)


async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != CONFIG.owner_id:
        # Do not reveal that /admin exists differently for non-owners — just refuse.
        await update.message.reply_text("❌ Unknown command.")
        return

    args = context.args
    if not args:
        await update.message.reply_text(HELP, parse_mode="HTML")
        return

    sub = args[0].lower()
    rest = args[1:]

    if sub == "overview":
        await _overview(update, context)
    elif sub == "storage":
        await _storage(update, context)
    elif sub == "ai":
        await _ai(update, context)
    elif sub == "filter":
        await _filter(update, context, rest)
    elif sub == "plan":
        await _plan(update, context, rest)
    elif sub == "premium":
        await _premium(update, context, rest)
    elif sub == "payadmin":
        await _payadmin(update, context, rest)
    elif sub == "audit":
        await _audit(update, context)
    elif sub == "transactions":
        await _transactions(update, context, rest)
    elif sub == "banner":
        await _banner_start(update, context)
    elif sub == "paymentqr":
        await _paymentqr_start(update, context)
    else:
        await update.message.reply_text(HELP, parse_mode="HTML")


async def _overview(update, context):
    analytics: AnalyticsService = context.bot_data["analytics"]
    stats = await analytics.owner_overview()
    from utils.formatting import owner_overview_text
    await update.message.reply_text(owner_overview_text(stats), parse_mode="HTML")


async def _storage(update, context):
    storage = context.bot_data["storage"]
    h = storage.health()
    await update.message.reply_text(
        "🗄 <b>STORAGE</b>\n\n"
        f"Status: {h['status']}\n"
        f"Records: {h['records']}\n"
        f"Last successful write: {fmt_time(h['last_write_ok'])}\n"
        f"Consecutive failures: {h['consecutive_failures']}\n"
        f"Last error: {h['last_write_error'] or '—'}\n\n"
        f"<i>Note: Telegram message history cannot be auto-replayed by a bot "
        f"(no Bot API method for it). Recovery uses a local snapshot file — "
        f"see storage/telegram_storage.py for details.</i>",
        parse_mode="HTML",
    )


async def _ai(update, context):
    pool = context.bot_data["api_pool"]
    h = pool.health_report()
    lines = [
        "🤖 <b>AI SYSTEM</b>\n",
        f"Configured Keys: {h['configured_keys']}",
        f"Healthy: {h['healthy']}",
        f"Cooldown: {h['cooldown']}",
        f"Unhealthy: {h['unhealthy']}",
    ]
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def _filter(update, context, rest):
    name_filter = context.bot_data["name_filter"]
    if not rest or rest[0] == "view":
        await update.message.reply_text(f"📝 Blocked terms: {name_filter.stats()['blocked_terms']}")
    elif rest[0] == "add" and len(rest) > 1:
        term = " ".join(rest[1:])
        name_filter.add(term)
        await update.message.reply_text(f"✅ Added '{term}' to blocked names.")
    elif rest[0] == "remove" and len(rest) > 1:
        term = " ".join(rest[1:])
        ok = name_filter.remove(term)
        await update.message.reply_text("✅ Removed." if ok else "Not found.")
    elif rest[0] == "reload":
        n = name_filter.reload()
        await update.message.reply_text(f"🔄 Reloaded. {n} terms active.")
    else:
        await update.message.reply_text(HELP, parse_mode="HTML")


async def _plan(update, context, rest):
    premium: PremiumService = context.bot_data["premium_service"]
    if not rest or rest[0] != "create":
        await update.message.reply_text(HELP, parse_mode="HTML")
        return
    raw = " ".join(rest[1:])
    parts = [p.strip() for p in raw.split("|")]
    if len(parts) < 4:
        await update.message.reply_text("Usage: /admin plan create <plan_id> | <name> | <days> | <price_inr>")
        return
    plan_id, name, days_raw, price_raw = parts[:4]
    try:
        days, price = int(days_raw), int(price_raw)
    except ValueError:
        await update.message.reply_text("❌ days and price_inr must be numbers.")
        return
    await premium.create_plan(update.effective_user.id, plan_id, name, days, price)
    await update.message.reply_text(f"✅ Plan '{name}' created: ₹{price} / {days} days.")


async def _premium(update, context, rest):
    premium: PremiumService = context.bot_data["premium_service"]
    if len(rest) < 2:
        await update.message.reply_text(HELP, parse_mode="HTML")
        return
    action = rest[0]
    try:
        user_id = int(rest[1])
    except ValueError:
        await update.message.reply_text("❌ user_id must be numeric.")
        return

    if action == "grant":
        if len(rest) < 3:
            await update.message.reply_text("Usage: /admin premium grant <user_id> <days>")
            return
        try:
            days = int(rest[2])
        except ValueError:
            await update.message.reply_text("❌ days must be numeric.")
            return
        _, prev, new = await premium.activate_or_extend(user_id, update.effective_user.id, days, source="owner_grant")
        await update.message.reply_text(f"✅ Granted {days} days. New expiry: {fmt_time(new)}")
    elif action == "revoke":
        await premium.revoke(user_id, update.effective_user.id, reason="owner_revoke")
        await update.message.reply_text("✅ Premium revoked.")
    else:
        await update.message.reply_text(HELP, parse_mode="HTML")


async def _payadmin(update, context, rest):
    permissions: Permissions = context.bot_data["permissions"]
    if len(rest) < 2:
        await update.message.reply_text(HELP, parse_mode="HTML")
        return
    action, user_id_raw = rest[0], rest[1]
    try:
        user_id = int(user_id_raw)
    except ValueError:
        await update.message.reply_text("❌ user_id must be numeric.")
        return
    if action == "add":
        permissions.grant_payment_admin(user_id)
        await permissions.persist_payment_admin_grant(user_id)
        await update.message.reply_text(f"✅ {user_id} is now a Payment Admin.")
    elif action == "remove":
        permissions.revoke_payment_admin(user_id)
        await permissions.persist_payment_admin_revoke(user_id)
        await update.message.reply_text(f"✅ {user_id} removed as Payment Admin.")
    else:
        await update.message.reply_text(HELP, parse_mode="HTML")


async def _audit(update, context):
    audit: AuditService = context.bot_data["audit_service"]
    logs = await audit.global_log(limit=15)
    if not logs:
        await update.message.reply_text("No audit events yet.")
        return
    lines = ["📜 <b>RECENT AUDIT EVENTS</b>\n"]
    for a in reversed(logs):
        lines.append(f"• {fmt_time(a.created_at)} — {a.data.get('action')} (actor {a.data.get('actor_id')})")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def _transactions(update, context, rest):
    """Spec section 55: owner transaction dashboard — pending/approved/
    rejected counts, total verified INR, search by user/reference."""
    payment_service = context.bot_data["payment_service"]
    records = context.bot_data["records"]

    if rest and rest[0] == "user" and len(rest) > 1:
        try:
            user_id = int(rest[1])
        except ValueError:
            await update.message.reply_text("❌ user_id must be numeric.")
            return
        history = await payment_service.user_history(user_id)
        if not history:
            await update.message.reply_text(f"No transactions for user {user_id}.")
            return
        lines = [f"💰 <b>TRANSACTIONS — user {user_id}</b>\n"]
        for p in sorted(history, key=lambda r: r.created_at):
            lines.append(
                f"• {fmt_time(p.created_at)} — {p.data.get('plan_id')} — ₹{p.data.get('amount_inr')} — {p.status.upper()}"
            )
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")
        return

    if rest and rest[0] == "ref" and len(rest) > 1:
        reference = " ".join(rest[1:])
        matches = await records.find("PREMIUM_PAYMENT", reference=reference)
        if not matches:
            await update.message.reply_text(f"No payment found with reference '{reference}'.")
            return
        lines = [f"🔎 <b>PAYMENTS matching '{reference}'</b>\n"]
        for p in matches:
            lines.append(
                f"• user {p.data.get('user_id')} — ₹{p.data.get('amount_inr')} — {p.status.upper()} — {fmt_time(p.created_at)}"
            )
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")
        return

    all_payments = await records.list("PREMIUM_PAYMENT")
    pending = [p for p in all_payments if p.status == "pending"]
    approved = [p for p in all_payments if p.status == "approved"]
    rejected = [p for p in all_payments if p.status == "rejected"]
    total_verified_inr = sum(p.data.get("amount_inr", 0) for p in approved)

    plan_counts: dict[str, int] = {}
    for p in approved:
        plan_id = p.data.get("plan_id", "unknown")
        plan_counts[plan_id] = plan_counts.get(plan_id, 0) + 1
    popular = sorted(plan_counts.items(), key=lambda kv: kv[1], reverse=True)[:5]

    renewals = await records.list("PREMIUM_TRANSACTION")
    renewal_count = sum(1 for t in renewals if t.data.get("previous_expiry"))

    lines = [
        "💰 <b>TRANSACTIONS</b>\n",
        f"Pending: {len(pending)}",
        f"Approved: {len(approved)}",
        f"Rejected: {len(rejected)}",
        f"Total verified: ₹{total_verified_inr}",
        f"Renewals: {renewal_count}",
        "",
        "Popular plans:",
    ]
    for plan_id, count in popular:
        lines.append(f"  • {plan_id}: {count}")
    lines.append("")
    lines.append("Search: <code>/admin transactions user &lt;id&gt;</code> or <code>/admin transactions ref &lt;reference&gt;</code>")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def _banner_start(update, context):
    context.user_data["awaiting_banner_photo"] = True
    await update.message.reply_text(
        "📸 Send the banner photo now — it becomes the image shown on /start for everyone."
    )


async def handle_banner_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Returns True if this photo was consumed as a new welcome banner."""
    if not context.user_data.get("awaiting_banner_photo"):
        return False
    if update.effective_user.id != CONFIG.owner_id:
        # Defense in depth: only the owner could have set this flag via
        # /admin banner in the first place, but never trust state alone.
        context.user_data.pop("awaiting_banner_photo", None)
        return False

    file_id = update.message.photo[-1].file_id
    records = context.bot_data["records"]
    existing = await records.find_one("CONFIG", key="welcome_banner")
    if existing:
        await records.update(existing.id, data={"file_id": file_id})
    else:
        await records.save("CONFIG", {"key": "welcome_banner", "file_id": file_id})

    context.user_data.pop("awaiting_banner_photo", None)
    await update.message.reply_text("✅ Welcome banner updated. Try /start to see it.")
    return True


async def _paymentqr_start(update, context):
    context.user_data["awaiting_payment_qr_photo"] = True
    await update.message.reply_text(
        "📸 Send the payment QR code photo now — it will be shown to everyone "
        "buying Premium, alongside your payment instructions."
    )


async def handle_payment_qr_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Returns True if this photo was consumed as a new payment QR code."""
    if not context.user_data.get("awaiting_payment_qr_photo"):
        return False
    if update.effective_user.id != CONFIG.owner_id:
        # Defense in depth: only the owner could have set this flag via
        # /admin paymentqr in the first place, but never trust state alone.
        context.user_data.pop("awaiting_payment_qr_photo", None)
        return False

    file_id = update.message.photo[-1].file_id
    records = context.bot_data["records"]
    existing = await records.find_one("CONFIG", key="payment_qr")
    if existing:
        await records.update(existing.id, data={"file_id": file_id})
    else:
        await records.save("CONFIG", {"key": "payment_qr", "file_id": file_id})

    context.user_data.pop("awaiting_payment_qr_photo", None)
    await update.message.reply_text("✅ Payment QR updated. It will now show at checkout.")
    return True


# ----------------------------------------------------------------------
# Broadcast — reply to any message with /broadcast (or /boadcast) to
# DM-copy it to every user who has ever /start'd the bot (see
# handlers/start.py:_track_bot_user for how that list is built).
# ----------------------------------------------------------------------
_BROADCAST_SEND_DELAY = 0.05  # ~20 msg/s — comfortably under Telegram's
                               # bot-wide ~30 msg/s cap, leaving headroom
                               # for whatever else the bot is doing.


async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != CONFIG.owner_id:
        # Do not reveal that /broadcast exists differently for non-owners.
        await update.message.reply_text("❌ Unknown command.")
        return

    target = update.message.reply_to_message
    if target is None:
        await update.message.reply_text(
            "📢 Send (or forward) whatever you want to broadcast as a normal "
            "message first, then reply to THAT message with /broadcast.\n\n"
            "It gets copied — text, photo, video, whatever it is — into a "
            "private DM to everyone who has ever started this bot. Never "
            "posted to any group or channel."
        )
        return

    records = context.bot_data["records"]
    audit: AuditService = context.bot_data["audit_service"]

    users = await records.list("BOT_USER")
    user_ids = sorted({u.data["user_id"] for u in users if u.data.get("user_id")})
    if not user_ids:
        await update.message.reply_text("No recorded users to broadcast to yet — nobody has started the bot.")
        return

    status = await update.message.reply_text(f"📢 Broadcasting to {len(user_ids)} user(s)... 0 sent so far.")

    sent = 0
    blocked = 0
    other_failed = 0
    for i, uid in enumerate(user_ids, start=1):
        for attempt in range(2):  # one retry, only for a rate-limit backoff
            try:
                await context.bot.copy_message(
                    chat_id=uid,
                    from_chat_id=target.chat_id,
                    message_id=target.message_id,
                )
                sent += 1
                break
            except RetryAfter as e:
                await asyncio.sleep(e.retry_after + 0.5)
                continue
            except Forbidden:
                # User blocked the bot, deleted their account, or never
                # actually opened a private chat with it (e.g. only ever
                # hit /start inside a group) — Telegram refuses to let a
                # bot DM-initiate to that user. Expected and common at
                # scale; just skip them, never raise.
                blocked += 1
                break
            except BadRequest:
                other_failed += 1
                break
            except TelegramError:
                other_failed += 1
                break

        if i % 25 == 0 or i == len(user_ids):
            try:
                await status.edit_text(
                    f"📢 Broadcasting to {len(user_ids)} user(s)... {sent} sent so far ({i}/{len(user_ids)})."
                )
            except TelegramError:
                pass  # "message not modified" or similar — never fatal to the broadcast itself

        await asyncio.sleep(_BROADCAST_SEND_DELAY)

    await status.edit_text(
        "📢 <b>BROADCAST COMPLETE</b>\n\n"
        f"✅ Delivered: {sent}\n"
        f"🚫 Blocked/unreachable: {blocked}\n"
        f"❌ Other failures: {other_failed}\n"
        f"👥 Total recorded users: {len(user_ids)}",
        parse_mode="HTML",
    )
    await audit.log(
        "broadcast_sent", update.effective_user.id,
        details={"sent": sent, "blocked": blocked, "other_failed": other_failed, "total": len(user_ids)},
    )
