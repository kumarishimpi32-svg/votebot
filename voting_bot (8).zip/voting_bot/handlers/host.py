"""
handlers/host.py
Host dashboard + /addvote /removevote /undo /end (spec 24-26, 32, 68).
"""
from __future__ import annotations
from utils.telegram_helpers import safe_edit
import io
from telegram import Update, InputFile
from telegram.ext import ContextTypes
from services.giveaway_service import GiveawayService
from services.vote_service import VoteService, VoteError
from services.analytics import AnalyticsService
from services.winner_service import WinnerService
from services.export_service import ExportService
from security.validation import validate_vote_amount
from security.callbacks import decode
from utils.formatting import dashboard_text, esc, spoiler_mask
from utils.keyboards import host_dashboard, tie_break_picker, review_buttons


async def _require_host(update: Update, context: ContextTypes.DEFAULT_TYPE, giveaway_id: str) -> bool:
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    if not await giveaway_service.is_host(giveaway_id, update.effective_user.id):
        await update.message.reply_text("❌ Only the host of this giveaway can do that.")
        return False
    return True


async def imageprotection_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Premium hosts toggle photo-verified entries (/submitphoto) on/off
    for one of their giveaways. Usage: /imageprotection <giveaway_id> on|off"""
    if len(context.args) < 2 or context.args[1].lower() not in ("on", "off"):
        await update.message.reply_text("Usage: /imageprotection <giveaway_id> on|off")
        return
    giveaway_id, choice = context.args[0], context.args[1].lower()
    if not await _require_host(update, context, giveaway_id):
        return

    premium = context.bot_data["premium_service"]
    if not await premium.is_active(update.effective_user.id):
        from utils.formatting import premium_required_text
        from utils.keyboards import premium_required_keyboard
        await update.message.reply_text(
            premium_required_text("Photo-verified entries"), parse_mode="HTML", reply_markup=premium_required_keyboard(),
        )
        return

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    enabled = choice == "on"
    await giveaway_service.update_config(giveaway_id, update.effective_user.id, image_protection=enabled)
    state = "enabled ✅" if enabled else "disabled ❌"
    await update.message.reply_text(f"Photo-verified entries {state} for this giveaway.")


async def dashboard_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /dashboard <giveaway_id>")
        return
    giveaway_id = context.args[0]
    if not await _require_host(update, context, giveaway_id):
        return

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    analytics: AnalyticsService = context.bot_data["analytics"]
    giveaway = await giveaway_service.get(giveaway_id)
    stats = await analytics.giveaway_stats(giveaway_id)
    await update.message.reply_text(
        dashboard_text(giveaway.data.get("title", ""), stats),
        parse_mode="HTML",
        reply_markup=host_dashboard(giveaway_id),
    )


async def addvote_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _mutate_vote(update, context, direction="add")


async def removevote_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _mutate_vote(update, context, direction="remove")


async def _mutate_vote(update: Update, context: ContextTypes.DEFAULT_TYPE, direction: str):
    if len(context.args) < 3:
        cmd = "/addvote" if direction == "add" else "/removevote"
        await update.message.reply_text(f"Usage: {cmd} <giveaway_id> <participant_id> <amount>")
        return
    giveaway_id, participant_id, amount_raw = context.args[0], context.args[1], context.args[2]
    if not await _require_host(update, context, giveaway_id):
        return

    ok, amount, err = validate_vote_amount(amount_raw)
    if not ok:
        await update.message.reply_text(f"❌ {err}")
        return

    vote_service: VoteService = context.bot_data["vote_service"]
    try:
        if direction == "add":
            await vote_service.add_manual_vote(giveaway_id, participant_id, update.effective_user.id, amount)
        else:
            await vote_service.remove_manual_vote(giveaway_id, participant_id, update.effective_user.id, amount)
        # Keep the "Vote - N" button in the channel in sync — vote_service
        # only updates storage, it never touches the live channel message.
        contestant_service = context.bot_data.get("contestant_service")
        if contestant_service is not None:
            await contestant_service.refresh_card(context.bot, participant_id)
        await update.message.reply_text(f"✅ {'Added' if direction == 'add' else 'Removed'} {amount} vote(s).")
    except VoteError as e:
        if str(e) == "invalid_participant":
            await update.message.reply_text("❌ That participant doesn't belong to this giveaway.")
        else:
            await update.message.reply_text("❌ Could not update votes.")


async def undo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /undo <giveaway_id>")
        return
    giveaway_id = context.args[0]
    if not await _require_host(update, context, giveaway_id):
        return

    vote_service: VoteService = context.bot_data["vote_service"]
    try:
        _, participant_id = await vote_service.undo_last_manual_action(giveaway_id, update.effective_user.id)
        contestant_service = context.bot_data.get("contestant_service")
        if contestant_service is not None:
            await contestant_service.refresh_card(context.bot, participant_id)
        await update.message.reply_text("↩️ Last manual vote action undone.")
    except VoteError as e:
        await update.message.reply_text(f"❌ Nothing to undo ({e}).")


async def end_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /end <giveaway_id>")
        return
    giveaway_id = context.args[0]
    if not await _require_host(update, context, giveaway_id):
        return

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    winner_service: WinnerService = context.bot_data["winner_service"]

    ended = await giveaway_service.end_giveaway(giveaway_id, update.effective_user.id, reason="host_ended")
    if ended is None:
        await update.message.reply_text("ℹ️ This giveaway has already been ended.")
        return
    winners = await winner_service.select_winners(giveaway_id, update.effective_user.id)

    if isinstance(winners, dict) and winners.get("needs_host_selection"):
        candidates = winners["candidates"]
        await update.message.reply_text(
            f"🏁 Giveaway ended. There's a {len(candidates)}-way tie at the top. "
            f"Pick the winner(s):",
            reply_markup=tie_break_picker(giveaway_id, [c.id for c in candidates],
                                           {c.id: c.data["name"] for c in candidates}),
        )
        return

    if not winners:
        await update.message.reply_text("🏁 Giveaway ended. No participant met the minimum vote requirement.")
        return

    lines = ["🏆 <b>GIVEAWAY ENDED</b>\n"]
    for w in winners:
        lines.append(f"🥇 Winner: {esc(w.data['name'])}\n🆔 Telegram ID: <code>{w.data['telegram_id']}</code>\n🗳 Valid Votes: {w.data.get('votes', 0)}")
    text = "\n\n".join(lines)

    giveaway = await giveaway_service.get(giveaway_id)
    await context.bot.send_message(chat_id=giveaway.data["channel_id"], text=text, parse_mode="HTML")
    await update.message.reply_text("✅ Winners announced in the channel.")


async def export_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /export <giveaway_id> [csv|xlsx|json]")
        return
    giveaway_id = context.args[0]
    fmt = context.args[1].lower() if len(context.args) > 1 else "csv"
    if not await _require_host(update, context, giveaway_id):
        return

    anti_abuse = context.bot_data["anti_abuse"]
    if not anti_abuse.allow_export(update.effective_user.id):
        await update.message.reply_text("⏳ Export rate limit reached, try again later.")
        return

    export_service: ExportService = context.bot_data["export_service"]
    # Recompute current top-of-leaderboard as "winner" flag context for export
    giveaway = await context.bot_data["giveaway_service"].get(giveaway_id)
    winners_ids = set()
    if giveaway and giveaway.data.get("state") == "ENDED":
        audit = await context.bot_data["audit_service"].for_giveaway(giveaway_id)
        winners_ids = {
            a.data["details"]["participant_id"]
            for a in audit if a.data.get("action") == "winner_selected"
        }

    if fmt == "xlsx":
        data = await export_service.export_xlsx(giveaway_id, winners_ids)
        filename = f"{giveaway_id}_results.xlsx"
    elif fmt == "json":
        data = await export_service.export_json(giveaway_id, winners_ids)
        filename = f"{giveaway_id}_results.json"
    else:
        data = await export_service.export_csv(giveaway_id, winners_ids)
        filename = f"{giveaway_id}_results.csv"

    await update.message.reply_document(InputFile(io.BytesIO(data), filename=filename))


# ----------------------------------------------------------------------
# Tie-break selection (spec 33: host-select tie rule)
# ----------------------------------------------------------------------
_TIEBREAK_SELECTIONS: dict[str, set] = {}  # giveaway_id -> selected participant_ids (process-local, ephemeral)


async def tie_pick_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    _, args = decode(query.data)
    giveaway_id, participant_id = args[0], args[1]

    if not await _require_host_callback(update, context, giveaway_id):
        return

    selected = _TIEBREAK_SELECTIONS.setdefault(giveaway_id, set())
    if participant_id in selected:
        selected.discard(participant_id)
    else:
        selected.add(participant_id)

    vote_service: VoteService = context.bot_data["vote_service"]
    # Re-derive the full tied candidate set for redraw from the message's
    # existing buttons rather than re-running selection (keeps this cheap).
    names_by_id = {}
    candidate_ids = []
    for row in query.message.reply_markup.inline_keyboard:
        for btn in row:
            action, cb_args = decode(btn.callback_data)
            if action == "tiepick":
                pid = cb_args[1]
                candidate_ids.append(pid)
                participant = await vote_service.records.get(pid)
                names_by_id[pid] = participant.data["name"] if participant else pid

    from utils.keyboards import tie_break_picker
    await query.edit_message_reply_markup(
        reply_markup=tie_break_picker(giveaway_id, candidate_ids, names_by_id, selected)
    )
    await query.answer()


async def tie_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    _, args = decode(query.data)
    giveaway_id = args[0]

    if not await _require_host_callback(update, context, giveaway_id):
        return

    selected = _TIEBREAK_SELECTIONS.pop(giveaway_id, set())
    if not selected:
        await query.answer("Select at least one winner first.", show_alert=True)
        _TIEBREAK_SELECTIONS[giveaway_id] = selected
        return

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    vote_service: VoteService = context.bot_data["vote_service"]
    audit_service = context.bot_data["audit_service"]
    giveaway = await giveaway_service.get(giveaway_id)

    lines = ["🏆 <b>GIVEAWAY ENDED</b>\n"]
    for pid in selected:
        participant = await vote_service.records.get(pid)
        if participant is None:
            continue
        await audit_service.log(
            "winner_selected", update.effective_user.id, giveaway_id=giveaway_id,
            details={"participant_id": pid, "votes": participant.data.get("votes", 0), "via": "host_tiebreak"},
        )
        lines.append(
            f"🥇 Winner: {esc(participant.data['name'])}\n🆔 Telegram ID: <code>{participant.data['telegram_id']}</code>\n"
            f"🗳 Valid Votes: {participant.data.get('votes', 0)}"
        )

    text = "\n\n".join(lines)
    if giveaway:
        await context.bot.send_message(chat_id=giveaway.data["channel_id"], text=text, parse_mode="HTML")
    await safe_edit(query, "✅ Winners confirmed and announced in the channel.")
    await query.answer()


async def _require_host_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, giveaway_id: str) -> bool:
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    if not await giveaway_service.is_host(giveaway_id, update.effective_user.id):
        await update.callback_query.answer("❌ Only the host can do that.", show_alert=True)
        return False
    return True


# ----------------------------------------------------------------------
# Host dashboard button actions (previously the keyboard existed with no
# handlers behind it at all — every one of these ten buttons is now wired.
# ----------------------------------------------------------------------
async def dashboard_action_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    action, args = decode(query.data)
    giveaway_id = args[0]

    if not await _require_host_callback(update, context, giveaway_id):
        return

    handlers_by_action = {
        "h_participants": _dash_participants,
        "h_votes": _dash_votes,
        "h_leaderboard": _dash_leaderboard,
        "h_reviews": _dash_reviews,
        "h_undo": _dash_undo,
        "h_analytics": _dash_analytics,
        "h_export": _dash_export,
        "h_end": _dash_end,
    }
    fn = handlers_by_action.get(action)
    if fn is None:
        await query.answer("Unknown action.", show_alert=True)
        return
    await fn(update, context, giveaway_id)


async def _back_to_dashboard_kb(giveaway_id: str):
    return host_dashboard(giveaway_id)


async def _dash_participants(update, context, giveaway_id):
    query = update.callback_query
    participant_service = context.bot_data["participant_service"]
    participants = await participant_service.list_for_giveaway(giveaway_id)
    if not participants:
        await safe_edit(query, "👥 No participants yet.", reply_markup=host_dashboard(giveaway_id))
        await query.answer()
        return
    lines = ["👥 <b>PARTICIPANTS</b>\n"]
    status_icon = {"approved": "✅", "pending_review": "🛡", "rejected": "❌"}
    for p in participants[:25]:
        icon = status_icon.get(p.status, "•")
        lines.append(f"{icon} {esc(p.data.get('name'))} — <code>{p.id}</code> — {p.data.get('votes', 0)} votes")
    if len(participants) > 25:
        lines.append(f"\n…and {len(participants) - 25} more.")
    await safe_edit(query, "\n".join(lines), parse_mode="HTML", reply_markup=host_dashboard(giveaway_id))
    await query.answer()


async def _dash_votes(update, context, giveaway_id):
    query = update.callback_query
    analytics = context.bot_data["analytics"]
    stats = await analytics.giveaway_stats(giveaway_id)
    text = (
        "🗳 <b>VOTES</b>\n\n"
        f"Valid votes: {stats['valid_votes']}\n"
        f"Manual votes: {stats['manual_votes']}\n"
        f"Deducted (membership left): {stats['deducted_votes']}\n"
        f"Restored (rejoined): {stats['restored_votes']}"
    )
    await safe_edit(query, text, parse_mode="HTML", reply_markup=host_dashboard(giveaway_id))
    await query.answer()


async def _dash_leaderboard(update, context, giveaway_id):
    query = update.callback_query
    leaderboard = context.bot_data["leaderboard"]
    ranked = await leaderboard.top(giveaway_id, limit=10)
    await safe_edit(query, leaderboard.format_free(ranked), parse_mode="HTML", reply_markup=host_dashboard(giveaway_id))
    await query.answer()


async def _dash_reviews(update, context, giveaway_id):
    query = update.callback_query
    participant_service = context.bot_data["participant_service"]
    pending = await participant_service.list_for_giveaway(giveaway_id, status="pending_review")
    if not pending:
        await safe_edit(query, "⚠️ No pending reviews.", reply_markup=host_dashboard(giveaway_id))
        await query.answer()
        return
    await query.answer(f"{len(pending)} pending — sending review cards…")
    for p in pending[:10]:
        await context.bot.send_message(
            chat_id=update.effective_user.id,
            text=(
                f"🛡 <b>MANUAL VERIFICATION</b>\n\n"
                # Every entry in this list is pending_review — i.e. the
                # AI/local filter was uncertain the name is clean — so
                # the name itself is spoiler-masked the same way the
                # moderation reason is, rather than shown in plain,
                # screenshottable text. First/last letters stay visible
                # so the host can still recognize and judge the word.
                f"👤 Participant: {spoiler_mask(p.data.get('name'))}\n"
                f"🆔 Telegram ID: <code>{p.data.get('telegram_id')}</code>\n"
                f"🤖 Status: {spoiler_mask(p.data.get('moderation_reason', 'pending'))}"
            ),
            parse_mode="HTML",
            reply_markup=review_buttons(p.id),
        )


async def _dash_undo(update, context, giveaway_id):
    query = update.callback_query
    vote_service = context.bot_data["vote_service"]
    try:
        _, participant_id = await vote_service.undo_last_manual_action(giveaway_id, update.effective_user.id)
        contestant_service = context.bot_data.get("contestant_service")
        if contestant_service is not None:
            await contestant_service.refresh_card(context.bot, participant_id)
        await query.answer("↩️ Last manual vote action undone.", show_alert=True)
    except VoteError as e:
        await query.answer(f"Nothing to undo ({e}).", show_alert=True)


async def _dash_analytics(update, context, giveaway_id):
    query = update.callback_query
    giveaway_service = context.bot_data["giveaway_service"]
    analytics = context.bot_data["analytics"]
    giveaway = await giveaway_service.get(giveaway_id)
    stats = await analytics.giveaway_stats(giveaway_id)
    await safe_edit(query, 
        dashboard_text(giveaway.data.get("title", "") if giveaway else "", stats),
        parse_mode="HTML",
        reply_markup=host_dashboard(giveaway_id),
    )
    await query.answer()


async def _dash_export(update, context, giveaway_id):
    query = update.callback_query
    anti_abuse = context.bot_data["anti_abuse"]
    if not anti_abuse.allow_export(update.effective_user.id):
        await query.answer("⏳ Export rate limit reached, try again later.", show_alert=True)
        return
    export_service = context.bot_data["export_service"]
    data = await export_service.export_csv(giveaway_id, winners_ids=set())
    await context.bot.send_document(
        chat_id=update.effective_user.id,
        document=InputFile(io.BytesIO(data), filename=f"{giveaway_id}_results.csv"),
    )
    await query.answer("📤 CSV sent to your DMs.")


async def _dash_end(update, context, giveaway_id):
    query = update.callback_query
    giveaway_service = context.bot_data["giveaway_service"]
    winner_service = context.bot_data["winner_service"]

    ended = await giveaway_service.end_giveaway(giveaway_id, update.effective_user.id, reason="host_ended")
    if ended is None:
        await query.answer("ℹ️ This giveaway has already been ended.", show_alert=True)
        return
    winners = await winner_service.select_winners(giveaway_id, update.effective_user.id)

    if isinstance(winners, dict) and winners.get("needs_host_selection"):
        candidates = winners["candidates"]
        await safe_edit(query, 
            f"🏁 There's a {len(candidates)}-way tie at the top. Pick the winner(s):",
            reply_markup=tie_break_picker(giveaway_id, [c.id for c in candidates],
                                           {c.id: c.data["name"] for c in candidates}),
        )
        await query.answer()
        return

    if not winners:
        await safe_edit(query, "🏁 Giveaway ended. No participant met the minimum vote requirement.")
        await query.answer()
        return

    lines = ["🏆 <b>GIVEAWAY ENDED</b>\n"]
    for w in winners:
        lines.append(f"🥇 Winner: {esc(w.data['name'])}\n🆔 Telegram ID: <code>{w.data['telegram_id']}</code>\n🗳 Valid Votes: {w.data.get('votes', 0)}")
    text = "\n\n".join(lines)

    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway:
        await context.bot.send_message(chat_id=giveaway.data["channel_id"], text=text, parse_mode="HTML")
    await safe_edit(query, "✅ Giveaway ended. Winners announced in the channel.")
    await query.answer()
