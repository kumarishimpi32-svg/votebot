"""
handlers/voting.py
Publishing approved participants to the giveaway channel and handling
vote button presses (spec 12, 22-23).
"""
from __future__ import annotations
from utils.telegram_helpers import safe_edit
from telegram import Update
from telegram.ext import ContextTypes
from security.callbacks import decode
from security.rate_limit import reject_if_limited
from services.giveaway_service import GiveawayService
from services.vote_service import VoteService, VoteError
from services.membership_service import MembershipService
from services.anti_abuse import AntiAbuseService
from utils.formatting import participant_card
from utils.keyboards import vote_button


async def publish_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manual catch-up publish (e.g. approvals that landed while the bot's
    channel permissions were broken). Normal approvals publish
    automatically now — see services/contestant_service.py — so this is a
    safety net, not the primary path, and shares the exact same idempotent
    implementation so there is one authoritative publish flow."""
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    contestant_service = context.bot_data["contestant_service"]

    if not context.args:
        await update.message.reply_text("Usage: /publish <giveaway_id>")
        return
    giveaway_id = context.args[0]

    if not await giveaway_service.is_host(giveaway_id, update.effective_user.id):
        await update.message.reply_text("❌ Only the host can publish this giveaway.")
        return

    posted = await contestant_service.publish_all_pending(context.bot, giveaway_id)
    if posted == 0:
        await update.message.reply_text("Nothing new to publish — every approved entry is already in the channel.")
    else:
        await update.message.reply_text(f"✅ Published {posted} new participant(s).")


async def vote_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    action, args = decode(query.data)
    giveaway_id, participant_id = args[0], args[1]

    anti_abuse: AntiAbuseService = context.bot_data["anti_abuse"]
    if anti_abuse.is_replay(query.id):
        await query.answer("Already processed.", show_alert=False)
        return
    if await reject_if_limited(update, anti_abuse.allow_vote(update.effective_user.id)):
        return

    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    vote_service: VoteService = context.bot_data["vote_service"]
    membership_service: MembershipService = context.bot_data["membership_service"]

    giveaway = await giveaway_service.get(giveaway_id)
    if giveaway is None or giveaway.data.get("state") != "ACTIVE":
        await query.answer("This giveaway has ended.", show_alert=True)
        return

    required_channels = giveaway.data.get("required_channels", [])
    if required_channels:
        ok, missing = await membership_service.is_member_of_all(update.effective_user.id, required_channels)
        if not ok:
            await query.answer(
                "❌ Join all required channels before voting.", show_alert=True
            )
            return

    try:
        await vote_service.cast_vote(giveaway_id, participant_id, update.effective_user.id)
    except VoteError as e:
        err = str(e)
        if err == "already_voted":
            await query.answer("⚠️ You have already voted in this contest.", show_alert=True)
        elif err == "self_vote":
            await query.answer("❌ You can't vote for your own entry.", show_alert=True)
        elif err in ("invalid_participant", "not_approved"):
            # Forged/stale callback_data (wrong giveaway/participant pairing,
            # or a not-yet-approved entry) — never silently count these.
            await query.answer("This entry isn't available to vote for.", show_alert=True)
        else:
            await query.answer("Could not register your vote.", show_alert=True)
        return

    participant = await vote_service.records.get(participant_id)
    votes = participant.data.get("votes", 0)
    await safe_edit(query, 
        participant_card(
            participant.data["name"], participant.data["telegram_id"], votes
        ),
        parse_mode="HTML",
        reply_markup=vote_button(giveaway_id, participant_id, votes),
    )
    await query.answer("✅ Vote counted!")
