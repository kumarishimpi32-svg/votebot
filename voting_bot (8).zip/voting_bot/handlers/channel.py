"""
handlers/channel.py

Multi-channel CONNECT system UI (mega-prompt Phase 2 / spec §5, §6, §8-§14):
Add Channel, My Channels, active-channel switching, Access Denied.

Every handler here re-verifies authorization from the stored CHANNEL
record (via ChannelService/Permissions) — never from callback_data alone,
and never from context.user_data — so a manipulated callback carrying
another host's channel-record id is rejected the same way regardless of
what buttons the UI happened to show.
"""
from __future__ import annotations
import logging
from telegram import Update
from telegram.ext import ContextTypes
from config import CONFIG
from utils.telegram_helpers import safe_edit
from security.callbacks import decode
from security.rate_limit import reject_if_limited
from services.channel_service import ChannelService, ChannelError
from utils.formatting import (
    channels_menu_text, add_channel_prompt_text, channel_error_text,
    channel_connected_text, access_denied_text,
    remove_channel_confirm_text, channel_removed_text,
)
from utils.keyboards import (
    channels_menu_keyboard, add_channel_keyboard, channel_error_keyboard,
    channel_connected_keyboard, access_denied_keyboard,
    remove_channel_confirm_keyboard,
)

logger = logging.getLogger("channel_handlers")


async def _show_access_denied(query) -> None:
    await query.answer("❌ Access denied.", show_alert=True)
    await safe_edit(query, access_denied_text(), parse_mode="HTML", reply_markup=access_denied_keyboard())


async def channels_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """My Channels (spec §2.4) — only ever this user's own channels."""
    query = update.callback_query
    await query.answer()
    channel_service: ChannelService = context.bot_data["channel_service"]
    user_id = update.effective_user.id

    channels = await channel_service.list_for_owner(user_id)
    active = await channel_service.get_active_channel(user_id)
    active_id = active.id if active else None

    await safe_edit(
        query,
        channels_menu_text(channels, active_id),
        parse_mode="HTML",
        reply_markup=channels_menu_keyboard(channels, active_id),
    )


async def channels_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/channels — text-command entry point to the same "My Channels"
    screen as the 🔗 Channels button. Previously there was no
    CommandHandler registered for this at all, so typing /channels did
    nothing; this shares the exact same data-fetch as
    channels_menu_callback so the two entry points can never drift."""
    channel_service: ChannelService = context.bot_data["channel_service"]
    user_id = update.effective_user.id

    channels = await channel_service.list_for_owner(user_id)
    active = await channel_service.get_active_channel(user_id)
    active_id = active.id if active else None

    await update.message.reply_text(
        channels_menu_text(channels, active_id),
        parse_mode="HTML",
        reply_markup=channels_menu_keyboard(channels, active_id),
    )


async def add_channel_start_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Opens the Add Channel flow (spec §2.1, steps 1-3). Open to every
    host — there is no default/fallback channel, so connecting a channel
    is mandatory for everyone, not a Premium perk."""
    query = update.callback_query
    await query.answer()
    context.user_data["awaiting_channel_input"] = True
    await safe_edit(query, add_channel_prompt_text(), parse_mode="HTML", reply_markup=add_channel_keyboard())


async def handle_channel_input_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Free-text handler for the Add Channel flow, hooked into
    main.text_router the same way payment-reference / vote-amount /
    name-entry text states are. Returns True if it handled this message
    (so the router stops), False otherwise. Invalid input never crashes
    the bot — every failure path re-shows a normal error screen."""
    if not context.user_data.get("awaiting_channel_input"):
        return False

    context.user_data.pop("awaiting_channel_input", None)
    channel_service: ChannelService = context.bot_data["channel_service"]
    user = update.effective_user

    if CONFIG.premium_max_channels > 0:
        existing = await channel_service.list_for_owner(user.id)
        if len(existing) >= CONFIG.premium_max_channels:
            await update.message.reply_text(
                f"⚠️ You've reached the limit of {CONFIG.premium_max_channels} connected channels "
                f"for your Premium plan. Remove one from 🔗 My Channels before adding another.",
                parse_mode="HTML",
            )
            return True

    anti_abuse = context.bot_data.get("anti_abuse")
    if anti_abuse is not None and await reject_if_limited(
        update, anti_abuse.allow_channel_connect(user.id),
        message="⏳ Too many channel attempts. Please wait a bit and try again.",
    ):
        return True

    raw = (update.message.text or "").strip()

    try:
        rec = await channel_service.add_channel(user.id, raw)
    except ChannelError as e:
        logger.info("Add channel failed for user %s (%s): %s", user.id, e.code, e.detail)
        await update.message.reply_text(
            channel_error_text(e.code, e.detail), parse_mode="HTML", reply_markup=channel_error_keyboard(),
        )
        return True

    await update.message.reply_text(
        channel_connected_text(rec.data["title"]), parse_mode="HTML", reply_markup=channel_connected_keyboard(),
    )
    return True


async def remove_channel_start_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """🗑 button on a My Channels row — asks for confirmation first, so a
    stray tap can never silently disconnect a channel a giveaway relies on."""
    query = update.callback_query
    _, args = decode(query.data)
    if not args:
        await query.answer("Invalid selection.", show_alert=True)
        return
    channel_record_id = args[0]
    channel_service: ChannelService = context.bot_data["channel_service"]
    user_id = update.effective_user.id

    owned = await channel_service.get_owned(channel_record_id, user_id)
    if owned is None:
        await _show_access_denied(query)
        return

    await query.answer()
    await safe_edit(
        query,
        remove_channel_confirm_text(owned.data.get("title", "Untitled")),
        parse_mode="HTML",
        reply_markup=remove_channel_confirm_keyboard(channel_record_id),
    )


async def remove_channel_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Actually disconnects the channel — ownership re-verified from the
    stored record itself, never trusted from the callback alone."""
    query = update.callback_query
    _, args = decode(query.data)
    if not args:
        await query.answer("Invalid selection.", show_alert=True)
        return
    channel_record_id = args[0]
    channel_service: ChannelService = context.bot_data["channel_service"]
    user_id = update.effective_user.id

    owned = await channel_service.get_owned(channel_record_id, user_id)
    if owned is None:
        await _show_access_denied(query)
        return

    title = owned.data.get("title", "Untitled")
    try:
        await channel_service.remove_channel(user_id, channel_record_id)
    except ChannelError as e:
        await query.answer("⚠️ Could not remove channel.", show_alert=True)
        await safe_edit(query, channel_error_text(e.code, e.detail), parse_mode="HTML", reply_markup=channel_error_keyboard())
        return

    channels = await channel_service.list_for_owner(user_id)
    active = await channel_service.get_active_channel(user_id)
    active_id = active.id if active else None
    await query.answer("🗑 Channel removed.")
    await safe_edit(
        query,
        channel_removed_text(title) + "\n\n" + channels_menu_text(channels, active_id),
        parse_mode="HTML",
        reply_markup=channels_menu_keyboard(channels, active_id),
    )


async def select_channel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Change active channel (spec §2.5). channel_record_id in the
    callback is only ever a lookup key — ownership is re-verified from
    the stored record on every single call, not trusted from the UI."""
    query = update.callback_query
    _, args = decode(query.data)
    if not args:
        await query.answer("Invalid selection.", show_alert=True)
        return
    channel_record_id = args[0]
    user_id = update.effective_user.id
    channel_service: ChannelService = context.bot_data["channel_service"]

    # Ownership check happens INSIDE set_active_channel (get_owned), not
    # just here — but we also short-circuit obviously-foreign ids early
    # so a stale/manipulated callback gets Access Denied, not a generic
    # verification-failed screen (which would leak that the id exists).
    owned = await channel_service.get_owned(channel_record_id, user_id)
    if owned is None:
        await _show_access_denied(query)
        return

    try:
        rec = await channel_service.set_active_channel(user_id, channel_record_id)
    except ChannelError as e:
        await query.answer("⚠️ Verification failed.", show_alert=True)
        await safe_edit(query, channel_error_text(e.code, e.detail), parse_mode="HTML", reply_markup=channel_error_keyboard())
        return

    channels = await channel_service.list_for_owner(user_id)
    await query.answer(f"✅ Active channel: {rec.data['title']}")
    await safe_edit(
        query,
        channels_menu_text(channels, rec.id),
        parse_mode="HTML",
        reply_markup=channels_menu_keyboard(channels, rec.id),
    )
