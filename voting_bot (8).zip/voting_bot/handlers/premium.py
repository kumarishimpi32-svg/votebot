"""
handlers/premium.py
💎 PREMIUM menu: view plans, my premium status, start a purchase (spec 37-43, 53-54).
"""
from __future__ import annotations
from utils.telegram_helpers import safe_edit
from telegram import Update
from telegram.ext import ContextTypes
from security.callbacks import decode
from services.premium_service import PremiumService
from config import CONFIG
from utils.formatting import (
    premium_status_text, premium_checkout_text, premium_payment_done_prompt,
    premium_plans_header, premium_command_list_text, premium_required_text,
)
from utils.small_caps import sc
from utils.keyboards import plan_list, confirm_cancel, back_home, premium_required_keyboard


async def premium_menu_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/premium — spec: shows ALL premium commands. Usable if the caller
    has Premium; otherwise shows 'you don't have premium' plus a 💎
    Premium / 🏠 Home choice, exactly as spec'd."""
    premium: PremiumService = context.bot_data["premium_service"]
    active = await premium.is_active(update.effective_user.id)

    if not active:
        await update.message.reply_text(
            premium_required_text("Premium commands"), parse_mode="HTML", reply_markup=premium_required_keyboard(),
        )
        return

    acc = await premium.get_account(update.effective_user.id)
    text = (
        premium_status_text(
            active, acc.data.get("plan_id") if acc else None,
            acc.data.get("started_at") if acc else None,
            acc.data.get("expires_at") if acc else None,
        )
        + "\n" + premium_command_list_text(active)
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=back_home())


async def premium_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Home menu's 💎 Premium button — same gating/content as /premium,
    plus a direct link into plan browsing since that's the natural next
    action for a non-Premium user landing here."""
    query = update.callback_query
    premium: PremiumService = context.bot_data["premium_service"]
    active = await premium.is_active(update.effective_user.id)

    if not active:
        await query.answer()
        text = premium_required_text("Premium commands") + f"\n\n{sc('Send /plans to view Premium plans')}."
        await safe_edit(query, text, parse_mode="HTML", reply_markup=premium_required_keyboard())
        return

    await query.answer()
    acc = await premium.get_account(update.effective_user.id)
    text = (
        premium_status_text(
            active, acc.data.get("plan_id") if acc else None,
            acc.data.get("started_at") if acc else None,
            acc.data.get("expires_at") if acc else None,
        )
        + "\n" + premium_command_list_text(active)
        + f"\n{sc('Send /plans to view or renew Premium plans')}."
    )
    await safe_edit(query, text, parse_mode="HTML", reply_markup=back_home())


async def plans_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    premium: PremiumService = context.bot_data["premium_service"]
    plans = await premium.list_active_plans()
    if not plans:
        await update.message.reply_text("No Premium plans are configured yet. Ask the owner to add one via /admin.")
        return
    await update.message.reply_text(premium_plans_header(), parse_mode="HTML", reply_markup=plan_list(plans))


async def plan_selected_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    _, args = decode(query.data)
    plan_record_id = args[0]
    premium: PremiumService = context.bot_data["premium_service"]
    plan = await premium.records.get(plan_record_id)
    if plan is None:
        await query.answer("Plan no longer available.", show_alert=True)
        return

    context.user_data["pending_plan_record_id"] = plan_record_id
    text = premium_checkout_text(
        plan.data["name"], plan.data["price_inr"], plan.data["duration_days"],
        CONFIG.payment_provider, CONFIG.manual_payment_instructions,
    )
    await safe_edit(query, text, parse_mode="HTML", reply_markup=confirm_cancel("premium", plan_record_id))

    # If the owner has uploaded a payment QR (/admin paymentqr), show it
    # here as a separate photo message — this is the actual scan-to-pay
    # step; previously checkout was text-only with no QR at all.
    records = context.bot_data["records"]
    qr = await records.find_one("CONFIG", key="payment_qr")
    if qr and qr.data.get("file_id"):
        try:
            await context.bot.send_photo(
                chat_id=update.effective_user.id,
                photo=qr.data["file_id"],
                caption="📷 Scan to pay. Once paid, tap 💳 Payment Done above and send your transaction ID.",
            )
        except Exception:
            pass  # never block checkout if the QR send fails for any reason

    await query.answer()


async def payment_done_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    _, args = decode(query.data)
    plan_record_id = args[0]
    context.user_data["awaiting_payment_reference_for"] = plan_record_id
    await safe_edit(query, premium_payment_done_prompt(), parse_mode="HTML")
    await query.answer()
