"""
handlers/giveaway.py
Giveaway listing (spec 10-12). Creation itself now lives entirely in
handlers/giveaway_wizard.py as a button-driven flow — no more typing a
pipe-delimited command with a raw channel_id. /creategiveaway (typed with
no args) and the 🎁 Create button both route to that wizard.
"""
from __future__ import annotations
from telegram import Update
from telegram.ext import ContextTypes
from services.giveaway_service import GiveawayService
from utils.formatting import esc


async def my_giveaways_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    giveaway_service: GiveawayService = context.bot_data["giveaway_service"]
    giveaways = await giveaway_service.list_by_host(update.effective_user.id)
    if not giveaways:
        await update.message.reply_text("You haven't created any giveaways yet. Tap 🎁 Giveaways → 🎁 Create to start one.")
        return
    lines = ["🎁 <b>YOUR GIVEAWAYS</b>\n"]
    for g in giveaways:
        state_icon = "🟢" if g.data.get("state") == "ACTIVE" else "🔴"
        lines.append(f"{state_icon} {esc(g.data.get('title'))}")
    lines.append("\nTap 🎁 Giveaways → 🗂 Manage to open any of these — no ID needed.")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")
